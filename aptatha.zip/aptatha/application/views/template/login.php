<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="SI Apotek Klinik Permata Husada">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title> SI Apotek Atha</title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo base_url('frontend/img/core-img/favicon.ico') ?>">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="<?php echo base_url('frontend/style.css') ?>">

    <!-- Responsive Stylesheet -->
    <link rel="stylesheet" href="<?php echo base_url('frontend/css/responsive.css') ?>">

</head>

<body>

    <div class="page-wrapper">
        <!-- Breadcrumb Area -->
        <div class="breadcrumb-area"  style="padding: 15px 15px;">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <!--<ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashboard-1.html">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="#">Authentication</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Login</li>
                    </ol>-->
                </nav>
            </div>
        </div>
		

        <!-- Wrapper -->
        <div class="wrapper wrapper-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <!-- Middle Box -->
                        <div style="padding:80px !important" class="middle-box bg-boxshadow text-center">
                            <h1 class="logo-name"><img src="<?php echo base_url('frontend/img/core-img/logo_.jpeg') ?>" style="width:100%" alt=""></h1>
                            <!--<h1 style="font-size:135px" class="logo-name">ATHA</h1>-->
                            <!--<h4>Apotek Atha</h4>-->
                            <p>Silahkan Login</p>
							<?php $idmessage = $this->session->flashdata('idmessage') ?>
							<?php $message = $this->session->flashdata('message') ?>
							<?php if ($message) { ?>
								<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
									<button data-dismiss="alert" class="close">
										&times;
									</button>
									<i class="fa fa-info-circle"></i>
									<strong><?php echo $message ?></strong>
								</div>
							<?php } ?>

                            <!-- Form -->
							<?php echo $contents ?>

                            <p class="font-size-12">SI Jual Beli Apotek Atha &copy; 2018</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--
		<div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Copywrite Text 
                    <div class="copywrite-text mt-100">
                        <p>SI Jual Beli Apotek Utama Permata Husada &copy; 2018 created by <a href="#">Floit.my.id</a></p>
                         Nav Style 
                        <div class="footer--nav--style">
                            <ul>
                                <li><a href="#">About</a></li>
                                <li><a href="#">Privacy</a></li>
                                <li><a href="#">Purchase</a></li>
                            </ul>
                        </div>
						
                    </div>
                </div>
            </div>
        </div>
		-->
    </div>

    <!-- jQuery 2.2.4 -->
    <script src="<?php echo base_url('frontend/assets/js/jquery/jquery.2.2.4.min.js') ?>"></script>
    <!-- Bootsrap js -->
    <script src="<?php echo base_url('frontend/assets/js/bootstrap/popper.min.js') ?>"></script>
    <script src="<?php echo base_url('frontend/assets/js/bootstrap/bootstrap.min.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/classy-nav.js') ?>"></script>

    <!-- Active js -->
    <script src="<?php echo base_url('frontend/js/active.js') ?>"></script>

</body>

</html>