<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="SI Apotek Klinik Permata Husada">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title> SI Jual Beli Apotek Klinik Permata Husada</title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo base_url('frontend/img/core-img/favicon.ico') ?>">

    <!-- Core Stylesheet -->
	<link rel="stylesheet" href="<?php echo base_url('frontend/style.css') ?>"> 
    <link rel="stylesheet" href="<?php echo base_url('frontend/css/plugins/data-table-css/datatables.min.css') ?>">

    <!-- Selects Tag Stylesheet -->
    <link rel="stylesheet" href="<?php echo base_url('frontend/css/plugins/select-tags-css/bootstrap-multiselect.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('frontend/css/plugins/select-tags-css/bootstrap-tagsinput.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('frontend/css/plugins/select-tags-css/bootstrap-select.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('frontend/css/plugins/select-tags-css/bootstrap-select-2.css') ?>">
	
    <!-- Responsive Stylesheet -->
    <link rel="stylesheet" href="<?php echo base_url('frontend/css/responsive.css') ?>">

</head>

<body>

		<?php echo $contents ?>


    <!-- jQuery 2.2.4 -->
    <script src="<?php echo base_url('frontend/assets/js/jquery/jquery.2.2.4.min.js') ?>"></script>
    <!-- Bootsrap js -->
    <script src="<?php echo base_url('frontend/assets/js/bootstrap/popper.min.js') ?>"></script>
    <script src="<?php echo base_url('frontend/assets/js/bootstrap/bootstrap.min.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/classy-nav.js') ?>"></script>

    <!-- Plugins js -->
    <script src="<?php echo base_url('frontend/js/plugins-js/password-metter-js/pwstrength-bootstrap.min.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/password-metter-js/pwstrength-zxcvbn.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/password-metter-js/active.js') ?>"></script>
	
    <!-- Data Table js -->
    <script src="<?php echo base_url('frontend/js/plugins-js/data-table-js/data-table.bootstrap.min.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/data-table-js/data-table.min.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/data-table-js/data-table-active.js') ?>"></script>
	
    <!-- Select And Tag Js -->
    <script src="<?php echo base_url('frontend/js/plugins-js/select-tags-js/bootstrap-multiselect.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/select-tags-js/bootstrap-forms-selects.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/select-tags-js/bootstrap-tagsinput.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/select-tags-js/bootstrap-select.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/select-tags-js/bootstrap-select-2.js') ?>"></script>

    <!-- Active js -->
    <script src="<?php echo base_url('frontend/js/active.js') ?>"></script>

	<script type="text/javascript">
	 window.onload = function() { window.print(); }
	</script>
</body>

</html>