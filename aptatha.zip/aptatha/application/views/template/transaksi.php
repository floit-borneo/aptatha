<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="SI Apotek Klinik Permata Husada">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title> SI Jual Beli Apotek Atha</title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo base_url('frontend/img/core-img/favicon.ico') ?>">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="<?php echo base_url('frontend/style.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('frontend/css/plugins/data-table-css/datatables.min.css') ?>">

    <!-- Selects Tag Stylesheet -->
    <link rel="stylesheet" href="<?php echo base_url('frontend/css/plugins/select-tags-css/bootstrap-multiselect.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('frontend/css/plugins/select-tags-css/bootstrap-tagsinput.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('frontend/css/plugins/select-tags-css/bootstrap-select.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('frontend/css/plugins/select-tags-css/bootstrap-select-2.css') ?>">
	
    <!-- Responsive Stylesheet -->
    <link rel="stylesheet" href="<?php echo base_url('frontend/css/responsive.css') ?>">

</head>

<body>

    <div class="page-wrapper">

        <!-- Page Top Bar Area -->
        <div class="page-top-bar-area d-flex align-items-center justify-content-between">

            <!-- Logo Trigger Area -->
            <div class="logo-trigger-area d-flex align-items-center">
				<!--
                <a href="dashboard-1.html" class="logo">
                   <span class="big-logo">
						<img src="<?php echo base_url('frontend/img/core-img/logo-klinik.jpg') ?>" style="width:50%"alt="">
                   </span>
                </a>-->
				
				<a href="<?php echo site_url('profile') ?>">
				<h6 style="color:white; margin:0; margin-right:10px; padding:10px;">SI Jual Beli Apotek Atha </h6>
				</a>
                <!-- Trigger -->
                <div class="top-trigger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>


            <!-- User Meta -->
            <div class="user-meta-data d-flex align-items-center">


                <!-- Profile -->
                <div class="topbar-profile">
				
								
                    <!-- Thumb -->
                    <div class="user---thumb">
                        <p style="color: grey; font-weight:700; background-color: white;padding: 5px;margin: 0;border-radius: 100px" > ATHA </p>
                    </div>
                    <!-- Profile Data -->
                    <div class="profile-data">
                        <!-- Profile User Details -->
                        <div class="profile-user--details" style="background-image: url(<?php echo base_url('frontend/img/thumbnails-img/profile-bg.jpg') ?>);">
                            <!-- Thumb -->
                            <div class="profile---thumb-det">
                                <!--<img src="<?php echo base_url('frontend/img/core-img/logo-klinik.jpg') ?>" alt="">-->
                            </div>
                            <!-- Profile Text -->
                            <div class="profile---text-details">
								<?php if($hakakses=='1'){ ?>
                                <h6>Super Administrator</h6>
								<?php }else if($hakakses=='2'){ ?>
                                <h6>Administrator</h6>
								<?php } if($hakakses=='3'){ ?>
                                <h6>Kasir</h6>
								<?php } ?>
                            </div>
                        </div>
                        <!-- Profile List Data -->
                        <a class="profile-list--data" href="<?php echo site_url('profile') ?>">
                            <!-- Profile icon -->
                            <div class="profile--list-icon">
                                <i class="fa fa-user" aria-hidden="true"></i>
                            </div>
                            <!-- Profile Text -->
                            <div class="notification--list-body-text profile">
                                <h6>My profile</h6>
                            </div>
                        </a>
                        <!-- Profile List Data -->
                        <a class="profile-list--data" href="<?php echo site_url('login/logout') ?>">
                            <!-- Profile icon -->
                            <div class="profile--list-icon">
                                <i class="fa fa-sign-out text-danger" aria-hidden="true"></i>
                            </div>
                            <!-- Profile Text -->
                            <div class="notification--list-body-text profile">
                                <h6>Sign-out</h6>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- ###### Layout Container Area ###### -->
        <div class="layout-container-area mt-70">
            <!-- Side Menu Area -->
            <div class="side-menu-area">

                <div class="classy-nav-container breakpoint-off">
                    <!-- Classy Menu -->
                    <nav class="classy-navbar justify-content-between" id="classyNav">

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">
                            <!-- close btn -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="<?php echo site_url('profile') ?>"><i class="fa fa-desktop"></i> Dashboards</a></li>
                                    <li><a href="<?php echo site_url('laporan') ?>"><i class="fa fa-book"></i> Laporan
									</a>
											<ul class="dropdown">
												<li><a href="<?php echo site_url('laporan/transaksi') ?>">-Laporan Transaksi</a></li>
											</ul>
                                    </li>
                                    <li><a href="<?php echo site_url('admin') ?>"><i class="fa fa-database"></i> Administrator </a>
											<ul class="dropdown">
												<li><a href="<?php echo site_url('admin/produk') ?>">-Produk</a></li>
												<li><a href="<?php echo site_url('admin/supplier') ?>">-Supplier</a></li>
												<li><a href="<?php echo site_url('admin/adjust') ?>">-Adjusment</a></li>
											</ul>
                                    </li>
                                    <li><a href="<?php echo site_url('transaksi') ?>"><i class="fa fa-users"></i> Transaksi</a>
											<ul class="dropdown">
												<li><a href="<?php echo site_url('transaksi/barangMasuk') ?>">-Barang Masuk</a></li>
												<li> <a href="<?php echo site_url('transaksi/penjualanDgnResep') ?>">-Penjualan Dengan Resep</a>
                                                    <ul class="dropdown">
                                                        <li><a href="<?php echo site_url('transaksi/penjualanDgnResep') ?>">-List</a></li>
                                                        <li><a href="<?php echo site_url('transaksi/addPenjualanTnpResep') ?>">-Penjualan Baru</a></li>
                                                    </ul>
                                                </li>
												<li><a href="<?php echo site_url('transaksi/penjualanTnpResep') ?>">-Penjualan Tanpa Resep</a>
                                                    <ul class="dropdown">
                                                        <li><a href="<?php echo site_url('transaksi/penjualanTnpResep') ?>">-List</a></li>
                                                        <li><a href="<?php echo site_url('transaksi/addPenjualanTnpResep') ?>">-Penjualan Baru</a></li>
                                                    </ul>
                                                </li>
											</ul>
                                    </li>
                                </ul>
                            </div>
                            <!-- Nav End -->
                        </div>
                    </nav>
                </div>
            </div>

            <!-- Layout Container -->
            <div class="layout-container sidemenu-container">
				<?php echo $contents ?>
				

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <!-- Copywrite Text -->
                            <div class="copywrite-text mt-50">
                                <p class="font-size-12">SI Jual Beli Apotek Atha x Floit &copy; 2018</p>
                                <!-- Nav Style -->
                            </div>
                        </div>
                    </div>
                </div>
				
            </div>
        </div>
    </div>


    <!-- jQuery 2.2.4 -->
    <script src="<?php echo base_url('frontend/assets/js/jquery/jquery.2.2.4.min.js') ?>"></script>
    <!-- Bootsrap js -->
    <script src="<?php echo base_url('frontend/assets/js/bootstrap/popper.min.js') ?>"></script>
    <script src="<?php echo base_url('frontend/assets/js/bootstrap/bootstrap.min.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/classy-nav.js') ?>"></script>

    <!-- Plugins js -->
    <script src="<?php echo base_url('frontend/js/plugins-js/password-metter-js/pwstrength-bootstrap.min.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/password-metter-js/pwstrength-zxcvbn.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/password-metter-js/active.js') ?>"></script>
	
    <!-- Data Table js -->
    <script src="<?php echo base_url('frontend/js/plugins-js/data-table-js/data-table.bootstrap.min.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/data-table-js/data-table.min.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/data-table-js/data-table-active.js') ?>"></script>
	
    <!-- Select And Tag Js -->
    <script src="<?php echo base_url('frontend/js/plugins-js/select-tags-js/bootstrap-multiselect.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/select-tags-js/bootstrap-forms-selects.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/select-tags-js/bootstrap-tagsinput.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/select-tags-js/bootstrap-select.js') ?>"></script>
    <script src="<?php echo base_url('frontend/js/plugins-js/select-tags-js/bootstrap-select-2.js') ?>"></script>

    <!-- Active js -->
    <script src="<?php echo base_url('frontend/js/active.js') ?>"></script>

</body>

</html>