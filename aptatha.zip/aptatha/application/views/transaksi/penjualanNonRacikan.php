

                <!-- Breadcrumb Area -->
                <div class="breadcrumb-area" style="padding:20px 5px">
                    <div class="container-fluid">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Transaksi</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Daftar Penjualan Non Racikan</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox bg-boxshadow">
                                    <div class="ibox-title mb-10">
                                        <h5>Daftar Penjualan Non Racikan</h5>
                                    </div>
									<?php $idmessage = $this->session->flashdata('idmessage') ?>
									<?php $message = $this->session->flashdata('message') ?>
									<?php if ($message) { ?>
										<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
											<button data-dismiss="alert" class="close">
												&times;
											</button>
											<i class="fa fa-info-circle"></i>
											<strong><?php echo $message ?></strong>
										</div>
									<?php } ?>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											<div class="">
												<p><a href="<?php echo site_url('transaksi/addPenjualanNonRacikan') ?>" class="btn btn-info"><i class="fa fa-plus"></i> Penjualan Non Racikan Baru </a>
											</div>
											<?php $no=0; ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-full-penjualanNonRacikan">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Tanggal Penjualan</th>
                                                        <th>Total</th>
                                                        <th width="180"></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($penjualanNonRacikan_data as $penjualanNonRacikan){ ?>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td><?php echo $penjualanNonRacikan->nmpembuat ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($penjualanNonRacikan->tglpenjualan)); ?></td>
                                                        <td><?php echo $penjualanNonRacikan->total ?></td>
                                                        <td width="180" class="text-right">
															<a href="<?php echo site_url('transaksi/viewPenjualanNonRacikan/'.$penjualanNonRacikan->idpenjualan)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Lihat"><i class="fa fa-eye fa-white"></i></a>
															<a href="<?php echo site_url('transaksi/editPenjualanNonRacikan/'.$penjualanNonRacikan->idpenjualan)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Edit"><i class="fa fa-edit fa-white"></i></a>
															<a href="<?php echo site_url('transaksi/hapusPenjualanNonRacikan/'.$penjualanNonRacikan->idpenjualan)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Hapus"
															   onclick="return confirm('Hapus Penjualan Non Racikan?')"><i class="fa fa-times fa-white"></i></a>
														</td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Tanggal Penjualan</th>
                                                        <th>Total</th>
                                                        <th width="180"></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
