

                <!-- Breadcrumb Area -->
                <div class="breadcrumb-area" style="padding:20px 5px">
                    <div class="container-fluid">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Transaksi</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Daftar Barang Masuk</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox bg-boxshadow">
                                    <div class="ibox-title mb-10">
                                        <h5>Daftar Barang Masuk</h5>
                                    </div>
									<?php $idmessage = $this->session->flashdata('idmessage') ?>
									<?php $message = $this->session->flashdata('message') ?>
									<?php if ($message) { ?>
										<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
											<button data-dismiss="alert" class="close">
												&times;
											</button>
											<i class="fa fa-info-circle"></i>
											<strong><?php echo $message ?></strong>
										</div>
									<?php } ?>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											<div class="">
												<p><a href="<?php echo site_url('transaksi/addBarangMasuk') ?>" class="btn btn-info"><i class="fa fa-plus"></i> Barang Masuk Baru </a>
											</div>
											<?php $no=0; ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-full-barangMasuk">
                                                <thead>
                                                    <tr>
                                                        <th width="40">No</th>
                                                        <th>Tanggal Masuk</th>
                                                        <th>Nama Supplier</th>
                                                        <th>No. Faktur</th>
                                                        <th>Tanggal Faktur</th>
                                                        <th width="120">Total</th>
                                                        <th width="120"></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($barangMasuk_data as $barangMasuk){ ?>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($barangMasuk->tglbarangmasuk)); ?></td>
                                                        <td><?php echo $barangMasuk->nmsupplier ?></td>
                                                        <td><?php echo $barangMasuk->nofaktur ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($barangMasuk->tglfaktur)); ?></td>
                                                        <td><?php echo 'Rp'.number_format($barangMasuk->total, 0, ',', '.').',-' ?></td>
                                                        <td class="text-right">
															<a href="<?php echo site_url('cprint/barangMasuk/'.$barangMasuk->idbarangmasuk)?>" target="blank" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Lihat"><i class="fa fa-print fa-white"></i></a>
															<a href="<?php echo site_url('transaksi/viewBarangMasuk/'.$barangMasuk->idbarangmasuk)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Lihat"><i class="fa fa-eye fa-white"></i></a>
															<a href="<?php echo site_url('transaksi/editBarangMasuk/'.$barangMasuk->idbarangmasuk)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Edit"><i class="fa fa-edit fa-white"></i></a>
															<a href="<?php echo site_url('transaksi/hapusBarangMasuk/'.$barangMasuk->idbarangmasuk)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Hapus"
															   onclick="return confirm('Hapus Barang Masuk ?')"><i class="fa fa-times fa-white"></i></a>
														</td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Tanggal Masuk</th>
                                                        <th>Nama Supplier</th>
                                                        <th>No. Faktur</th>
                                                        <th>Tanggal Faktur</th>
                                                        <th>Total</th>
                                                        <th></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
