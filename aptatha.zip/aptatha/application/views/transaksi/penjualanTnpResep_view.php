

<!-- Breadcrumb Area -->
<div class="breadcrumb-area" style="padding:20px 5px">
	<div class="container-fluid">
		<nav aria-label="breadcrumb">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="#">Transaksi</a></li>
				<li class="breadcrumb-item"><a href="<?php echo site_url('transaksi/penjualanTnpResep') ?>">Penjualan Tanpa Resep</a></li>
				<li class="breadcrumb-item active" aria-current="page">Daftar Penjualan Tanpa Resep</li>
			</ol>
		</nav>
	</div>
</div>

<!-- Wrapper -->
<div class="wrapper wrapper-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <!-- Ibox -->
				<div class="row">
                    <div class="col-lg-12">
                        <div class="ibox bg-boxshadow mb-30">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-30">
                                <h5>Detail Penjualan Tanpa Resep <small> </small></h5>
                            </div>
							<div class="">
								<p><a href="<?php echo site_url('cprint/penjualanTnpResep/'.$idpenjualan)?>" class="btn btn-info" target="blank"><i class="fa fa-print"></i> Cetak Faktur </a>
							</div>
							<?php $idmessage = $this->session->flashdata('idmessage') ?>
							<?php $message = $this->session->flashdata('message') ?>
							<?php if ($message) { ?>
								<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
									<button data-dismiss="alert" class="close">
										&times;
									</button>
									<i class="fa fa-info-circle"></i>
									<strong><?php echo $message ?></strong>
								</div>
							<?php } ?>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Dibuat oleh: </label>
										<label class="col-sm-6 col-form-label">
											<?php echo $nmpembuat; ?>
										</label>
									</div>
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">ID Penjualan Tanpa Resep</label>
										<label class="col-sm-6 col-form-label">
											<?php echo $idpenjualan; ?>
										</label>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Tanggal Penjualan Tanpa Resep</label>
										<label class="col-sm-6 col-form-label">
											<?php echo date('d-m-Y', strtotime($tglpenjualan)); ?>
										</label>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Jumlah</label>
										<label class="col-sm-6 col-form-label">
											<?php echo $jumlah; ?>
										</label>
									</div>
																		
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Total</label>
										<label class="col-sm-6 col-form-label">
											Rp.<?php echo number_format($total, 0, ',', '.') ?>,-
										</label>
									</div>
																		
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Diskon</label>
										<label class="col-sm-6 col-form-label">
											<?php echo $diskon; ?>
										</label>
									</div>
									
									
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Keterangan</label>
										<label class="col-sm-6 col-form-label">
											<?php echo $keterangan; ?>
										</label>
									</div>
                            </div>
						</div>
                    </div>
                    
                    <!-- Item Penjualan Tanpa Resep -->
                    <div class="col-lg-12">
                        <div class="ibox bg-boxshadow mb-50">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-30">
                                <h5>Item Penjualan Tanpa Resep<small></small></h5>
                            </div>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
								<!-- Table Responsive -->
								<div class="table-responsive">
									<table class="table table-striped table-bordered table-hover">
										<thead>
											<tr>
                                                <th width="50">No</th>
												<th>Produk</th>
												<th>Jumlah</th>
												<th>Harga</th>
												<th>Diskon</th>
												<th>Subtotal</th>
											</tr>
										</thead>
										<tbody>
											<?php $no=0; ?>
											<?php foreach ($itemPenjualanTnpResep_data as $itemPenjualanTnpResep){ ?>
                                            <tr>
                                                <td><?php echo ++$no ?></td>
                                                <td><?php echo $itemPenjualanTnpResep->idproduk.' - '.$itemPenjualanTnpResep->nmproduk ?></td>
                                                <td><?php echo $itemPenjualanTnpResep->jumlah ?></td>
                                                <td><?php echo $itemPenjualanTnpResep->harga ?></td>
                                                <td><?php echo $itemPenjualanTnpResep->diskon ?></td>
                                                <td><?php echo $itemPenjualanTnpResep->subtotal ?></td>
                                            </tr>
											<?php } ?>
										</tbody>
										<tfoot>
											<tr>
                                                <th width="50">No</th>
												<th>Produk</th>
												<th>Jumlah</th>
												<th>Harga</th>
												<th>Diskon</th>
												<th>Sub Total</th>
											</tr>
										</tfoot>
									</table>
								</div>
                            </div>
						</div>
                    </div>
					
                </div>
            </div>
        </div>
    </div>
</div>

