

<!-- Breadcrumb Area -->
<div class="breadcrumb-area" style="padding:20px 5px">
	<div class="container-fluid">
		<nav aria-label="breadcrumb">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="#">Transaksi</a></li>
				<li class="breadcrumb-item"><a href="<?php echo site_url('transaksi/barangMasuk') ?>">Barang Masuk</a></li>
				<li class="breadcrumb-item active" aria-current="page">Form Barang Masuk</li>
			</ol>
		</nav>
	</div>
</div>

<!-- Wrapper -->
<div class="wrapper wrapper-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <!-- Ibox -->
				<div class="row">
                    <div class="col-lg-12">
					<!--
					<?php if ($state == 'create') { ?>
                    <div class="col-lg-12">
					<?php } elseif ($state == 'update') { ?>	
                    <div class="col-lg-6">
					<?php }  ?>	
					-->
                        <div class="ibox bg-boxshadow mb-30">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-10">
                                <h5>Form Barang Masuk<small></small></h5>
                            </div>
							<?php $idmessage = $this->session->flashdata('idmessage') ?>
							<?php $message = $this->session->flashdata('message') ?>
							<?php if ($message) { ?>
								<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
									<button data-dismiss="alert" class="close">
										&times;
									</button>
									<i class="fa fa-info-circle"></i>
									<strong><?php echo $message ?></strong>
								</div>
							<?php } ?>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
								<?php if ($state == 'create') { ?>
								<?php echo form_open_multipart($addBarangMasuk_action, "class='form-horizontal'") ?>
								<?php } elseif ($state == 'update') { ?>
								<?php echo form_open_multipart($editBarangMasuk_action, "class='form-horizontal'") ?>
								<?php echo form_hidden('idbarangmasuk', $idbarangmasuk) ?>
								<?php }  ?>									
									
									
									<div class="form-group row">
										<label class="col-sm-3 col-form-label">Tanggal Barang Masuk</label>
										<div class="input-group col-sm-3">
											<?php echo form_error('tglbarangmasuk') ?>    
											<?php
											$tglbarangmasuk_=array(
												'type'=> 'date',
												'name'=> 'tglbarangmasuk',
												'class'=>'form-control',
												'value'=>$tglbarangmasuk
											);
											?>
											<?php echo form_input($tglbarangmasuk_) ?>
                                            <div class="input-group-append">
                                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                            </div>
										</div>
										
										<label class="col-sm-3 col-form-label">Jumlah Produk</label>
										<div class="col-sm-3">
											<?php echo form_error('jumlah') ?>    
											<?php
											$jumlah_=array(
												'type'=> 'number',
												'name'=> 'jumlah',
												'disabled' => true,
												'class'=>'form-control',
												'value'=>$jumlah
											);
											?>
											<?php echo form_input($jumlah_) ?>
										</div>
									</div>
										
									<div class="form-group row">
										<label class="col-sm-3 col-form-label">Total</label>
										<div class="col-sm-3">
											<?php echo form_error('total') ?>    
											<?php
											$total_=array(
												'type'=> 'number',
												'name'=> 'total',
												'disabled' => true,
												'class'=>'form-control',
												'value'=>$total
											);
											?>
											<?php echo form_input($total_) ?>
										</div>
										
										<label class="col-sm-3 col-form-label">Supplier</label>
										<div class="col-sm-3">
											<?php
											foreach ($supplier_data as $supplier_row) {
												$option_supplier[$supplier_row->idsupplier] = $supplier_row->idsupplier.' - '.$supplier_row->nmsupplier;
											}
											echo form_dropdown('idsupplier', $option_supplier, $idsupplier, 'class="form-control selectpicker" data-style="btn-select-tag" data-live-search="true"')
											?>
										</div>
									</div>
																			
									<div class="form-group row">
										<label class="col-sm-3 col-form-label">Payment</label>
										<div class="col-sm-3">
											<?php
												$option_payment['Kontan'] = 'Kontan';
												$option_payment['Kredit'] = 'Kredit';
											echo form_dropdown('payment', $option_payment, $payment, 'class="form-control selectpicker" data-style="btn-select-tag"')
											?>
										</div>
										
										<label class="col-sm-3 col-form-label">Tanggal Jatuh Tempo</label>
										<div class="input-group col-sm-3">
											<?php echo form_error('tgljatuhtempo') ?>    
											<?php
											$tgljatuhtempo_=array(
												'type'=> 'date',
												'name'=> 'tgljatuhtempo',
												'class'=>'form-control',
												'value'=>$tgljatuhtempo
											);
											?>
											<?php echo form_input($tgljatuhtempo_) ?>
                                            <div class="input-group-append">
                                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                            </div>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-3 col-form-label">No. Faktur</label>
										<div class="col-sm-3">
											<?php echo form_error('nofaktur') ?>    
											<?php
											$nofaktur_=array(
												'type'=> 'nofaktur',
												'name'=> 'nofaktur',
												'class'=>'form-control',
												'value'=>$nofaktur
											);
											?>
											<?php echo form_input($nofaktur_) ?>
										</div>
										
										<label class="col-sm-3 col-form-label">Tanggal Faktur</label>
										<div class="input-group col-sm-3">
											<?php echo form_error('tglfaktur') ?>    
											<?php
											$tglfaktur_=array(
												'type'=> 'date',
												'name'=> 'tglfaktur',
												'class'=>'form-control',
												'value'=>$tglfaktur
											);
											?>
											<?php echo form_input($tglfaktur_) ?>
                                            <div class="input-group-append">
                                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                            </div>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-3 col-form-label">Diskon</label>
										<div class="col-sm-3">
											<?php echo form_error('diskon_atas') ?>    
											<?php
											$diskon_=array(
												'type'=> 'number',
												'name'=> 'diskon_atas',
												'class'=>'form-control',
												'value'=>$diskon_atas,
												'step'=>0.001
											);
											?>
											<?php echo form_input($diskon_) ?>
										</div>
										
										<label class="col-sm-3 col-form-label">PPN</label>
										<div class="col-sm-3">
											<?php echo form_error('ppn') ?>    
											<?php
											$ppn_=array(
												'type'=> 'number',
												'name'=> 'ppn',
												'class'=>'form-control',
												'value'=>$ppn,
												'step'=>0.001
											);
											?>
											<?php echo form_input($ppn_) ?>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-3 col-form-label">Keterangan</label>
										<div class="col-sm-9">
											<?php echo form_error('keterangan') ?>    
											<?php
											$keterangan_=array(
												'type'=> 'keterangan',
												'name'=> 'keterangan',
												'class'=>'form-control',
												'value'=>$keterangan
											);
											?>
											<?php echo form_input($keterangan_) ?>
										</div>
									</div>
									
                                    <div class="form-group mb-0 row">
                                        <div class="col-12">
											<a href="<?php echo site_url('transaksi/barangMasuk') ?>" class="btn btn-white btn-sm mr-10">Kembali</a>
                                            <button class="btn btn-info btn-sm" type="submit">Simpan</button>
                                        </div>
                                    </div>
								<?php echo form_close() ?>
                            </div>
						</div>
                    </div>
					
					
					<?php if ($state == 'update'){ ?>
					
                    <!-- Tabel Item Barang Masuk -->
                    <div class="col-lg-12" id="itembarangmasuk">
                        <div class="ibox bg-boxshadow mb-50">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-10">
                                <h5>Item Barang Masuk<small></small></h5>
                            </div>
							<?php $idmessage = $this->session->flashdata('idmessage') ?>
							<?php $message = $this->session->flashdata('message') ?>
							<?php if ($message) { ?>
								<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
									<button data-dismiss="alert" class="close">
										&times;
									</button>
									<i class="fa fa-info-circle"></i>
									<strong><?php echo $message ?></strong>
								</div>
							<?php } ?>
							
                            <!-- Ibox-content -->
							<div class="col-lg-12">
								<div class="ibox mb-10">
									
									<div class="ibox-content">
										<?php if ($item_state == 'item_create') { ?>
										<h6>Input Item Barang Masuk<small></small></h6>
										<?php echo form_open_multipart($addItemBarangMasuk_action, "class='form-horizontal'") ?>
										<?php echo form_hidden('idbarangmasuk', $idbarangmasuk); ?>
										<?php } elseif ($item_state == 'item_update') { ?>
										<h6>Edit Item Barang Masuk<small></small></h6>
										<?php echo form_open_multipart($editItemBarangMasuk_action, "class='form-horizontal'") ?>
										<?php echo form_hidden('idbarangmasuk', $idbarangmasuk); ?>
										<?php echo form_hidden('iditembarangmasuk', $iditembarangmasuk); ?>
										<?php }  ?>									
											
											<div class="form-group row">
												<label class="col-sm-3 col-form-label">Produk</label>
												<div class="col-sm-9">
													<?php
													foreach ($produk_data as $produk_row) {
														$option_produk[$produk_row->idproduk] = $produk_row->nmproduk.' - Stok: '.$produk_row->stok.' - Rp.'.number_format($produk_row->hargasatuanbeli, 0, ',', '.').',-/'.$produk_row->satuanbeli;
													}
													echo form_dropdown('idproduk', $option_produk, $idproduk, 'class="form-control selectpicker" data-style="btn-select-tag" data-live-search="true"')
													?>
												</div>
											</div>
														
											<div class="form-group row">
												<label class="col-sm-3 col-form-label">Quantity</label>
												<div class="col-sm-3">
													<?php echo form_error('jumlah_item') ?>    
													<?php
													$jumlah_item_=array(
														'type'=> 'number',
														'name'=> 'jumlah_item',
														'class'=>'form-control',
														'value'=>$jumlah_item
													);
													?>
													<?php echo form_input($jumlah_item_) ?>
												</div>
												
												<label class="col-sm-3 col-form-label">Tanggal Kadaluarsa</label>
												<div class="input-group col-sm-3">
													<?php echo form_error('tglkadaluarsa') ?>    
													<?php
													$tglkadaluarsa_=array(
														'type'=> 'date',
														'name'=> 'tglkadaluarsa',
														'class'=>'form-control',
														'value'=>$tglkadaluarsa
													);
													?>
													<?php echo form_input($tglkadaluarsa_) ?>
													<div class="input-group-append">
														<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
													</div>
												</div>
											</div>
											
											<div class="form-group mb-0 row">
												<div class="col-12">
												<?php if ($item_state == 'item_create') { ?>
													
												<?php }elseif ($item_state == 'item_update'){ ?>
													<a href="<?php echo site_url('transaksi/editBarangMasuk/'.$idbarangmasuk) ?>" class="btn btn-white btn-sm mr-10">Batal</a>
												<?php } ?>
													<button class="btn btn-info btn-sm" type="submit">Simpan</button>
												</div>
											</div>
										<?php echo form_close() ?>
									</div>
								</div>
							</div>	
                            <div class="ibox-content">
								<!-- Table Responsive -->
								<div class="table-responsive">
									<table class="table table-striped table-bordered table-hover">
										<thead>
											<tr>
                                                <th width="50">No</th>
												<th>Produk</th>
												<th>Sisa Stok</th>
												<th>Harga</th>
												<th>Jumlah</th>
												<th>Tanggal Kadaluarsa</th>
												<th>Subtotal</th>
                                                <th width="100"></th>
											</tr>
										</thead>
										<tbody>
											<?php $no=0; ?>
											<?php foreach ($itemBarangMasuk_data as $itemBarangMasuk){ ?>
                                            <tr>
                                                <td><?php echo ++$no ?></td>
                                                <td><?php echo $itemBarangMasuk->idproduk.' - '.$itemBarangMasuk->nmproduk ?></td>
                                                <td><?php echo $itemBarangMasuk->stok ?></td>
                                                <td><?php echo 'Rp'.number_format($itemBarangMasuk->harga, 0, ',', '.').',-' ?></td>
                                                <td><?php echo $itemBarangMasuk->jumlah ?></td>
                                                <td><?php echo date('d-m-Y', strtotime($itemBarangMasuk->tglkdluarsa)) ?></td>
                                                <td><?php echo 'Rp'.number_format($itemBarangMasuk->subtotal, 0, ',', '.').',-' ?></td>
                                                <td class="text-right">
													<a href="<?php echo site_url('transaksi/editItemBarangMasuk/'.$itemBarangMasuk->idbarangmasuk.'/'.$itemBarangMasuk->iditembarangmasuk.'#itembarangmasuk')?>" style="padding:5px 10px;" class="btn  btn-xs btn-outline-default" data-placement="top" data-original-title="Lihat dan Edit"> <i class="fa fa-edit fa-white"></i></a>
													<a href="<?php echo site_url('transaksi/hapusItemBarangMasuk/'.$itemBarangMasuk->idbarangmasuk.'/'.$itemBarangMasuk->iditembarangmasuk)?>" style="padding:5px 10px;" class="btn btn-xs btn-outline-default" data-placement="top" data-original-title="Hapus"
													onclick="return confirm('Hapus Barang Masuk ?')"><i class="fa fa-times fa-white"></i></a>
												</td>
                                            </tr>
											<?php } ?>
											
										</tbody>
										<tfoot>
											<tr>
												<th colspan="6" class="text-right"><b>Diskon </b></th>
												<th><b><?php echo 'Rp'.number_format($diskon_atas, 2, ',', '.').',-' ?></b></th>
                                                <th></th>
											</tr>
											<tr>
												<th colspan="6" class="text-right"><b>Total (PPN: <?php echo $ppn; ?>%) </b></th>
												<th><b><?php echo 'Rp'.number_format($total, 2, ',', '.').',-' ?></b></th>
                                                <th></th>
											</tr>
										</tfoot>
									</table>
								</div>
                            </div>
						</div>
                    </div>
					<?php } ?>						
					
					
                </div>
            </div>
        </div>
    </div>
</div>

