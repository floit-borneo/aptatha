

                <!-- Breadcrumb Area -->
                <div class="breadcrumb-area" style="padding:20px 5px">
                    <div class="container-fluid">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Transaksi</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Daftar Penjualan Dengan Resep</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox bg-boxshadow">
                                    <div class="ibox-title mb-10">
                                        <h5>Daftar Penjualan Dengan Resep</h5>
                                    </div>
									<?php $idmessage = $this->session->flashdata('idmessage') ?>
									<?php $message = $this->session->flashdata('message') ?>
									<?php if ($message) { ?>
										<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
											<button data-dismiss="alert" class="close">
												&times;
											</button>
											<i class="fa fa-info-circle"></i>
											<strong><?php echo $message ?></strong>
										</div>
									<?php } ?>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											<div class="">
												<p><a href="<?php echo site_url('transaksi/addPenjualanDgnResep') ?>" class="btn btn-info"><i class="fa fa-plus"></i> Penjualan Dengan Resep Baru </a>
											</div>
											<?php $no=0; ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-full-penjualanDgnResep">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Penjualan</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Tanggal Penjualan</th>
                                                        <th>Jumlah Produk</th>
                                                        <th>Total</th>
                                                        <th width="240"></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($penjualanDgnResep_data as $penjualanDgnResep){ ?>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td><?php echo $penjualanDgnResep->idpenjualan ?></td>
                                                        <td><?php echo $penjualanDgnResep->nmpembuat ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($penjualanDgnResep->tglpenjualan)); ?></td>
                                                        <td><?php echo $penjualanDgnResep->jumlah ?></td>
														<td><?php echo 'Rp.'.number_format($penjualanDgnResep->total, 0, ',', '.').',-' ?></td>
                                                        <td width="240" class="text-right">
															<a href="<?php echo site_url('cprint/penjualanDgnResep/'.$penjualanDgnResep->idpenjualan)?>" target="blank" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Lihat"><i class="fa fa-print fa-white"></i></a>
															<a href="<?php echo site_url('transaksi/viewPenjualanDgnResep/'.$penjualanDgnResep->idpenjualan)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Lihat"><i class="fa fa-eye fa-white"></i></a>
															<a href="<?php echo site_url('transaksi/editPenjualanDgnResep/'.$penjualanDgnResep->idpenjualan)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Edit"><i class="fa fa-edit fa-white"></i></a>
															<a href="<?php echo site_url('transaksi/hapusPenjualanDgnResep/'.$penjualanDgnResep->idpenjualan)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Hapus"
															   onclick="return confirm('Hapus Penjualan?')"><i class="fa fa-times fa-white"></i></a>
														</td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Penjualan</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Tanggal Penjualan</th>
                                                        <th>Jumlah Produk</th>
                                                        <th>Total</th>
                                                        <th width="240"></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
