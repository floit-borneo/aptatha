

<!-- Breadcrumb Area -->
<div class="breadcrumb-area" style="padding:20px 5px">
	<div class="container-fluid">
		<nav aria-label="breadcrumb">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="#">Transaksi</a></li>
				<li class="breadcrumb-item"><a href="<?php echo site_url('transaksi/penjualanDgnResep') ?>">Penjualan Dengan Racikan</a></li>
				<li class="breadcrumb-item active" aria-current="page">Form Penjualan Dengan Resep</li>
			</ol>
		</nav>
	</div>
</div>

<!-- Wrapper -->
<div class="wrapper wrapper-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <!-- Ibox -->
				<div class="row">
					<?php if ($state == 'create'){ ?>
                    <div class="col-lg-12">
					<?php } elseif ($state == 'update') { ?>
					<div class="col-lg-12">
					<?php } ?>
                        <div class="ibox bg-boxshadow mb-30">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-10">
                                <h5>Form Penjualan Dengan Racikan<small></small></h5>
                            </div>
							<?php $idmessage = $this->session->flashdata('idmessage') ?>
							<?php $message = $this->session->flashdata('message') ?>
							<?php if ($message) { ?>
								<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
									<button data-dismiss="alert" class="close">
										&times;
									</button>
									<i class="fa fa-info-circle"></i>
									<strong><?php echo $message ?></strong>
								</div>
							<?php } ?>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
								<?php if ($state == 'create') { ?>
								<?php echo form_open_multipart($addPenjualanDgnResep_action, "class='form-horizontal'") ?>
								<?php } elseif ($state == 'update') { ?>
								<?php echo form_open_multipart($editPenjualanDgnResep_action, "class='form-horizontal'") ?>
								<?php echo form_hidden('idpenjualan', $idpenjualan) ?>
								<?php }  ?>									
									
									
									<div class="form-group row">
										<label class="col-sm-3 col-form-label">Tanggal Penjualan</label>
										<div class="input-group col-sm-3">
											<?php echo form_error('tglpenjualan') ?>    
											<?php
											$tglpenjualan_=array(
												'type'=> 'date',
												'name'=> 'tglpenjualan',
												'class'=>'form-control',
												'value'=>$tglpenjualan
											);
											?>
											<?php echo form_input($tglpenjualan_) ?>
                                            <div class="input-group-append">
                                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                            </div>
										</div>
										
										<label class="col-sm-3 col-form-label">Jumlah Racikan</label>
										<div class="col-sm-3">
											<?php echo form_error('jumlah') ?>    
											<?php
											$jumlah_=array(
												'type'=> 'number',
												'name'=> 'jumlah',
												'disabled'=>true,
												'class'=>'form-control',
												'value'=>$jumlah
											);
											?>
											<?php echo form_input($jumlah_) ?>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-3 col-form-label">Total</label>
										<div class="col-sm-3">
											<?php echo form_error('total') ?>    
											<?php
											$total_=array(
												'type'=> 'number',
												'name'=> 'total',
												'disabled'=>true,
												'class'=>'form-control',
												'value'=>$total
											);
											?>
											<?php echo form_input($total_) ?>
										</div>
										
										<label class="col-sm-3 col-form-label">Diskon</label>
										<div class="col-sm-3">
											<?php echo form_error('diskon') ?>    
											<?php
											$diskon_=array(
												'type'=> 'number',
												'name'=> 'diskon',
												'class'=>'form-control',
												'value'=>$diskon
											);
											?>
											<?php echo form_input($diskon_) ?>
										</div>
									</div>
									
									
									<div class="form-group row">
										<label class="col-sm-3 col-form-label">Dokter</label>
										<div class="col-sm-3">
											<?php echo form_error('dokter') ?>    
											<?php
											$dokter_=array(
												'type'=> 'text',
												'name'=> 'dokter',
												'class'=>'form-control',
												'value'=>$dokter
											);
											?>
											<?php echo form_input($dokter_) ?>
										</div>
										
										<label class="col-sm-3 col-form-label">Keterangan</label>
										<div class="col-sm-3">
											<?php echo form_error('keterangan') ?>    
											<?php
											$keterangan_=array(
												'type'=> 'keterangan',
												'name'=> 'keterangan',
												'class'=>'form-control',
												'value'=>$keterangan
											);
											?>
											<?php echo form_input($keterangan_) ?>
										</div>
									</div>
									
                                    <div class="form-group mb-0 row">
                                        <div class="col-12">
											<a href="<?php echo site_url('transaksi/penjualanDgnResep') ?>" class="btn btn-white btn-sm mr-10">Kembali</a>
                                            <button class="btn btn-info btn-sm" type="submit">Simpan</button>
                                        </div>
                                    </div>
								<?php echo form_close() ?>
                            </div>
						</div>
                    </div>
					
					<?php if ($state == 'update'){ ?>
                    <!-- Deatil Item Penjualan Dengan Racikan -->
					<div class="col-lg-12">
						<div class="ibox bg-boxshadow wrapper wrapper-content mb-30">
							<div class="container-fluid">
								<div class="row">
									<?php if ($nonracikan_state!='nonracikan_update') {?>
									<div class="col-6">
									<?php } ?>
										<div class="appwork-faq-area">
											<dl style="margin-bottom:0;">
												<?php if ($nonracikan_state!='nonracikan_update') {?>
												<dt>Form Racikan Baru</dt>
												<dd>
														<!-- Ibox-content -->
														<div class="mb-30">
														</div>
														<div class="col-lg-12">
															<?php if ($racikan_state == 'racikan_create') { ?>
															<?php echo form_open_multipart($addRacikan_action, "class='form-horizontal'") ?>
															<?php echo form_hidden('idpenjualan', $idpenjualan); ?>
															<?php } elseif ($racikan_state == 'racikan_update') { ?>
															<?php echo form_open_multipart($editRacikan_action, "class='form-horizontal'") ?>
															<?php echo form_hidden('idpenjualan', $idpenjualan); ?>
															<?php echo form_hidden('idracikan', $idracikan); ?>
															<?php }  ?>									
																										
															<div class="form-group row">
																<label class="col-sm-6 col-form-label">Jumlah Kapsul</label>
																<div class="col-sm-6">
																	<?php echo form_error('jumlah_caps_racikan') ?>    
																		<?php
																		$jumlah_caps_racikan_=array(
																			'type'=> 'number',
																			'name'=> 'jumlah_caps_racikan',
																			'class'=>'form-control',
																			'value'=>$jumlah_caps_racikan
																		);
																		?>
																	<?php echo form_input($jumlah_caps_racikan_) ?>
																</div>
															</div>
																				
															<div class="form-group row">			
																<label class="col-sm-6 col-form-label">Jumlah Produk</label>
																<div class="col-sm-6">
																	<?php echo form_error('jumlah_produk_racikan') ?>    
																	<?php
																		$jumlah_produk_racikan_=array(
																			'type'=> 'number',
																			'id' => 'harga_item',
																			'name'=> 'jumlah_produk_racikan',
																			'class'=>'form-control',
																			'disabled'=>true,
																			'value'=>$jumlah_produk_racikan
																		);
																	?>
																	<?php echo form_input($jumlah_produk_racikan_) ?>
																</div>
															</div>
																								
															<div class="form-group row">
																<label class="col-sm-6 col-form-label">Total Tuslah</label>
																<div class="col-sm-6">
																	<?php echo form_error('tuslah_racikan') ?>    
																	<?php
																		$tuslah_racikan_=array(
																			'type'=> 'number',
																			'name'=> 'tuslah_racikan',
																			'class'=>'form-control',
																			'value'=>$tuslah_racikan
																		);
																	?>
																	<?php echo form_input($tuslah_racikan_) ?>
																</div>
															</div>
																				
															<div class="form-group row">			
																<label class="col-sm-6 col-form-label">Subtotal</label>
																<div class="col-sm-6">
																	<?php echo form_error('subtotal_racikan') ?>    
																	<?php
																		$subtotal_racikan_=array(
																			'type'=> 'number',
																			'name'=> 'subtotal_racikan',
																			'class'=>'form-control',
																			'disabled'=>true,
																			'value'=>$subtotal_racikan
																		);
																	?>
																	<?php echo form_input($subtotal_racikan_) ?>
																</div>
															</div>
																						
															<div class="form-group mb-0 row">
																<div class="col-sm-12">
																	<button class="btn btn-info btn-sm" type="submit">Simpan</button>
																</div>
															</div>
															<?php echo form_close() ?>
														</div>
												</dd>
												<?php } ?>

											</dl>
										</div>
									</div>
									<?php if ($nonracikan_state!='nonracikan_update') {?>
									<div class="col-6">
									<?php } else { ?>
									<div class="col-12">
									<?php } ?>
										<div class="appwork-faq-area">
											<dl style="margin-bottom:0;">
												<dt>Form Item Non Racikan Baru</dt>
												<dd id="itemnonracikan">
														<!-- Ibox-content -->
														<div class="mb-30">
														</div>
														<div class="col-lg-12">
															<?php if ($nonracikan_state == 'nonracikan_create') { ?>
															<?php echo form_open_multipart($addNonRacikan_action, "class='form-horizontal'") ?>
															<?php echo form_hidden('idpenjualan', $idpenjualan); ?>
															<?php } elseif ($nonracikan_state == 'nonracikan_update') { ?>
															<?php echo form_open_multipart($editNonRacikan_action, "class='form-horizontal'") ?>
															<?php echo form_hidden('idpenjualan', $idpenjualan); ?>
															<?php echo form_hidden('iditemresep', $iditemresep); ?>
															<?php echo form_hidden('iditemracikan', $iditemracikan); ?>
															<?php }  ?>					
															<div class="form-group row">							
																<label class="col-sm-6 col-form-label">Produk</label>
																<div class="col-sm-6">
																	<?php
																		foreach ($produk_data as $produk_row) {
																			$option_produk[$produk_row->idproduk] = $produk_row->nmproduk.' - Sisa stok: '.$produk_row->stok.' - Rp.'.number_format($produk_row->hargasatuanjual, 0, ',', '.').',-/'.$produk_row->satuanjual;
																		}
																		echo form_dropdown('idproduk', $option_produk, $idproduk, 'class="form-control selectpicker" data-style="btn-select-tag" data-live-search="true" onchange="getHarga()"')
																	?>
																</div>
															</div>
																				
															<div class="form-group row">	
																<label class="col-sm-6 col-form-label">Quantity</label>
																<div class="col-sm-6">
																	<?php echo form_error('jumlah_caps_non') ?>    
																	<?php
																		$jumlah_caps_non_=array(
																			'type'=> 'number',
																			'name'=> 'jumlah_caps_non',
																			'class'=>'form-control',
																			'value'=>$jumlah_caps_non
																		);
																	?>
																	<?php echo form_input($jumlah_caps_non_) ?>
																</div>
															</div>
																							
															<div class="form-group row">
																<label class="col-sm-6 col-form-label">Harga Jual</label>
																<div class="col-sm-6">
																	<?php echo form_error('harga_item_non') ?>    
																	<?php
																		$harga_item_non_=array(
																			'type'=> 'number',
																			'id' => 'harga_item_non',
																			'name'=> 'harga_item_non',
																			'class'=>'form-control',
																			'disabled'=>true,
																			'value'=>$harga_item_non
																		);
																	?>
																	<?php echo form_input($harga_item_non_) ?>
																</div>
															</div>
																				
															<div class="form-group row">			
																<label class="col-sm-6 col-form-label">Subtotal</label>
																<div class="col-sm-6">
																	<?php echo form_error('subtotal_non') ?>    
																	<?php
																		$subtotal_non_=array(
																			'type'=> 'number',
																			'name'=> 'subtotal_non',
																			'class'=>'form-control',
																			'disabled'=>true,
																			'value'=>$subtotal_non
																		);
																	?>
																	<?php echo form_input($subtotal_non_) ?>
																</div>
															</div>
																						
															<div class="form-group mb-0 row">
																<div class="col-sm-12">
																	<?php if ($nonracikan_state == 'nonracikan_create') { ?>
																								
																	<?php }elseif ($nonracikan_state == 'nonracikan_update'){ ?>
																	<a href="<?php echo site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan) ?>" class="btn btn-white btn-sm mr-10">Batal</a>
																	<?php } ?>
																	<button class="btn btn-info btn-sm" type="submit">Simpan</button>
																</div>
															</div>
															<?php echo form_close() ?>
														</div>

												</dd>
											</dl>
										</div>
									</div>									
								</div>
							</div>
						</div>
						<div class="col-lg-12" id="racikan">
						</div>	
						<div class="col-lg-12">
							
						</div>	
					</div>
                    <!-- Tabel Item Penjualan Dengan Racikan -->
                    <div class="col-lg-12" id="#tabelitempenjualandgnresep">
                        <div class="ibox bg-boxshadow mb-50">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-30">
                                <h5>Daftar Item<small></small></h5>
                            </div>
							<?php $idmessage = $this->session->flashdata('idmessage') ?>
							<?php $message = $this->session->flashdata('message') ?>
							<?php if ($message) { ?>
								<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
									<button data-dismiss="alert" class="close">
										&times;
									</button>
									<i class="fa fa-info-circle"></i>
									<strong><?php echo $message ?></strong>
								</div>
							<?php } ?>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
								<!-- Table Responsive -->
								<div class="table-responsive">
									<table class="table table-striped table-bordered table-hover">
										<thead>
											<tr>
                                                <th width="50">No</th>
												<th>Tipe</th>
												<th>Nama Produk</th>
												<th>Jumlah</th>
												<th>Subtotal</th>
                                                <th width="130"></th>
											</tr>
										</thead>
										<tbody>
											<?php $no=0; ?>
											<?php foreach ($itemracikan_data as $item){ ?>
                                            <tr>
                                                <td><?php echo ++$no ?></td>
                                                <td><?php echo $item->id ?></td>
                                                <td><?php echo $item->produk ?></td>
                                                <td><?php echo $item->jumlah ?></td>
                                                <td><?php echo 'Rp.'.number_format($item->subtotal, 0, ',', '.').',-' ?></td>
                                                <td width="130" class="text-right">
												<?php if ($item->tiperesep == 'Non Racikan'){ ?>
												
												<?php }elseif ($item->tiperesep == 'Racikan'){ ?>
												
													<a href="<?php echo site_url('transaksi/addItemRacikan/'.$item->idpenjualan.'#itemracikan')?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Edit"><i class="fa fa-plus fa-white"></i></a>
													
												<?php }elseif ($item->tipe == 'Non Racikan'){ ?>
												
													<a href="<?php echo site_url('transaksi/editItemNonRacikan/'.$item->idpenjualan.'#itemracikan')?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Edit"><i class="fa fa-edit fa-white"></i></a>
													<a href="<?php echo site_url('transaksi/hapusItemNonRacikan/'.$item->idpenjualan) ?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Hapus"
															   onclick="return confirm('Hapus Penjualan Dengan Racikan ?')"><i class="fa fa-times fa-white"></i></a>
												<?php }else { ?>
												
													<a href="<?php echo site_url('transaksi/editItemRacikan/'.$item->idpenjualan.'#itemnonracikan')?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Edit"><i class="fa fa-edit fa-white"></i></a>
													<a href="<?php echo site_url('transaksi/hapusItemRacikan/'.$item->idpenjualan) ?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Hapus"
															   onclick="return confirm('Hapus Penjualan Dengan Racikan ?')"><i class="fa fa-times fa-white"></i></a>
												<?php } ?>
												</td>
                                            </tr>
											<?php } ?>
										</tbody>
										<tfoot>
											<tr>
                                                <th width="50">No</th>
												<th>Tipe</th>
												<th>Nama Produk</th>
												<th>Jumlah</th>
												<th>Subtotal</th>
                                                <th width="130"></th>
											</tr>
										</tfoot>
									</table>
								</div>
                            </div>
						</div>
                    </div>
					<?php } ?>						
					
					
					
                </div>
            </div>
        </div>
    </div>
</div>
