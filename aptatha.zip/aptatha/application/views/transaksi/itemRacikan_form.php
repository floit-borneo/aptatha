

<!-- Breadcrumb Area -->
<div class="breadcrumb-area" style="padding:20px 5px">
	<div class="container-fluid">
		<nav aria-label="breadcrumb">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="#">Transaksi</a></li>
				<li class="breadcrumb-item"><a href="<?php echo site_url('transaksi/penjualanDgnResep') ?>">Penjualan Dengan Resep</a></li>
				<li class="breadcrumb-item active" aria-current="page">Form Penjualan Dengan Resep</li>
			</ol>
		</nav>
	</div>
</div>

<!-- Wrapper -->
<div class="wrapper wrapper-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <!-- Ibox -->
				<div class="row">
                    					
					
					<?php if ($racikan_state == 'racikan_update'){ ?>
                    <!-- Deatil Item Penjualan Dengan Racikan -->
                    <div class="col-lg-6" id="racikan">
                        <div class="ibox bg-boxshadow mb-50">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-30">
                                <h5>Form Racikan<small> <?php echo $idpenjualan.' - '.$iditemresep ?></small></h5>
                            </div>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
								<?php if ($racikan_state == 'racikan_create') { ?>
								<?php echo form_open_multipart($addRacikan_action, "class='form-horizontal'") ?>
								<?php echo form_hidden('idpenjualan', $idpenjualan); ?>
								<?php } elseif ($racikan_state == 'racikan_update') { ?>
								<?php echo form_open_multipart($editRacikan_action, "class='form-horizontal'") ?>
								<?php echo form_hidden('idpenjualan', $idpenjualan); ?>
								<?php echo form_hidden('iditemresep', $iditemresep); ?>
								<?php }  ?>									

									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Jumlah Kapsul</label>
										<div class="col-sm-6">
											<?php echo form_error('jumlah_caps_racikan') ?>    
											<?php
											$jumlah_caps_racikan_=array(
												'type'=> 'number',
												'name'=> 'jumlah_caps_racikan',
												'class'=>'form-control',
												'value'=>$jumlah_caps_racikan
											);
											?>
											<?php echo form_input($jumlah_caps_racikan_) ?>
										</div>
									</div>		
									
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Jumlah Produk</label>
										<div class="col-sm-6">
											<?php echo form_error('jumlah_produk_racikan') ?>    
											<?php
											$jumlah_produk_racikan_=array(
												'type'=> 'number',
												'name'=> 'jumlah_produk_racikan',
												'class'=>'form-control',
												'value'=>$jumlah_produk_racikan
											);
											?>
											<?php echo form_input($jumlah_produk_racikan_) ?>
										</div>
									</div>
													
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Total Tuslah</label>
										<div class="col-sm-6">
											<?php echo form_error('tuslah_racikan') ?>    
											<?php
											$tuslah_racikan_=array(
												'type'=> 'number',
												'name'=> 'tuslah_racikan',
												'class'=>'form-control',
												'value'=>$tuslah_racikan
											);
											?>
											<?php echo form_input($tuslah_racikan_) ?>
										</div>
									</div>
														
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Subtotal</label>
										<div class="col-sm-6">
											<?php echo form_error('subtotal_racikan') ?>    
											<?php
											$subtotal_racikan_=array(
												'type'=> 'number',
												'name'=> 'subtotal_racikan',
												'class'=>'form-control',
												'disabled'=> true,
												'value'=>$subtotal_racikan
											);
											?>
											<?php echo form_input($subtotal_racikan_) ?>
										</div>
									</div>
									
                                    <div class="form-group mb-0 row">
                                        <div class="col-12">
											<a href="<?php echo site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan) ?>" class="btn btn-white btn-sm mr-10">Kembali</a>
                                            <button class="btn btn-info btn-sm" type="submit">Simpan</button>
                                        </div>
                                    </div>
								<?php echo form_close() ?>
                            </div>
						</div>
					</div>	
					
					
                    <!-- Form Item Racikan -->
					<div class="col-lg-6">
                        <div class="ibox bg-boxshadow mb-50">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-30">
                                <h5>Form Item Racikan<small></small></h5>
                            </div>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
								<?php if ($item_state == 'item_create') { ?>
								<?php echo form_open_multipart($addItemRacikan_action, "class='form-horizontal'") ?>
								<?php echo form_hidden('idpenjualan', $idpenjualan); ?>
								<?php echo form_hidden('iditemresep', $iditemresep); ?>
								<?php } elseif ($item_state == 'item_update') { ?>
								<?php echo form_open_multipart($editItemRacikan_action, "class='form-horizontal'") ?>
								<?php echo form_hidden('idpenjualan', $idpenjualan); ?>
								<?php echo form_hidden('iditemresep', $iditemresep); ?>
								<?php echo form_hidden('iditemracikan', $iditemracikan); ?>
								<?php }  ?>									
									
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Produk</label>
										<div class="col-sm-6">
											<?php
											foreach ($produk_data as $produk_row) {
												$option_produk[$produk_row->idproduk] = $produk_row->nmproduk.' - Sisa stok: '.$produk_row->stok.' - Rp.'.number_format($produk_row->hargasatuanjual, 0, ',', '.').',-/'.$produk_row->satuanjual;
											}
											echo form_dropdown('idproduk', $option_produk, $idproduk, 'class="form-control selectpicker" data-style="btn-select-tag" data-live-search="true" onchange="getHarga()"')
											?>
										</div>
									</div>
												
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Quantity</label>
										<div class="col-sm-6">
											<?php echo form_error('jumlah_item') ?>    
											<?php
											$jumlah_item_=array(
												'type'=> 'number',
												'name'=> 'jumlah_item',
												'class'=>'form-control',
												'value'=>$jumlah_item
											);
											?>
											<?php echo form_input($jumlah_item_) ?>
										</div>
									</div>
										
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Harga Jual</label>
										<div class="col-sm-6">
											<?php echo form_error('harga_item') ?>    
											<?php
											$harga_item_=array(
												'type'=> 'number',
												'id' => 'harga_item',
												'name'=> 'harga_item',
												'class'=>'form-control',
												'disabled'=> true,
												'value'=>$harga_item
											);
											?>
											<?php echo form_input($harga_item_) ?>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Subtotal</label>
										<div class="col-sm-6">
											<?php echo form_error('subtotal_item') ?>    
											<?php
											$subtotal_item_=array(
												'type'=> 'number',
												'name'=> 'subtotal_item',
												'class'=>'form-control',
												'disabled'=>true,
												'value'=>$subtotal_item
											);
											?>
											<?php echo form_input($subtotal_item_) ?>
										</div>
									</div>
									
									
                                    <div class="form-group mb-0 row">
                                        <div class="col-12">			
											<?php if ($item_state == 'item_update'){ ?>
												<a href="<?php echo site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan) ?>" class="btn btn-white btn-sm mr-10">Kembali</a>
											<?php } else if($item_state == 'item_create'){ ?>
											<?php } ?>
                                            <button class="btn btn-info btn-sm" type="submit">Simpan</button>
                                        </div>
                                    </div>
								<?php echo form_close() ?>
                            </div>
						</div>
					</div>	
					
                    <!-- Tabel Item Penjualan Dengan Racikan -->
                    <div class="col-lg-12" id="#tabelitemracikan">
                        <div class="ibox bg-boxshadow mb-50">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-30">
                                <h5>Daftar Racikan<small></small></h5>
                            </div>
							<?php $idmessage = $this->session->flashdata('idmessage') ?>
							<?php $message = $this->session->flashdata('message') ?>
							<?php if ($message) { ?>
								<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
									<button data-dismiss="alert" class="close">
										&times;
									</button>
									<i class="fa fa-info-circle"></i>
									<strong><?php echo $message ?></strong>
								</div>
							<?php } ?>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
								<!-- Table Responsive -->
								<div class="table-responsive">
									<table class="table table-striped table-bordered table-hover">
										<thead>
											<tr>
                                                <th width="50">No</th>
												<th>Produk</th>
												<th>Jumlah</th>
												<th>Harga</th>
												<th>Subtotal</th>
                                                <th width="130"></th>
											</tr>
										</thead>
										<tbody>
											<?php $no=0; ?>
											<?php foreach ($itemracikan_data as $itemracikan){ ?>
                                            <tr>
                                                <td><?php echo ++$no ?></td>
                                                <td><?php echo $itemracikan->nmproduk ?></td>
                                                <td><?php echo $itemracikan->jumlah ?></td>
                                                <td><?php echo 'Rp.'.number_format($itemracikan->harga, 0, ',', '.').',-' ?></td>
                                                <td><?php echo 'Rp.'.number_format($itemracikan->subtotal, 0, ',', '.').',-' ?></td>
                                                <td width="130" class="text-right">
													<a href="<?php echo site_url('transaksi/editItemRacikan/'.$idpenjualan.'/'.$itemracikan->iditemresep.'/'.$itemracikan->iditemracikan.'#itemracikan')?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Edit"><i class="fa fa-edit fa-white"></i></a>
													<a href="<?php echo site_url('transaksi/hapusItemRacikan/'.$idpenjualan.'/'.$itemracikan->iditemresep.'/'.$itemracikan->iditemracikan)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Hapus"
															   onclick="return confirm('Hapus Item Racikan ?')"><i class="fa fa-times fa-white"></i></a>
												</td>
                                            </tr>
											<?php } ?>
										</tbody>
										<tfoot>
											<tr>
                                                <th width="50">No</th>
												<th>Produk</th>
												<th>Jumlah</th>
												<th>Harga</th>
												<th>Sub Total</th>
                                                <th width="130"></th>
											</tr>
										</tfoot>
									</table>
								</div>
                            </div>
						</div>
                    </div>
					<?php } ?>						
					
					
					
                </div>
            </div>
        </div>
    </div>
</div>
