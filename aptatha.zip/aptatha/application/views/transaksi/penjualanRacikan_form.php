

<!-- Breadcrumb Area -->
<div class="breadcrumb-area" style="padding:20px 5px">
	<div class="container-fluid">
		<nav aria-label="breadcrumb">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="#">Transaksi</a></li>
				<li class="breadcrumb-item"><a href="<?php echo site_url('transaksi/penjualanRacikan') ?>">Penjualan Dengan Racikan</a></li>
				<li class="breadcrumb-item active" aria-current="page">Form Penjualan Dengan Racikan</li>
			</ol>
		</nav>
	</div>
</div>

<!-- Wrapper -->
<div class="wrapper wrapper-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <!-- Ibox -->
				<div class="row">
					<?php if ($state == 'create'){ ?>
                    <div class="col-lg-12">
					<?php } elseif ($state == 'update') { ?>
					<div class="col-lg-6">
					<?php } ?>
                        <div class="ibox bg-boxshadow mb-50">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-30">
                                <h5>Form Penjualan Dengan Racikan<small></small></h5>
                            </div>
							<?php $idmessage = $this->session->flashdata('idmessage') ?>
							<?php $message = $this->session->flashdata('message') ?>
							<?php if ($message) { ?>
								<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
									<button data-dismiss="alert" class="close">
										&times;
									</button>
									<i class="fa fa-info-circle"></i>
									<strong><?php echo $message ?></strong>
								</div>
							<?php } ?>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
								<?php if ($state == 'create') { ?>
								<?php echo form_open_multipart($addPenjualanRacikan_action, "class='form-horizontal'") ?>
								<?php } elseif ($state == 'update') { ?>
								<?php echo form_open_multipart($editPenjualanRacikan_action, "class='form-horizontal'") ?>
								<?php echo form_hidden('idpenjualan', $idpenjualan) ?>
								<?php }  ?>									
									
									
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Tanggal Penjualan Dengan Racikan</label>
										<div class="input-group col-sm-6">
											<?php echo form_error('tglpenjualan') ?>    
											<?php
											$tglpenjualan_=array(
												'type'=> 'date',
												'name'=> 'tglpenjualan',
												'class'=>'form-control',
												'value'=>$tglpenjualan
											);
											?>
											<?php echo form_input($tglpenjualan_) ?>
                                            <div class="input-group-append">
                                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                            </div>
										</div>
									</div>
												
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Jumlah Racikan</label>
										<div class="col-sm-6">
											<?php echo form_error('jumlah') ?>    
											<?php
											$jumlah_=array(
												'type'=> 'number',
												'name'=> 'jumlah',
												'disabled'=>true,
												'class'=>'form-control',
												'value'=>$jumlah
											);
											?>
											<?php echo form_input($jumlah_) ?>
										</div>
									</div>
										
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Total Kapsul</label>
										<div class="col-sm-6">
											<?php echo form_error('total_caps') ?>    
											<?php
											$total_caps_=array(
												'type'=> 'number',
												'name'=> 'total_caps',
												'disabled'=>true,
												'class'=>'form-control',
												'value'=>$total_caps
											);
											?>
											<?php echo form_input($total_caps_) ?>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Total</label>
										<div class="col-sm-6">
											<?php echo form_error('total') ?>    
											<?php
											$total_=array(
												'type'=> 'number',
												'name'=> 'total',
												'disabled'=>true,
												'class'=>'form-control',
												'value'=>$total
											);
											?>
											<?php echo form_input($total_) ?>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Diskon</label>
										<div class="col-sm-6">
											<?php echo form_error('diskon') ?>    
											<?php
											$diskon_=array(
												'type'=> 'number',
												'name'=> 'diskon',
												'class'=>'form-control',
												'value'=>$diskon
											);
											?>
											<?php echo form_input($diskon_) ?>
										</div>
									</div>
									
									
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Dokter</label>
										<div class="col-sm-6">
											<?php
											foreach ($dokter_data as $dokter_row) {
												$option_dokter[$dokter_row->iddokter] = $dokter_row->nmdokter.' - '.$dokter_row->nmspesialisasi.' - Rp.'.number_format($dokter_row->komisi, 0, ',', '.').',-';
											}
											echo form_dropdown('iddokter', $option_dokter, $iddokter, 'class="form-control selectpicker" data-style="btn-select-tag" data-live-search="true"')
											?>
										</div>
									</div>
										
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Keterangan</label>
										<div class="col-sm-6">
											<?php echo form_error('keterangan') ?>    
											<?php
											$keterangan_=array(
												'type'=> 'keterangan',
												'name'=> 'keterangan',
												'class'=>'form-control',
												'value'=>$keterangan
											);
											?>
											<?php echo form_textarea($keterangan_) ?>
										</div>
									</div>
									
                                    <div class="form-group mb-0 row">
                                        <div class="col-12">
											<a href="<?php echo site_url('transaksi/penjualanRacikan') ?>" class="btn btn-white btn-sm mr-10">Kembali</a>
                                            <button class="btn btn-info btn-sm" type="submit">Simpan</button>
                                        </div>
                                    </div>
								<?php echo form_close() ?>
                            </div>
						</div>
                    </div>
					
					
					<?php if ($state == 'update'){ ?>
                    <!-- Deatil Item Penjualan Dengan Racikan -->
                    <div class="col-lg-6" id="racikan">
                        <div class="ibox bg-boxshadow mb-50">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-30">
                                <h5>Form Racikan Baru<small></small></h5>
                            </div>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
								<?php if ($racikan_state == 'racikan_create') { ?>
								<?php echo form_open_multipart($addRacikan_action, "class='form-horizontal'") ?>
								<?php echo form_hidden('idpenjualan', $idpenjualan); ?>
								<?php } elseif ($racikan_state == 'racikan_update') { ?>
								<?php echo form_open_multipart($editRacikan_action, "class='form-horizontal'") ?>
								<?php echo form_hidden('idpenjualan', $idpenjualan); ?>
								<?php echo form_hidden('idracikan', $idracikan); ?>
								<?php }  ?>									
																		
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Jumlah Kapsul</label>
										<div class="col-sm-6">
											<?php echo form_error('jumlah_kapsul') ?>    
											<?php
											$jumlah_kapsul_=array(
												'type'=> 'text',
												'name'=> 'jumlah_kapsul',
												'class'=>'form-control',
												'value'=>$jumlah_kapsul
											);
											?>
											<?php echo form_input($jumlah_kapsul_) ?>
										</div>
									</div>		
									
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Jumlah Produk</label>
										<div class="col-sm-6">
											<?php echo form_error('jumlah_produk') ?>    
											<?php
											$jumlah_produk_=array(
												'type'=> 'number',
												'name'=> 'jumlah_produk',
												'class'=>'form-control',
												'value'=>$jumlah_produk
											);
											?>
											<?php echo form_input($jumlah_produk_) ?>
										</div>
									</div>
																		
									<div class="form-group row">
										<label class="col-sm-6 col-form-label">Subtotal</label>
										<div class="col-sm-6">
											<?php echo form_error('subtotal_racikan') ?>    
											<?php
											$subtotal_racikan_=array(
												'type'=> 'number',
												'name'=> 'subtotal_racikan',
												'class'=>'form-control',
												'disabled'=> true,
												'value'=>$subtotal_racikan
											);
											?>
											<?php echo form_input($subtotal_racikan_) ?>
										</div>
									</div>
									
                                    <div class="form-group mb-0 row">
                                        <div class="col-12">
											<a href="<?php echo site_url('transaksi/penjualanRacikan') ?>" class="btn btn-white btn-sm mr-10">Kembali</a>
                                            <button class="btn btn-info btn-sm" type="submit">Simpan</button>
                                        </div>
                                    </div>
								<?php echo form_close() ?>
                            </div>
						</div>
					</div>	
					
                    <!-- Tabel Item Penjualan Dengan Racikan -->
                    <div class="col-lg-6" id="#tabelitempenjualannonracikan">
                        <div class="ibox bg-boxshadow mb-50">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-30">
                                <h5>Daftar Racikan<small></small></h5>
                            </div>
							<?php $idmessage = $this->session->flashdata('idmessage') ?>
							<?php $message = $this->session->flashdata('message') ?>
							<?php if ($message) { ?>
								<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
									<button data-dismiss="alert" class="close">
										&times;
									</button>
									<i class="fa fa-info-circle"></i>
									<strong><?php echo $message ?></strong>
								</div>
							<?php } ?>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
								<!-- Table Responsive -->
								<div class="table-responsive">
									<table class="table table-striped table-bordered table-hover">
										<thead>
											<tr>
                                                <th width="50">No</th>
												<th>Jumlah Kapsul</th>
												<th>Jumlah Produk</th>
												<th>Subtotal</th>
                                                <th width="130"></th>
											</tr>
										</thead>
										<tbody>
											<?php $no=0; ?>
											<?php foreach ($racikan_data as $racikan){ ?>
                                            <tr>
                                                <td><?php echo ++$no ?></td>
                                                <td><?php echo $racikan->jumlah_kapsul ?></td>
                                                <td><?php echo $racikan->jumlah_produk ?></td>
                                                <td><?php echo 'Rp.'.number_format($racikan->subtotal, 0, ',', '.').',-' ?></td>
                                                <td width="130" class="text-right">
													<a href="<?php echo site_url('transaksi/editRacikan/'.$racikan->idpenjualan.'/'.$racikan->idracikan.'#itemracikan')?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Edit"><i class="fa fa-edit fa-white"></i></a>
													<a href="<?php echo site_url('transaksi/hapusRacikan/'.$racikan->idpenjualan.'/'.$racikan->idracikan)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Hapus"
															   onclick="return confirm('Hapus Penjualan Dengan Racikan ?')"><i class="fa fa-times fa-white"></i></a>
												</td>
                                            </tr>
											<?php } ?>
										</tbody>
										<tfoot>
											<tr>
                                                <th width="50">No</th>
												<th>Produk</th>
												<th>Jumlah</th>
												<th>Sub Total</th>
                                                <th width="130"></th>
											</tr>
										</tfoot>
									</table>
								</div>
                            </div>
						</div>
                    </div>
					<?php } ?>						
					
					
					
                </div>
            </div>
        </div>
    </div>
</div>
