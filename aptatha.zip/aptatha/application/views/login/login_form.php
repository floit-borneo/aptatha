
							<?php echo form_open($action) ?>
                                <!-- Form Group -->
                                <div class="form-group">
									<?php echo form_error('email') ?>
                                    <input type="email" name="email" class="form-control" placeholder="Email" required="true">
                                </div>

                                <!-- Form Group -->
                                <div class="form-group">
									<?php echo form_error('password') ?>
                                    <input type="password" name="password" class="form-control" placeholder="Password" required="true">
                                </div>

                                <button type="submit" class="btn btn-primary register">Login</button>
                                <a class="forgot_pass" href="#"><small> <!--Forgot password?--> </small></a>
							<?php echo form_close() ?>