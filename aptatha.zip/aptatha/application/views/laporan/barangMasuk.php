

                <!-- Breadcrumb Area -->
                <div class="breadcrumb-area" style="padding:20px 5px">
                    <div class="container-fluid">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Laporan</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Laporan Barang Masuk</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox bg-boxshadow">
                                    <div class="ibox-title mb-10">
                                        <h5>Laporan Barang Masuk</h5>
                                    </div>
									<?php $idmessage = $this->session->flashdata('idmessage') ?>
									<?php $message = $this->session->flashdata('message') ?>
									<?php if ($message) { ?>
										<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
											<button data-dismiss="alert" class="close">
												&times;
											</button>
											<i class="fa fa-info-circle"></i>
											<strong><?php echo $message ?></strong>
										</div>
									<?php } ?>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
										
											<div class="col-sm-6 mb-10">
												<?php echo form_open_multipart($laporanBarangMasuk_print, 'target=blank') ?>
												<div class="input-group col-sm-12">
													<label class="col-form-label" style="margin-right:10px">Dari:</label>
													<?php
													$tglawal=array(
														'type'=> 'date',
														'name'=> 'tglawal',
														'class'=>'form-control',
														'value'=>date('Y-m-d')
													);
													?>
													<?php echo form_input($tglawal) ?>
													<div class="input-group-append" style="margin-right:10px">
														<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
													</div> 
													<label class="col-form-label" style="margin-right:10px">Sampai: </label>
													<?php
													$tglakhir=array(
														'type'=> 'date',
														'name'=> 'tglakhir',
														'class'=>'form-control',
														'value'=>date('Y-m-d')
													);
													?>
													<?php echo form_input($tglakhir) ?>
													<div class="input-group-append" style="margin-right:10px">
														<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
													</div> 
													<button class="btn btn-info btn-sm" type="submit"><i class="fa fa-print"></i> Cetak Laporan</button>
												</div>
												<?php echo form_close() ?>
											</div>
											
											<?php $sumProduk=0; ?>
											<?php $sumSatuan=0; ?>
											<?php $sumPengeluaran=0; ?>
											<?php $sumCount=0; ?>
											<?php foreach ($barangMasuk_data as $barangMasuk){ ?>
											<?php 
												if (!empty($barangMasuk->kolom3)){ 
													$sumPengeluaran =  $barangMasuk->kolom9+$sumPengeluaran;
													$sumCount =  1+$sumCount;
												} 
											?>
											<?php 
												if (!empty($barangMasuk->kolom12)){ 
													$sumProduk =  $barangMasuk->kolom12+$sumProduk;
												} 
											?>
											<?php 
												if (!empty($barangMasuk->kolom15)){ 
													$sumSatuan =  $barangMasuk->kolom15+$sumSatuan;
												} 
											?>
											<?php } ?>
											<div class="col-lg-12 mb-10">
											<h6>
												<table>
													<tr>
														<td>Total Faktur &nbsp </td>
														<td><?php echo ': '.$sumCount.' produk'; ?> </td>
													</tr>
													<tr>
														<td>Total Produk Masuk &nbsp </td>
														<td><?php echo ': '.$sumProduk.' produk'; ?> </td>
													</tr>
													<tr>
														<td>Total Satuan Produk Masuk &nbsp</td>
														<td><?php echo ': '.$sumSatuan.' satuan produk'; ?> </td>
													</tr>
													<tr>
														<td>Total Pengeluaran &nbsp </td>
														<td><?php echo ': Rp.'.number_format($sumPengeluaran, 0, ',', '.').',-'; ?> </td>
													</tr>
												</table>
											</h6>
											</div>
											<?php $no=0; ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-full-barangMasuk">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Barang Masuk</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Tanggal Masuk</th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th>Status</th>
                                                        <th>Keterangan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($barangMasuk_data as $barangMasuk){ ?>
                                                    <tr>
                                                        <td><?php if (!empty($barangMasuk->kolom3)){echo ++$no; }?></td>
                                                        <td><?php if (!empty($barangMasuk->kolom3)){echo $barangMasuk->kolom1; }?></td>
                                                        <td><?php echo $barangMasuk->kolom2 ?></td>
                                                        <td><?php if (!empty($barangMasuk->kolom3)){echo date('d-m-Y', strtotime($barangMasuk->kolom3)); }?></td>
                                                        <td><?php echo $barangMasuk->kolom4 ?></td>
                                                        <td><?php if (!empty($barangMasuk->kolom3)){echo 'Faktur: '.$barangMasuk->kolom5; } else{
															echo 'Batch: '.$barangMasuk->kolom5; }?></td>
                                                        <td><?php if (!empty($barangMasuk->kolom3)){echo 'Tgl Faktur: '.date('d-m-Y', strtotime($barangMasuk->kolom6)); } else{
															echo 'Tgl Kadaluarsa: '.date('d-m-Y', strtotime($barangMasuk->kolom6)); }?></td>
                                                        <td><?php echo $barangMasuk->kolom7 ?></td>
                                                        <td><?php echo $barangMasuk->kolom8 ?></td>
                                                        <td><?php echo $barangMasuk->kolom13.'Rp.'.number_format($barangMasuk->kolom9, 0, ',', '.').',-'.$barangMasuk->kolom14  ?></td>
                                                        <td><?php echo $barangMasuk->kolom10 ?></td>
                                                        <td><?php echo $barangMasuk->kolom11 ?></td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Barang Masuk</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Tanggal Masuk</th>
                                                        <th>Nama Supplier</th>
                                                        <th>No. Faktur</th>
                                                        <th>Tanggal Faktur</th>
                                                        <th>Jumlah Produk</th>
                                                        <th>PPN</th>
                                                        <th>Total</th>
                                                        <th>Status</th>
                                                        <th>Keterangan</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
