

                <!-- Breadcrumb Area -->
                <div class="breadcrumb-area" style="padding:20px 5px">
                    <div class="container-fluid">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Laporan</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Laporan Transaksi</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox bg-boxshadow">
                                    <div class="ibox-title mb-10">
                                        <h5>Laporan Transaksi</h5>
                                    </div>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											
											<div class="col-sm-12 mb-10">
												<?php echo form_open_multipart($laporanTransaksi_print, 'target=blank') ?>
												<div class="input-group col-sm-12">
													<label class="col-form-label" style="margin-right:10px">Dari:</label>
													<?php
													$tglawal=array(
														'type'=> 'date',
														'name'=> 'tglawal',
														'class'=>'form-control',
														'value'=>date('Y-m-d')
													);
													?>
													<?php echo form_input($tglawal) ?>
													<div class="input-group-append" style="margin-right:10px">
														<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
													</div> 
													<label class="col-form-label" style="margin-right:10px">Sampai: </label>
													<?php
													$tglakhir=array(
														'type'=> 'date',
														'name'=> 'tglakhir',
														'class'=>'form-control',
														'value'=>date('Y-m-d')
													);
													?>
													<?php echo form_input($tglakhir) ?>
													<div class="input-group-append" style="margin-right:10px">
														<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
													</div>
                                                    <?php
                                                        $options = array(
                                                            'penjualan' => 'Transaksi Penjualan',
                                                            'pembelian' => 'Transaksi Pembelian',
                                                            'semua' => 'Seluruh Transaksi'
                                                        );
                                                        echo form_dropdown('jenis_laporan', $options);
                                                    ?>
													<button class="btn btn-info btn-sm"style="margin-left:10px" type="submit"><i class="fa fa-print"></i> Cetak Laporan</button>
												</div>
												<?php echo form_close() ?>
											</div>
											
											<?php $no=0; ?>
											<?php $saldo=0; ?>
											<?php $totalmasuk=0; ?>
											<?php $totalkeluar=0; ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-full-transaksi">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Transaksi</th>
														<th>Tanggal Transaksi</th>
														<th>Nama Supplier</th>
                                                        <th>Total Masuk</th>
                                                        <th>Total Keluar</th>
                                                        <th>Saldo</th>
                                                        <?php if ($hakakses == '1') { ?>
                                                        <th>Laba</th>
                                                        <?php } ?>
                                                        <th>Keterangan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($transaksi_data as $transaksi){ ?>
													<?php
														if (!empty($transaksi->kolom4)){
															if (!empty($transaksi->kolom5)){
																$saldo=$saldo-$transaksi->kolom4+$transaksi->kolom5;
															} else {
																$saldo=$saldo-$transaksi->kolom4+0;
															}
															$totalkeluar=$transaksi->kolom4+$totalkeluar;
														} else {
															if (!empty($transaksi->kolom5)){
																$saldo=$saldo-0+$transaksi->kolom5;
															}															
														}
														if (!empty($transaksi->kolom5)){
															$totalmasuk=$transaksi->kolom5+$totalmasuk;
														}			
													?>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td><?php echo $transaksi->kolom1 ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($transaksi->kolom2)); ?></td>
                                                        <td><?php echo $transaksi->kolom3 ?></td>
                                                        <td><?php if (!empty($transaksi->kolom5)){echo 'Rp.'.number_format($transaksi->kolom5, 0, ',', '.').',-';} ?></td>
                                                        <td><?php if (!empty($transaksi->kolom4)){echo 'Rp.'.number_format($transaksi->kolom4, 0, ',', '.').',-';} ?></td>
                                                        <td><?php echo 'Rp.'.number_format($saldo, 0, ',', '.').',-'; ?></td>
                                                        <?php if ($hakakses == '1') { ?>
                                                        <td><?php if (!empty($transaksi->kolom7)){echo 'Rp.'.number_format($transaksi->kolom7, 0, ',', '.').',-';} ?></td>
                                                        <?php } ?>
                                                        <td><?php echo $transaksi->kolom6 ?></td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th></th>
                                                        <th></th>
														<th><b>Total</b></th>
                                                        <th><?php echo 'Rp.'.number_format($totalmasuk, 0, ',', '.').',-'; ?></th>
                                                        <th><?php echo 'Rp.'.number_format($totalkeluar, 0, ',', '.').',-'; ?></th>
                                                        <th><?php echo 'Rp.'.number_format($saldo, 0, ',', '.').',-'; ?></th>
                                                        <?php if ($hakakses == '1') { ?>
                                                        <th></th>
                                                        <?php } ?>
                                                        <th></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
