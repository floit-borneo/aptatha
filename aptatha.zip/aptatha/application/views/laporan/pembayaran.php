

                <!-- Breadcrumb Area -->
                <div class="breadcrumb-area" style="padding:20px 5px">
                    <div class="container-fluid">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Transaksi</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Daftar Pembayaran Barang Masuk</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12 mb-30">
                                <!-- Ibox -->
                                <div class="ibox bg-boxshadow">
                                    <div class="ibox-title mb-10">
                                        <h5>Daftar Pembayaran Barang Masuk</h5>
                                    </div>
									<?php $idmessage = $this->session->flashdata('idmessage') ?>
									<?php $message = $this->session->flashdata('message') ?>
									<?php if ($message) { ?>
										<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
											<button data-dismiss="alert" class="close">
												&times;
											</button>
											<i class="fa fa-info-circle"></i>
											<strong><?php echo $message ?></strong>
										</div>
									<?php } ?>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											<?php $no=0; ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-full-pembayaran">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Barang Masuk</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Tanggal Masuk</th>
                                                        <th>Nama Supplier</th>
                                                        <th>No. Faktur</th>
                                                        <th>Tanggal Faktur</th>
                                                        <th>Total</th>
                                                        <th>Sisa Pembayaran</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($pembayaran_data as $pembayaran){ ?>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td><?php echo $pembayaran->idbarangmasuk ?></td>
                                                        <td><?php echo $pembayaran->nmpembuat ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($pembayaran->tglbarangmasuk)); ?></td>
                                                        <td><?php echo $pembayaran->nmsupplier ?></td>
                                                        <td><?php echo $pembayaran->nofaktur ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($pembayaran->tglfaktur)); ?></td>
                                                        <td><?php echo 'Rp'.number_format($pembayaran->total, 0, ',', '.').',-' ?></td>
														<td>
															<?php if((($pembayaran->sisa)==0) AND (($pembayaran->total_sementara)==0)){ ?>
															Belum ada pembayaran
															<?php } else { ?>
															<?php echo 'Rp'.number_format($pembayaran->sisa, 0, ',', '.').',-' ?>
															<?php } ?>
														</td>
                                                        <td><?php echo $pembayaran->status ?></td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Barang Masuk</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Tanggal Masuk</th>
                                                        <th>Nama Supplier</th>
                                                        <th>No. Faktur</th>
                                                        <th>Tanggal Faktur</th>
                                                        <th>Total</th>
                                                        <th>Sisa Pembayaran</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
							<!--
							<div class="col-lg-12">
								<div class="ibox bg-boxshadow">
                                    <div class="ibox-title mb-10">
                                        <h5>History Pembayaran</h5>
                                    </div>
									<?php $idmessage = $this->session->flashdata('idmessage') ?>
									<?php $message = $this->session->flashdata('message') ?>
									<?php if ($message) { ?>
										<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
											<button data-dismiss="alert" class="close">
												&times;
											</button>
											<i class="fa fa-info-circle"></i>
											<strong><?php echo $message ?></strong>
										</div>
									<?php } ?>
							
                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive 
                                        <div class="table-responsive">
											<?php $no=0; ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-full-historypembayaran">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Barang Masuk</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Nama Penerima</th>
                                                        <th>Tanggal Masuk</th>
                                                        <th>Nama Supplier</th>
                                                        <th>No. Faktur</th>
                                                        <th>Tanggal Faktur</th>
                                                        <th>Tanggal Pembayaran</th>
                                                        <th>Jumlah Pembayaran</th>
                                                        <th>Keterangan</th>
                                                        <th width="100"></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($historypembayaran_data as $historypembayaran){ ?>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td><?php echo $historypembayaran->idbarangmasuk ?></td>
                                                        <td><?php echo $historypembayaran->nmpembuat ?></td>
                                                        <td><?php echo $historypembayaran->nmpenerima ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($historypembayaran->tglbarangmasuk)); ?></td>
                                                        <td><?php echo $historypembayaran->nmsupplier ?></td>
                                                        <td><?php echo $historypembayaran->nofaktur ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($historypembayaran->tglfaktur)); ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($historypembayaran->tglpembayaran)); ?></td>
                                                        <td><?php echo 'Rp'.number_format($historypembayaran->jumlah, 0, ',', '.').',-' ?></td>
                                                        <td><?php echo $historypembayaran->keterangan ?></td>
                                                        <td width="100" class="text-right">
															<a href="<?php echo site_url('cprint/pembayaran/'.$historypembayaran->idbarangmasuk.'/'.$historypembayaran->idpembayaran)?>" target="blank" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Lihat"><i class="fa fa-print fa-white"></i></a>
															<a href="<?php echo site_url('transaksi/hapusPembayaran/'.$historypembayaran->idpembayaran)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Lihat"><i class="fa fa-times fa-white"></i></a>
														</td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Barang Masuk</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Nama Penerima</th>
                                                        <th>Tanggal Masuk</th>
                                                        <th>Nama Supplier</th>
                                                        <th>No. Faktur</th>
                                                        <th>Tanggal Faktur</th>
                                                        <th>Tanggal Pembayaran</th>
                                                        <th>Jumlah</th>
                                                        <th>Keterangan</th>
                                                        <th width="100"></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
							-->
                        </div>
                    </div>
                </div>
