

                <!-- Breadcrumb Area -->
                <div class="breadcrumb-area" style="padding:20px 5px">
                    <div class="container-fluid">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Laporan</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Laporan Penjualan tanpa Resep</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox bg-boxshadow">
                                    <div class="ibox-title mb-10">
                                        <h5>Laporan Penjualan tanpa Resep</h5>
                                    </div>
									<?php $idmessage = $this->session->flashdata('idmessage') ?>
									<?php $message = $this->session->flashdata('message') ?>
									<?php if ($message) { ?>
										<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
											<button data-dismiss="alert" class="close">
												&times;
											</button>
											<i class="fa fa-info-circle"></i>
											<strong><?php echo $message ?></strong>
										</div>
									<?php } ?>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											
											<div class="col-sm-6 mb-10">
												<?php echo form_open_multipart($laporanPenjualanTnpResep_print, 'target=blank') ?>
												<div class="input-group col-sm-12">
													<label class="col-form-label" style="margin-right:10px">Dari:</label>
													<?php
													$tglawal=array(
														'type'=> 'date',
														'name'=> 'tglawal',
														'class'=>'form-control',
														'value'=>date('Y-m-d')
													);
													?>
													<?php echo form_input($tglawal) ?>
													<div class="input-group-append" style="margin-right:10px">
														<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
													</div> 
													<label class="col-form-label" style="margin-right:10px">Sampai: </label>
													<?php
													$tglakhir=array(
														'type'=> 'date',
														'name'=> 'tglakhir',
														'class'=>'form-control',
														'value'=>date('Y-m-d')
													);
													?>
													<?php echo form_input($tglakhir) ?>
													<div class="input-group-append" style="margin-right:10px">
														<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
													</div> 
													<button class="btn btn-info btn-sm" type="submit"><i class="fa fa-print"></i> Cetak Laporan</button>
												</div>
												<?php echo form_close() ?>
											</div>
											
											<?php $sumProduk=0; ?>
											<?php $sumSatuan=0; ?>
											<?php $sumPemasukan=0; ?>
											<?php $sumCount=0; ?>
											<?php foreach ($penjualanTnpResep_data as $penjualanTnpResep){ ?>
											<?php
												if (!empty($penjualanTnpResep->kolom3)){
													$sumPemasukan =  $penjualanTnpResep->kolom7+$sumPemasukan;
													$sumCount =  1+$sumCount;
												}
											?>
											<?php
												if (!empty($penjualanTnpResep->kolom12)){
													$sumProduk =  $penjualanTnpResep->kolom12+$sumProduk;
												}
											?>
											<?php
												if (!empty($penjualanTnpResep->kolom11)){
													$sumSatuan =  $penjualanTnpResep->kolom11+$sumSatuan ;
												}
											?>
											<?php } ?>
											<div class="col-lg-12 mb-10">
											<h6>
												<table>
													<tr>
														<td>Total Faktur &nbsp </td>
														<td><?php echo ': '.$sumCount.' faktur'; ?> </td>
													</tr>
													<tr>
														<td>Total Penjualan Produk &nbsp </td>
														<td><?php echo ': '.$sumProduk.' produk'; ?> </td>
													</tr>
													<tr>
														<td>Total Penjualan Satuan Produk &nbsp</td>
														<td><?php echo ': '.$sumSatuan.' satuan produk'; ?> </td>
													</tr>
													<tr>
														<td>Total Pemasukan &nbsp </td>
														<td><?php echo ': Rp.'.number_format($sumPemasukan, 0, ',', '.').',-'; ?> </td>
													</tr>
												</table>
											</h6>
											</div>
											<?php $no=0; ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-full-penjualanTnpResep">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Penjualan</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Tanggal Penjualan</th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th>Keterangan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($penjualanTnpResep_data as $penjualanTnpResep){ ?>
                                                    <tr>
                                                        <td><?php if (!empty($penjualanTnpResep->kolom3)){echo ++$no; }?></td>
                                                        <td><?php if (!empty($penjualanTnpResep->kolom3)){echo $penjualanTnpResep->kolom1; }?></td>
                                                        <td><?php echo $penjualanTnpResep->kolom2 ?></td>
                                                        <td><?php if (!empty($penjualanTnpResep->kolom3)){echo date('d-m-Y', strtotime($penjualanTnpResep->kolom3)); }?></td>
                                                        <td><?php echo $penjualanTnpResep->kolom4 ?></td>
                                                        <td><?php echo $penjualanTnpResep->kolom5 ?></td>
                                                        <td><?php echo $penjualanTnpResep->kolom6 ?></td>
                                                        <td><?php echo $penjualanTnpResep->kolom9.'Rp'.number_format($penjualanTnpResep->kolom7, 0, ',', '.').',-'.$penjualanTnpResep->kolom10 ?></td>
                                                        <td><?php echo $penjualanTnpResep->kolom8 ?></td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
