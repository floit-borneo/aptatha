

                <!-- Breadcrumb Area -->
                <div class="breadcrumb-area" style="padding:20px 5px">
                    <div class="container-fluid">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Laporan</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Laporan Penjualan Umum</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox bg-boxshadow">
                                    <div class="ibox-title mb-10">
                                        <h5>Laporan Penjualan dengan Resep</h5>
                                    </div>
									<?php $idmessage = $this->session->flashdata('idmessage') ?>
									<?php $message = $this->session->flashdata('message') ?>
									<?php if ($message) { ?>
										<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
											<button data-dismiss="alert" class="close">
												&times;
											</button>
											<i class="fa fa-info-circle"></i>
											<strong><?php echo $message ?></strong>
										</div>
									<?php } ?>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											
											<div class="col-sm-6 mb-10">
												<?php echo form_open_multipart($laporanPenjualan_print, 'target=blank') ?>
												<div class="input-group col-sm-12">
													<label class="col-form-label" style="margin-right:10px">Dari:</label>
													<?php
													$tglawal=array(
														'type'=> 'date',
														'name'=> 'tglawal',
														'class'=>'form-control',
														'value'=>date('Y-m-d')
													);
													?>
													<?php echo form_input($tglawal) ?>
													<div class="input-group-append" style="margin-right:10px">
														<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
													</div> 
													<label class="col-form-label" style="margin-right:10px">Sampai: </label>
													<?php
													$tglakhir=array(
														'type'=> 'date',
														'name'=> 'tglakhir',
														'class'=>'form-control',
														'value'=>date('Y-m-d')
													);
													?>
													<?php echo form_input($tglakhir) ?>
													<div class="input-group-append" style="margin-right:10px">
														<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
													</div> 
													<button class="btn btn-info btn-sm" type="submit"><i class="fa fa-print"></i> Cetak Laporan</button>
												</div>
												<?php echo form_close() ?>
											</div>
											
											<?php $sumProduk=0; ?>
											<?php $sumSatuan=0; ?>
											<?php $sumPemasukan=0; ?>
											<?php $sumCount=0; ?>
											<?php foreach ($penjualan_data as $penjualan){ ?>
											<?php 
												if (!empty($penjualan->kolom11)){ 
													$sumSatuan =  $penjualan->kolom11+$sumSatuan; 
												} 
											?>
											<?php
												if (!empty($penjualan->kolom3)){ 
													$sumPemasukan =  $penjualan->kolom7+$sumPemasukan;
													$sumCount =  1+$sumCount;
												}
											?>
											<?php
												if (!empty($penjualan->kolom12)){ 
													$sumProduk =  $penjualan->kolom12+$sumProduk;
												} 
											?>
											<?php } ?>
											<div class="col-lg-12 mb-10">
											<h6>
												<table>
													<tr>
														<td>Total Faktur &nbsp </td>
														<td><?php echo ': '.$sumCount.' faktur'; ?> </td>
													</tr>
													<tr>
														<td>Total Penjualan Produk &nbsp </td>
														<td><?php echo ': '.$sumProduk.' produk'; ?> </td>
													</tr>
													<tr>
														<td>Total Penjualan Satuan Produk &nbsp</td>
														<td><?php echo ': '.$sumSatuan.' satuan produk'; ?> </td>
													</tr>
													<tr>
														<td>Total Pemasukan &nbsp </td>
														<td><?php echo ': Rp.'.number_format($sumPemasukan, 0, ',', '.').',-'; ?> </td>
													</tr>
												</table>
											</h6>
											</div>
											<?php $no=0; ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-full-penjualan">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Penjualan</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Tanggal Penjualan</th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th>Keterangan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($penjualan_data as $penjualan){ ?>
                                                    <tr>
                                                        <td><?php if (!empty($penjualan->kolom3)){echo ++$no; }?></td>
                                                        <td><?php if (!empty($penjualan->kolom3)){echo $penjualan->kolom1; }?></td>
                                                        <td><?php echo $penjualan->kolom2 ?></td>
                                                        <td><?php if (!empty($penjualan->kolom3)){echo date('d-m-Y', strtotime($penjualan->kolom3)); }?></td>
                                                        <td><?php echo $penjualan->kolom4 ?></td>
                                                        <td><?php echo $penjualan->kolom5 ?></td>
                                                        <td><?php echo $penjualan->kolom6 ?></td>
                                                        <td><?php echo $penjualan->kolom9.'Rp'.number_format($penjualan->kolom7, 0, ',', '.').',-'.$penjualan->kolom10 ?></td>
                                                        <td><?php echo $penjualan->kolom8 ?></td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
