

                <!-- Breadcrumb Area -->
                <div class="breadcrumb-area" style="padding:20px 5px">
                    <div class="container-fluid">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Transaksi</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Laporan Buku Besar</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox bg-boxshadow">
                                    <div class="ibox-title mb-10">
                                        <h5>Laporan Buku Besar</h5>
                                    </div>
									
                                    <div class="card-header mb-5">
                                        <h5>Rilis Buku Besar<small> </small></h5>
										<?php echo form_open_multipart($rilisBukuBesar, "class='form-horizontal'") ?>
										<div class="form-group row">
											<div class="col-sm-4 mb-10"> 
												<label> Pemasukan Lain </label>
												<?php
												$pemasukanLain_=array(
													'type'=> 'number',
													'name'=> 'pemasukanLain',
													'class'=>'form-control',
													'value'=>$pemasukanLain
												);
												?>
												<?php echo form_input($pemasukanLain_) ?>
											</div>
											<div class="col-sm-4 mb-10"> 
												<label> Pengeluaran Lain </label>
												<?php
												$pengeluaranLain_=array(
													'type'=> 'number',
													'name'=> 'pengeluaranLain',
													'class'=>'form-control',
													'value'=>$pengeluaranLain
												);
												?>
												<?php echo form_input($pengeluaranLain_) ?>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-sm-4 mb-10"> 
												<label> Tanggal Awal: </label>
													<?php
													$tglawal_=array(
														'type'=> 'date',
														'name'=> 'tglawal',
														'class'=>'form-control',
														'value'=>date('Y-m-d')
													);
													?>
													<?php echo form_input($tglawal_) ?>
											</div>
											<div class="col-sm-4 mb-10"> 
												<label> Tanggal Akhir: </label>
													<?php
													$tglakhir_=array(
														'type'=> 'date',
														'name'=> 'tglakhir',
														'class'=>'form-control',
														'value'=>date('Y-m-d')
													);
													?>
													<?php echo form_input($tglakhir_) ?>
											</div>
										</div>
										<div class="col-sm-12">
												<button class="btn btn-info btn-sm" type="submit">Rilis</button>
										</div>
										<?php echo form_close() ?>
                                    </div>

                                    <!-- Ibox Content -->
									<?php if ($state=='ready') { ?>
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											<h5>Buku Besar<small> dari <?php echo date('d-m-Y', strtotime($tglawal)); ?>  sampai <?php echo date('d-m-Y', strtotime($tglakhir)); ?></small></h5>	
											<div class="">
												<p><a href="<?php echo site_url('cprint/laporanBukuBesar/'.$idbukubesar) ?>" class="btn btn-info" target="blank"><i class="fa fa-print"></i> Cetak Laporan </a>
											</div>
											<?php $no=0; ?>
                                            <table class="table table-striped table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th></th>
                                                        <th>Debit</th>
                                                        <th>Kredit</th>
                                                    </tr>
                                                </thead>
                                                <tbody><!--
                                                    <tr>
                                                        <td><?php // echo ++$no ?></td>
                                                        <td>Penjualan </td>
                                                        <td><?php echo 'Rp'.number_format($penjualan, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>-->
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Penjualan tanpa resep</td>
                                                        <td><?php echo 'Rp'.number_format($penjualantnpresep, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Penjualan dengan resep</td>
                                                        <td><?php echo 'Rp'.number_format($penjualandgnresep, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr><!--
                                                    <tr>
                                                        <td><?php // echo ++$no ?></td>
                                                        <td>Persediaan barang</td>
                                                        <td><?php echo 'Rp'.number_format($persediaanbarang, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php // echo ++$no ?></td>
                                                        <td>Laba per item</td>
                                                        <td><?php echo 'Rp'.number_format($laba, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php // echo ++$no ?></td>
                                                        <td>Potongan pembelian</td>
                                                        <td><?php echo 'Rp'.number_format($potonganpembelian, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Potongan penjualan</td>
                                                        <td>-</td>
                                                        <td><?php echo 'Rp'.number_format($potonganpenjualan, 0, ',', '.').',-' ?></td>
                                                    </tr>-->
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Pendapatan tuslah</td>
                                                        <td><?php echo 'Rp'.number_format($pendapatantuslah, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <!--<tr>
                                                        <td><?php // echo ++$no ?></td>
                                                        <td>Pendapatan embalase</td>
                                                        <td>-</td>
                                                        <td><?php echo 'Rp'.number_format($pendapatanembalase, 0, ',', '.').',-' ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php // echo ++$no ?></td>
                                                        <td>Hutang dagang</td>
                                                        <td>-</td>
                                                        <td><?php echo 'Rp'.number_format($hutangdagang, 0, ',', '.').',-' ?></td>
                                                    </tr>-->
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Pembayaran hutang</td>
                                                        <td>-</td>
                                                        <td><?php echo 'Rp'.number_format($hutangdagang, 0, ',', '.').',-' ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Pemasukan lain</td>
                                                        <td><?php echo 'Rp'.number_format($pemasukanlain, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Pengeluaran lain</td>
                                                        <td>-</td>
                                                        <td><?php echo 'Rp'.number_format($pengeluaranlain, 0, ',', '.').',-' ?></td>
                                                    </tr>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th width="50"></th>
                                                        <th><b>Total</b></th>
                                                        <th><b><?php echo 'Rp'.number_format($totalmasuk, 0, ',', '.').',-' ?></b></th>
                                                        <th><b><?php echo 'Rp'.number_format($totalkeluar, 0, ',', '.').',-' ?></b></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
									<?php } ?>
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											<h5>History Buku Besar<small> </small></h5>	
											<?php $no=0; ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-full-barangMasuk">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Buku Besar</th>
                                                        <th>Tanggal Awal</th>
                                                        <th>Tanggal Akhir</th>
                                                        <th>Total Masuk</th>
														<th>Total Keluar</th>
                                                        <th></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($bukuBesar_data as $bukuBesar){ ?>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td><?php echo $bukuBesar->idbukubesar ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($bukuBesar->tglawal)); ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($bukuBesar->tglakhir)); ?></td>
                                                        <td><?php echo $bukuBesar->totalmasuk ?></td>
														<td><?php echo $bukuBesar->totalkeluar ?></td>
                                                        <td width="100" class="text-right">
															<a href="<?php echo site_url('laporan/viewBukuBesar/'.$bukuBesar->idbukubesar)?>" target="blank" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Lihat"><i class="fa fa-eye fa-white"></i></a>
															<a href="<?php echo site_url('laporan/hapusBukuBesar/'.$bukuBesar->idbukubesar)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Lihat"><i class="fa fa-times fa-white"></i></a>
														</td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Buku Besar</th>
                                                        <th>Tanggal Buku Besar</th>
                                                        <th>Total Masuk</th>
														<th>Total Keluar</th>
                                                        <th></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
