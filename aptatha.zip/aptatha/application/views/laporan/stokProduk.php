

                <!-- Breadcrumb Area -->
                <div class="breadcrumb-area" style="padding:20px 5px">
                    <div class="container-fluid">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Laporan</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Laporan Stok Produk</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox bg-boxshadow">
                                    <div class="ibox-title mb-10">
                                        <h5>Laporan Stok Produk</h5>
                                    </div>
									<?php $idmessage = $this->session->flashdata('idmessage') ?>
									<?php $message = $this->session->flashdata('message') ?>
									<?php if ($message) { ?>
										<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
											<button data-dismiss="alert" class="close">
												&times;
											</button>
											<i class="fa fa-info-circle"></i>
											<strong><?php echo $message ?></strong>
										</div>
									<?php } ?>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											<!--
											<div class="col-sm-6 mb-10">
												<?php echo form_open_multipart($laporanStok_print, 'target=blank') ?>
												<div class="input-group col-sm-12">
													<label class="col-form-label" style="margin-right:10px">Dari:</label>
													<?php
													$tglawal=array(
														'type'=> 'date',
														'name'=> 'tglawal',
														'class'=>'form-control',
														'value'=>date('Y-m-d')
													);
													?>
													<?php echo form_input($tglawal) ?>
													<div class="input-group-append" style="margin-right:10px">
														<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
													</div> 
													<label class="col-form-label" style="margin-right:10px">Sampai: </label>
													<?php
													$tglakhir=array(
														'type'=> 'date',
														'name'=> 'tglakhir',
														'class'=>'form-control',
														'value'=>date('Y-m-d')
													);
													?>
													<?php echo form_input($tglakhir) ?>
													<div class="input-group-append" style="margin-right:10px">
														<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
													</div> 
													<button class="btn btn-info btn-sm" type="submit"><i class="fa fa-print"></i> Cetak Laporan</button>
												</div>
												<?php echo form_close() ?>
											</div>
											-->
											<?php $sumCount=0; ?>
											<?php foreach ($produk_data as $produk){ ?>
											<?php $sumCount =  1+$sumCount ?>
											<?php } ?>
											<div class="col-lg-12 mb-30">
											<h6>
												<table>
													<tr>
														<td>Total Produk &nbsp </td>
														<td><?php echo ': '.$sumCount.' produk'; ?> </td>
													</tr>
												</table>
											</h6>
											</div>
											<?php $no=0; ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-full-produk">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>Nama Produk</th>
                                                        <th>Kategori</th>
                                                        <th>Harga Satuan Beli</th>
                                                        <th>Satuan Beli</th>
                                                        <th>Harga Satuan Jual</th>
                                                        <th>Satuan Jual</th>
                                                        <th>Stok</th>
                                                        <th>Lokasi Rak</th>
                                                        <th>Keterangan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($produk_data as $produk){ ?>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td><?php echo $produk->nmproduk ?></td>
                                                        <td><?php echo $produk->nmkategori ?></td>
                                                        <td><?php echo $produk->hargasatuanbeli ?></td>
                                                        <td><?php echo $produk->satuanbeli ?></td>
                                                        <td><?php echo $produk->hargasatuanjual ?></td>
                                                        <td><?php echo $produk->satuanjual ?></td>
                                                        <td><?php echo $produk->stok ?></td>
                                                        <td><?php echo $produk->lokasirak ?></td>
                                                        <td><?php echo $produk->keterangan ?></td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>Nama Produk</th>
                                                        <th>Kategori</th>
                                                        <th>Harga Satuan Beli</th>
                                                        <th>Satuan Beli</th>
                                                        <th>Harga Satuan Jual</th>
                                                        <th>Satuan Jual</th>
                                                        <th>Stok</th>
                                                        <th>Lokasi Rak</th>
                                                        <th>Keterangan</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
