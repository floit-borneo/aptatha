


<!-- Wrapper -->
<div class="wrapper wrapper-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <!-- Ibox -->
				<div class="row">
                    
                    <!-- Item Penjualan Tanpa Resep -->
                    <div class="col-lg-12">
                        <div class="ibox mb-50">
							<div class="col-lg-12">
                                    <table style="text-align:center; width:100%;">
										<tbody>
											<tr>
												<td>
												   <span class="small-logo">
													   <img src="<?php echo base_url('frontend/img/core-img/logo-klinik.jpg') ?>" style="margin-right:10px; width:88px"alt="">
												   </span>
												</td>
											</tr>
											<tr>
												<td><h5 style="margin:0">Apotik Klinik Permata Husada</h5></td>
											</tr>
											<tr>
												<td>Jln. Ir. Pangeran M. Noor No. 50A RT. 004 RW.001 Kelurahan Sungai Ulin</td>
											</tr>
											<tr>
												<td>Kecamatan Banjarbaru Utara, Kota Banjarbaru, Kalimantan Selatan</td>
											</tr>
											<tr>
												<td>Telepon: (0511)5912712</td>
											</tr>
										</tbody>
									</table>
							</div>
                            <!-- Ibox-content -->
                            <div class="ibox-content">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <h5>Penjualan Tanpa Resep</h5>
												<p><span><strong>Dibuat oleh:</strong> <?php echo $nmpembuat; ?></span></p>
                                            </div>

                                            <!-- Address -->
                                            <div class="col-sm-6 text-right">
                                                <h6><?php echo "NRes-".$idpenjualan; ?></h6>
                                                <p><span><strong>Tanggal Penjualan:</strong> <?php echo date('d-m-Y', strtotime($tglpenjualan)); ?></span>
												<br><span><strong>Jumlah Produk:</strong> <?php echo $jumlah; ?> Produk</span></p></p>
                                            </div>
                                        </div>
								<!-- Table Responsive -->
								<div class="table-responsive">
									<table class="table">
										<thead>
											<tr>
                                                <th width="50">No</th>
												<th>Produk</th>
												<th style="text-align:right">Jumlah</th>
												<!--<th style="text-align:right">Harga</th>-->
												<th style="text-align:right">Diskon</th>
												<th>Subtotal</th>
											</tr>
										</thead>
										<tbody>
											<?php $no=0; ?>
											<?php $sum=0; ?>
											<?php $sumQty=0; ?>
											<?php foreach ($itemPenjualanTnpResep_data as $itemPenjualanTnpResep){ ?>
											<?php $sum=$sum+$itemPenjualanTnpResep->subtotal;?>
											<?php $sumQty=$sumQty+$itemPenjualanTnpResep->jumlah;?>
                                            <tr>
                                                <td><?php echo ++$no ?></td>
                                                <td><?php echo $itemPenjualanTnpResep->idproduk.' - '.$itemPenjualanTnpResep->nmproduk ?></td>
                                                <td style="text-align:right"><?php echo $itemPenjualanTnpResep->jumlah.' '.$itemPenjualanTnpResep->satuan ?></td>
                                                <!--<td style="text-align:right"><?php echo 'Rp.'.number_format($itemPenjualanTnpResep->harga, 0, ',', '.').',-' ?></td>-->
                                                <td style="text-align:right"><?php echo $itemPenjualanTnpResep->diskon."%" ?></td>
                                                <td><?php echo 'Rp.'.number_format($itemPenjualanTnpResep->subtotal, 0, ',', '.').',-' ?></td>
                                            </tr>
											<?php } ?>
										</tbody>
										<tfoot>
											<tr>
												<th colspan="4" style="text-align:right">Diskon <?php echo $diskon; ?>%</th>
												<th><?php echo 'Rp.'.number_format($sum*$diskon/100, 0, ',', '.').',-' ?></th>
											</tr>
											<tr>
												<th colspan="4" style="text-align:right">Total Pembayaran</th>
												<th><?php echo 'Rp.'.number_format($total, 0, ',', '.').',-' ?></th>
											</tr>
										</tfoot>
									</table>
                                    <div class="well mt-30"><strong>Keterangan: </strong><?php echo $keterangan; ?>
                                    </div>
									
								</div>
                            </div>
						</div>
                    </div>
					
                </div>
            </div>
        </div>
    </div>
</div>

