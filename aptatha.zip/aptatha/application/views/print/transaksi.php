
 <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox">
                                    <table>
										<tbody>
											<tr>
												<td rowspan="5">
												   <span class="small-logo">
													   <img src="<?php echo base_url('frontend/img/core-img/logo-klinik.jpg') ?>" style="margin-right:10px; width:88px"alt="">
												   </span>
												</td>
											</tr>
											<tr>
												<td><h5 style="margin:0">Apotik Klinik Permata Husada</h5></td>
											</tr>
											<tr>
												<td>Jln. Ir. Pangeran M. Noor No. 50A RT. 004 RW.001 Kelurahan Sungai Ulin</td>
											</tr>
											<tr>
												<td>Kecamatan Banjarbaru Utara, Kota Banjarbaru, Kalimantan Selatan</td>
											</tr>
											<tr>
												<td>Telepon: (0511)5912712</td>
											</tr>
										</tbody>
									</table>
									
                                    <div class="ibox-title mb-30">
										<?php if ($jenis_laporan=='semua'){	?>
                                        	<h5 style="text-align:center"><b>Laporan Transaksi</b></h5>
										<?php } elseif ($jenis_laporan=='penjualan'){ ?>
                                        	<h5 style="text-align:center"><b>Laporan Transaksi Penjualan</b></h5>
										<?php } elseif ($jenis_laporan=='pembelian'){ ?>
                                        	<h5 style="text-align:center"><b>Laporan Transaksi Pembelian</b></h5>
										<?php } ?>
                                    </div>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive" style="font-size:12px">
											<?php $no=0; ?>
											<?php $count=0; ?>
											<?php $saldo=0; ?>
											<?php $totalmasuk=0; ?>
											<?php $totalkeluar=0; ?>
											<?php $laba=0; ?>
													
											<?php foreach ($transaksi_data as $transaksi){ ?>
													<?php
														if (!empty($transaksi->kolom4)){
															if (!empty($transaksi->kolom5)){
																$saldo=$saldo-$transaksi->kolom4+$transaksi->kolom5;
															} else {
																$saldo=$saldo-$transaksi->kolom4+0;
															}
															$totalkeluar=$transaksi->kolom4+$totalkeluar;
														} else {
															if (!empty($transaksi->kolom5)){
																$saldo=$saldo-0+$transaksi->kolom5;
															}															
														}
														if (!empty($transaksi->kolom5)){
															$totalmasuk=$transaksi->kolom5+$totalmasuk;
														}	
														if (!empty($transaksi->kolom7)){
															$laba=$transaksi->kolom7+$laba;
														}				
													?>
											<?php $count=$count+1; ?>
											<?php } ?>
											<div class="col-lg-12 mb-30">
												<table>
													<tr>
														<td>Total Transaksi &nbsp </td>
														<td><?php echo ': '.$count.' transaksi'; ?> </td>
													</tr>
													<tr>
														<td>Total Masuk &nbsp </td>
														<td><?php echo ': '.'Rp.'.number_format($totalmasuk, 0, ',', '.').',-'; ?> </td>
													</tr>
													<tr>
														<td>Total Keluar &nbsp </td>
														<td><?php echo ': '.'Rp.'.number_format($totalkeluar, 0, ',', '.').',-'; ?> </td>
													</tr>
													<tr>
														<td>Total Saldo &nbsp </td>
														<td><?php echo ': '.'Rp.'.number_format($saldo, 0, ',', '.').',-';; ?> </td>
													</tr>
													<tr>
														<td>Total Laba &nbsp </td>
														<td><?php echo ': '.'Rp.'.number_format($laba, 0, ',', '.').',-';; ?> </td>
													</tr>
												</table>
											</div>
										
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Transaksi</th>
														<th>Tanggal Transaksi</th>
													<?php if ($jenis_laporan=='semua'){	?>
														<th>Nama Supplier</th>
                                                        <th>Total Masuk</th>
                                                        <th>Total Keluar</th>
                                                        <th>Saldo</th>
                                                        <?php if ($hakakses == '1') { ?>
                                                        <th>Laba</th>
														<?php } ?>
													<?php } elseif ($jenis_laporan=='penjualan'){ ?>
                                                        <th>Total Masuk</th>
                                                        <th>Saldo</th>
														<?php if ($hakakses == '1') { ?>
                                                        <th>Laba</th>
														<?php } ?>
													<?php } elseif ($jenis_laporan=='pembelian'){ ?>
														<th>Nama Supplier</th>
                                                        <th>Total Keluar</th>
                                                        <th>Saldo</th>
													<?php } ?>
                                                        <th>Keterangan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($transaksi_data as $transaksi){ ?>
													<?php
														if (!empty($transaksi->kolom4)){
															if (!empty($transaksi->kolom5)){
																$saldo=$saldo-$transaksi->kolom4+$transaksi->kolom5;
															} else {
																$saldo=$saldo-$transaksi->kolom4+0;
															}
															$totalkeluar=$transaksi->kolom4+$totalkeluar;
														} else {
															if (!empty($transaksi->kolom5)){
																$saldo=$saldo-0+$transaksi->kolom5;
															}															
														}
														if (!empty($transaksi->kolom5)){
															$totalmasuk=$transaksi->kolom5+$totalmasuk;
														}			
													?>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td><?php echo $transaksi->kolom1 ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($transaksi->kolom2)); ?></td>
													<?php if ($jenis_laporan=='semua'){	?>
                                                        <td><?php echo $transaksi->kolom3 ?></td>
                                                        <td><?php if (!empty($transaksi->kolom5)){echo 'Rp'.number_format($transaksi->kolom5, 0, ',', '.').',-';} ?></td>
                                                        <td><?php if (!empty($transaksi->kolom4)){echo 'Rp'.number_format($transaksi->kolom4, 0, ',', '.').',-';} ?></td>
                                                        <td><?php echo 'Rp.'.number_format($saldo, 0, ',', '.').',-'; ?></td>
                                                        <td><?php if (!empty($transaksi->kolom7)){echo 'Rp.'.number_format($transaksi->kolom7, 0, ',', '.').',-';} ?></td>
													<?php } elseif ($jenis_laporan=='penjualan'){ ?>
                                                        <td><?php if (!empty($transaksi->kolom5)){echo 'Rp'.number_format($transaksi->kolom5, 0, ',', '.').',-';} ?></td>
                                                        <td><?php echo 'Rp.'.number_format($saldo, 0, ',', '.').',-'; ?></td>
                                                        <td><?php if (!empty($transaksi->kolom7)){echo 'Rp.'.number_format($transaksi->kolom7, 0, ',', '.').',-';} ?></td>
													<?php } elseif ($jenis_laporan=='pembelian'){ ?>
                                                        <td><?php echo $transaksi->kolom3 ?></td>
                                                        <td><?php if (!empty($transaksi->kolom4)){echo 'Rp'.number_format($transaksi->kolom4, 0, ',', '.').',-';} ?></td>
                                                        <td><?php echo 'Rp.'.number_format($saldo, 0, ',', '.').',-'; ?></td>
													<?php } ?>
                                                        <td><?php echo $transaksi->kolom6 ?></td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th width="50"></th>
                                                        <th></th>
													<?php if ($jenis_laporan=='semua'){	?>
                                                        <th></th>
														<th><b>Sisa Saldo <br>(<?php echo date('d-m-Y', strtotime($tglawal)).' s/d '.date('d-m-Y', strtotime($tglakhir)); ?>)</b></th>
                                                        <th><?php echo 'Rp.'.number_format($totalmasuk, 0, ',', '.').',-'; ?></th>
                                                        <th><?php echo 'Rp.'.number_format($totalkeluar, 0, ',', '.').',-'; ?></th>
                                                        <th><?php echo 'Rp.'.number_format($saldo, 0, ',', '.').',-'; ?></th>
														<?php if ($hakakses == '1') { ?>
														<th><?php echo 'Rp.'.number_format($laba, 0, ',', '.').',-'; ?></th>
														<?php } ?>
                                                        <th></th>
													<?php } elseif ($jenis_laporan=='penjualan'){ ?>
														<th><b>Sisa Saldo <br>(<?php echo date('d-m-Y', strtotime($tglawal)).' s/d '.date('d-m-Y', strtotime($tglakhir)); ?>)</b></th>
                                                        <th><?php echo 'Rp.'.number_format($totalmasuk, 0, ',', '.').',-'; ?></th>
                                                        <th><?php echo 'Rp.'.number_format($saldo, 0, ',', '.').',-'; ?></th>
														<?php if ($hakakses == '1') { ?>
														<th><?php echo 'Rp.'.number_format($laba, 0, ',', '.').',-'; ?></th>
														<?php } ?>
													<?php } elseif ($jenis_laporan=='pembelian'){ ?>
                                                        <th></th>
														<th><b>Sisa Saldo <br>(<?php echo date('d-m-Y', strtotime($tglawal)).' s/d '.date('d-m-Y', strtotime($tglakhir)); ?>)</b></th>
                                                        <th><?php echo 'Rp.'.number_format($totalkeluar, 0, ',', '.').',-'; ?></th>
                                                        <th><?php echo 'Rp.'.number_format($saldo, 0, ',', '.').',-'; ?></th>
													<?php } ?>
                                                        <th></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
