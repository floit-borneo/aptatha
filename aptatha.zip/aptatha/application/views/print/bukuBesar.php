
                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox bg-boxshadow">
                                    <table>
										<tbody>
											<tr>
												<td rowspan="5">
												   <span class="small-logo">
													   <img src="<?php echo base_url('frontend/img/core-img/logo-klinik.jpg') ?>" style="margin-right:10px; width:88px"alt="">
												   </span>
												</td>
											</tr>
											<tr>
												<td><h5 style="margin:0">Apotik Klinik Permata Husada</h5></td>
											</tr>
											<tr>
												<td>Jln. Ir. Pangeran M. Noor No. 50A RT. 004 RW.001 Kelurahan Sungai Ulin</td>
											</tr>
											<tr>
												<td>Kecamatan Banjarbaru Utara, Kota Banjarbaru, Kalimantan Selatan</td>
											</tr>
											<tr>
												<td>Telepon: (0511)5912712</td>
											</tr>
										</tbody>
									</table>
									
                                    <div class="ibox-title mb-30">
                                        <h5 style="text-align:center">Buku Besar</h5>
										<h6 style="text-align:center">Per <?php echo date('d-m-Y', strtotime($tglbukubesar)); ?></h6>
                                    </div>
									
                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											<?php $no=0; ?>
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th></th>
                                                        <th>Debit</th>
                                                        <th>Kredit</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Penjualan </td>
                                                        <td><?php echo 'Rp'.number_format($penjualan, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Penjualan tanpa resep</td>
                                                        <td><?php echo 'Rp'.number_format($penjualantnpresep, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Penjualan dengan resep</td>
                                                        <td><?php echo 'Rp'.number_format($penjualandgnresep, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Persediaan barang</td>
                                                        <td><?php echo 'Rp'.number_format($persediaanbarang, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Laba per item</td>
                                                        <td><?php echo 'Rp'.number_format($laba, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Potongan pembelian</td>
                                                        <td><?php echo 'Rp'.number_format($potonganpembelian, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Potongan penjualan</td>
                                                        <td>-</td>
                                                        <td><?php echo 'Rp'.number_format($potonganpenjualan, 0, ',', '.').',-' ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Pendapatan tuslah</td>
                                                        <td>-</td>
                                                        <td><?php echo 'Rp'.number_format($pendapatantuslah, 0, ',', '.').',-' ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Pendapatan embalase</td>
                                                        <td>-</td>
                                                        <td><?php echo 'Rp'.number_format($pendapatanembalase, 0, ',', '.').',-' ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Hutang dagang</td>
                                                        <td>-</td>
                                                        <td><?php echo 'Rp'.number_format($hutangdagang, 0, ',', '.').',-' ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Pemasukan lain</td>
                                                        <td><?php echo 'Rp'.number_format($pemasukanlain, 0, ',', '.').',-' ?></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td>Pengeluaran lain</td>
                                                        <td>-</td>
                                                        <td><?php echo 'Rp'.number_format($pengeluaranlain, 0, ',', '.').',-' ?></td>
                                                    </tr>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th width="50"></th>
                                                        <th><b>Total</b></th>
                                                        <th><b><?php echo 'Rp'.number_format($totalmasuk, 0, ',', '.').',-' ?></b></th>
                                                        <th><b><?php echo 'Rp'.number_format($totalkeluar, 0, ',', '.').',-' ?></b></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
