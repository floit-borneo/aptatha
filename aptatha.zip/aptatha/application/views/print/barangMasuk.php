
                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox">
                                    <table>
										<tbody>
											<tr>
												<td rowspan="5">
												   <span class="small-logo">
													   <img src="<?php echo base_url('frontend/img/core-img/logo-klinik.jpg') ?>" style="margin-right:10px; width:88px"alt="">
												   </span>
												</td>
											</tr>
											<tr>
												<td><h5 style="margin:0">Apotik Klinik Permata Husada</h5></td>
											</tr>
											<tr>
												<td>Jln. Ir. Pangeran M. Noor No. 50A RT. 004 RW.001 Kelurahan Sungai Ulin</td>
											</tr>
											<tr>
												<td>Kecamatan Banjarbaru Utara, Kota Banjarbaru, Kalimantan Selatan</td>
											</tr>
											<tr>
												<td>Telepon: (0511)5912712</td>
											</tr>
										</tbody>
									</table>
									
                                    <div class="ibox-title mb-30">
                                        <h5 style="text-align:center"><b>Laporan Barang Masuk</b></h5>
                                    </div>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											
											<?php $sumProduk=0; ?>
											<?php $sumSatuan=0; ?>
											<?php $sumPengeluaran=0; ?>
											<?php $sumCount=0; ?>
											<?php foreach ($barangMasuk_data as $barangMasuk){ ?>
											<?php 
												if (!empty($barangMasuk->kolom3)){ 
													$sumPengeluaran =  $barangMasuk->kolom9+$sumPengeluaran;
													$sumCount =  1+$sumCount;
												} 
											?>
											<?php 
												if (!empty($barangMasuk->kolom12)){ 
													$sumProduk =  $barangMasuk->kolom12+$sumProduk;
												} 
											?>
											<?php 
												if (!empty($barangMasuk->kolom15)){ 
													$sumSatuan =  $barangMasuk->kolom15+$sumSatuan;
												} 
											?>
											<?php } ?>
											<div class="col-lg-12 mb-30">
												<table>
													<tbody>
														<tr>
															<td>Total Faktur Masuk &nbsp </td>
															<td><?php echo ': '.$sumCount.' produk'; ?> </td>
														</tr>
														<tr>
															<td>Total Produk Masuk &nbsp </td>
															<td><?php echo ': '.$sumProduk.' produk'; ?> </td>
														</tr>
														<tr>
															<td>Total Satuan Produk Masuk &nbsp</td>
															<td><?php echo ': '.$sumSatuan.' satuan produk'; ?> </td>
														</tr>
														<tr>
															<td>Total Pengeluaran &nbsp </td>
															<td><?php echo ': Rp.'.number_format($sumPengeluaran, 0, ',', '.').',-'; ?> </td>
														</tr>
													</tbody>
												</table>
											</div>
											<?php $no=0; ?>
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Barang Masuk</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Tanggal Masuk</th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th>Status</th>
                                                        <th>Ket</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($barangMasuk_data as $barangMasuk){ ?>
                                                    <tr>
                                                        <td><?php if (!empty($barangMasuk->kolom3)){echo ++$no; }?></td>
                                                        <td><?php if (!empty($barangMasuk->kolom3)){echo $barangMasuk->kolom1; }?></td>
                                                        <td><?php echo $barangMasuk->kolom2 ?></td>
                                                        <td><?php if (!empty($barangMasuk->kolom3)){echo date('d-m-Y', strtotime($barangMasuk->kolom3)); }?></td>
                                                        <td><?php echo $barangMasuk->kolom4 ?></td>
                                                        <td><?php if (!empty($barangMasuk->kolom3)){echo 'Faktur: '.$barangMasuk->kolom5; } else{
															echo 'Batch: '.$barangMasuk->kolom5; }?></td>
                                                        <td><?php if (!empty($barangMasuk->kolom3)){echo 'Tgl Faktur: '.date('d-m-Y', strtotime($barangMasuk->kolom6)); } else{
															echo 'Tgl Kadaluarsa: '.date('d-m-Y', strtotime($barangMasuk->kolom6)); }?></td>
                                                        <td><?php echo $barangMasuk->kolom7 ?></td>
                                                        <td><?php echo $barangMasuk->kolom8 ?></td>
                                                        <td><?php echo $barangMasuk->kolom13.'Rp.'.number_format($barangMasuk->kolom9, 0, ',', '.').',-'.$barangMasuk->kolom14  ?></td>
                                                        <td><?php echo $barangMasuk->kolom10 ?></td>
                                                        <td><?php echo $barangMasuk->kolom11 ?></td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
