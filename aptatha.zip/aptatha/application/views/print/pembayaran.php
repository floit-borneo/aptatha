
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox">
                                    <table>
										<tbody>
											<tr>
												<td rowspan="5">
												   <span class="small-logo">
													   <img src="<?php echo base_url('frontend/img/core-img/logo-klinik.jpg') ?>" style="margin-right:10px; width:88px"alt="">
												   </span>
												</td>
											</tr>
											<tr>
												<td><h5 style="margin:0">Apotik Klinik Permata Husada</h5></td>
											</tr>
											<tr>
												<td>Jln. Ir. Pangeran M. Noor No. 50A RT. 004 RW.001 Kelurahan Sungai Ulin</td>
											</tr>
											<tr>
												<td>Kecamatan Banjarbaru Utara, Kota Banjarbaru, Kalimantan Selatan</td>
											</tr>
											<tr>
												<td>Telepon: (0511)5912712</td>
											</tr>
										</tbody>
									</table>
									
                                    <div class="ibox-title mb-30">
                                        <h5 style="text-align:center"><b>Laporan Pembayaran</b></h5>
                                    </div>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											<?php $no=0; ?>
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Barang Masuk</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Nama Penerima</th>
                                                        <th>Tanggal Masuk</th>
                                                        <th>Nama Supplier</th>
                                                        <th>No. Faktur</th>
                                                        <th>Tanggal Faktur</th>
                                                        <th>Tanggal Pembayaran</th>
                                                        <th>Jumlah Pembayaran</th>
                                                        <th>Keterangan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($pembayaran_data as $pembayaran){ ?>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td><?php echo $pembayaran->idbarangmasuk ?></td>
                                                        <td><?php echo $pembayaran->nmpembuat ?></td>
                                                        <td><?php echo $pembayaran->nmpenerima ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($pembayaran->tglbarangmasuk)); ?></td>
                                                        <td><?php echo $pembayaran->nmsupplier ?></td>
                                                        <td><?php echo $pembayaran->nofaktur ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($pembayaran->tglfaktur)); ?></td>
                                                        <td><?php echo date('d-m-Y', strtotime($pembayaran->tglpembayaran)); ?></td>
                                                        <td><?php echo 'Rp'.number_format($pembayaran->jumlah, 0, ',', '.').',-' ?></td>
                                                        <td><?php echo $pembayaran->keterangan ?></td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Barang Masuk</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Nama Penerima</th>
                                                        <th>Tanggal Masuk</th>
                                                        <th>Nama Supplier</th>
                                                        <th>No. Faktur</th>
                                                        <th>Tanggal Faktur</th>
                                                        <th>Tanggal Pembayaran</th>
                                                        <th>Jumlah</th>
                                                        <th>Keterangan</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
								
                        </div>
                    </div>
                </div>
