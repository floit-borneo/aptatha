

<!-- Wrapper -->
<div class="wrapper wrapper-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <!-- Ibox -->
				<div class="row">
                    
                    <!-- Item Barang Masuk -->
                    <div class="col-lg-12">
                        <div class="ibox mb-50">
                            <!-- Title -->
                                    <table>
										<tbody>
											<tr>
												<td rowspan="5">
												   <span class="small-logo">
													   <img src="<?php echo base_url('frontend/img/core-img/logo-klinik.jpg') ?>" style="margin-right:10px; width:88px"alt="">
												   </span>
												</td>
											</tr>
											<tr>
												<td><h5 style="margin:0">Apotik Klinik Permata Husada</h5></td>
											</tr>
											<tr>
												<td>Jln. Ir. Pangeran M. Noor No. 50A RT. 004 RW.001 Kelurahan Sungai Ulin</td>
											</tr>
											<tr>
												<td>Kecamatan Banjarbaru Utara, Kota Banjarbaru, Kalimantan Selatan</td>
											</tr>
											<tr>
												<td>Telepon: (0511)5912712</td>
											</tr>
										</tbody>
									</table>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <h6>Tanda Terima Barang</h6>
												<p><span><strong>Dikirim oleh:</strong> <?php echo $nmsupplier; ?></span>
												<br><span><strong>Alamat:</strong> <?php echo $alamat; ?></span>
												<br><span><strong>No. Telepon:</strong> <?php echo $nohp; ?></span>
												<br><span><strong>Email:</strong> </span><?php echo $email; ?></p>
                                            </div>

                                            <!-- Address -->
                                            <div class="col-sm-6 text-right">
                                                <h6><?php echo $idbarangmasuk; ?></h6>
												<p><span><strong>No Faktur:</strong> <?php echo $nofaktur; ?></span>
												<br><span><strong>Tanggal Faktur:</strong> <?php echo date('d-m-Y', strtotime($tglfaktur)); ?></span>
												<br><span><strong>Jumlah Produk:</strong> <?php echo $jumlah; ?> Produk</span></p>
                                            </div>
                                        </div>
								<!-- Table Responsive -->
								<div class="table-responsive">
									<table class="table">
										<thead>
											<tr>
                                                <th width="50">No</th>
												<th>Produk</th>
												<th>Tanggal Kadaluarsa</th>
												<th style="text-align:right">Jumlah</th>
												<th style="text-align:right">Harga</th>
												<th>Subtotal</th>
											</tr>
										</thead>
										<tbody>
											<?php $no=0; ?>
											<?php $sum=0; ?>
											<?php foreach ($itemBarangMasuk_data as $itemBarangMasuk){ ?>
											<?php $sum=$sum+$itemBarangMasuk->subtotal;?>
                                            <tr>
                                                <td><?php echo ++$no ?></td>
                                                <td><?php echo $itemBarangMasuk->idproduk.' - '.$itemBarangMasuk->nmproduk ?></td>
                                                <td><?php echo date('d-m-Y', strtotime($itemBarangMasuk->tglkdluarsa)); ?></td>
                                                <td style="text-align:right"><?php echo $itemBarangMasuk->jumlah ?></td>
                                                <td style="text-align:right"><?php echo $itemBarangMasuk->harga ?></td>
                                                <td><?php echo 'Rp.'.number_format($itemBarangMasuk->subtotal, 0, ',', '.').',-' ?></td>
                                            </tr>
											<?php } ?>
										</tbody>
										<tfoot>
											<tr>
												<th colspan="5" style="text-align:right">Diskon</th>
												<th><?php echo 'Rp.'.number_format($diskon, 0, ',', '.').',-' ?></th>
											</tr>
											<tr>
												<th colspan="5" style="text-align:right">PPN <?php echo $ppn; ?>%</th>
												<th><?php echo 'Rp.'.number_format($sum*$ppn/100, 0, ',', '.').',-' ?></th>
											</tr>
											<tr>
												<th colspan="5" style="text-align:right">Total Pembayaran</th>
												<th><?php echo 'Rp.'.number_format($total, 0, ',', '.').',-' ?></th>
											</tr>
										</tfoot>
									</table>
								</div>
								<div class="col-lg-12">
								    <div class="row">
										<div class="col-sm-6">
											<p><span><strong><b>Keterangan: </b></strong> <?php echo $keterangan; ?></span>
                                            <br><span><strong>Metode Pembayaran:</strong> <?php echo $payment; ?></span>
											<br><span><strong>Tanggal Jatuh Tempo:</strong> <?php echo date('d-m-Y', strtotime($tgljatuhtempo)); ?></span>
											<br><span><strong>Status Pembayaran:</strong> <?php echo $status; ?></span></p>
                                        </div>

                                            <!-- Address -->
                                        <div class="col-sm-6 text-right">
											<p><span><strong>Diterima oleh:</strong> <?php echo $nmpembuat; ?></span>
											<br><span><strong>Tanggal Masuk:</strong> <?php echo date('d-m-Y', strtotime($tglbarangmasuk)); ?></span></p>
                                        </div>
                                    </div>
								</div>
                            </div>
						</div>
                    </div>
					
                </div>
            </div>
        </div>
    </div>
</div>

