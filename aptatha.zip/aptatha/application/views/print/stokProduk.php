
                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox">
                                    <table>
										<tbody>
											<tr>
												<td rowspan="5">
												   <span class="small-logo">
													   <img src="<?php echo base_url('frontend/img/core-img/logo-klinik.jpg') ?>" style="margin-right:10px; width:88px"alt="">
												   </span>
												</td>
											</tr>
											<tr>
												<td><h5 style="margin:0">Apotik Klinik Permata Husada</h5></td>
											</tr>
											<tr>
												<td>Jln. Ir. Pangeran M. Noor No. 50A RT. 004 RW.001 Kelurahan Sungai Ulin</td>
											</tr>
											<tr>
												<td>Kecamatan Banjarbaru Utara, Kota Banjarbaru, Kalimantan Selatan</td>
											</tr>
											<tr>
												<td>Telepon: (0511)5912712</td>
											</tr>
										</tbody>
									</table>
									
                                    <div class="ibox-title mb-30">
                                        <h5 style="text-align:center"><b>Laporan Stok Produk</b></h5>
                                    </div>
									
                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											<?php $sumCount=0; ?>
											<?php foreach ($produk_data as $produk){ ?>
											<?php $sumCount =  1+$sumCount ?>
											<?php } ?>
											<div class="col-lg-12 mb-30">
												<table>
													<tr>
														<td>Total Produk &nbsp </td>
														<td><?php echo ': '.$sumCount.' produk'; ?> </td>
													</tr>
												</table>
											</div>
											<?php $no=0; ?>
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>Nama Produk</th>
                                                        <th>Kategori</th>
                                                        <th>Harga Satuan Beli</th>
                                                        <th>Satuan Beli</th>
                                                        <th>Harga Satuan Jual</th>
                                                        <th>Satuan Jual</th>
                                                        <th>Stok</th>
                                                        <th>Lokasi Rak</th>
                                                        <th>Keterangan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($produk_data as $produk){ ?>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td><?php echo $produk->nmproduk ?></td>
                                                        <td><?php echo $produk->nmkategori ?></td>
                                                        <td><?php echo $produk->hargasatuanbeli ?></td>
                                                        <td><?php echo $produk->satuanbeli ?></td>
                                                        <td><?php echo $produk->hargasatuanjual ?></td>
                                                        <td><?php echo $produk->satuanjual ?></td>
                                                        <td><?php echo $produk->stok ?></td>
                                                        <td><?php echo $produk->lokasirak ?></td>
                                                        <td><?php echo $produk->keterangan ?></td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
