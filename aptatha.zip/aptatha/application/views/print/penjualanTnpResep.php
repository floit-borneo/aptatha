
                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox">
                                    <table>
										<tbody>
											<tr>
												<td rowspan="5">
												   <span class="small-logo">
													   <img src="<?php echo base_url('frontend/img/core-img/logo-klinik.jpg') ?>" style="margin-right:10px; width:88px"alt="">
												   </span>
												</td>
											</tr>
											<tr>
												<td><h5 style="margin:0">Apotik Klinik Permata Husada</h5></td>
											</tr>
											<tr>
												<td>Jln. Ir. Pangeran M. Noor No. 50A RT. 004 RW.001 Kelurahan Sungai Ulin</td>
											</tr>
											<tr>
												<td>Kecamatan Banjarbaru Utara, Kota Banjarbaru, Kalimantan Selatan</td>
											</tr>
											<tr>
												<td>Telepon: (0511)5912712</td>
											</tr>
										</tbody>
									</table>
									
                                    <div class="ibox-title mb-30">
                                        <h5 style="text-align:center"><b>Laporan Penjualan tanpa Resep</b></h5>
                                    </div>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											<?php $sumProduk=0; ?>
											<?php $sumSatuan=0; ?>
											<?php $sumPemasukan=0; ?>
											<?php $sumCount=0; ?>
											<?php foreach ($penjualanTnpResep_data as $penjualanTnpResep){ ?>
											<?php
												if (!empty($penjualanTnpResep->kolom3)){
													$sumPemasukan =  $penjualanTnpResep->kolom7+$sumPemasukan;
													$sumCount =  1+$sumCount;
												}
											?>
											<?php
												if (!empty($penjualanTnpResep->kolom12)){
													$sumProduk =  $penjualanTnpResep->kolom12+$sumProduk;
												}
											?>
											<?php
												if (!empty($penjualanTnpResep->kolom11)){
													$sumSatuan =  $penjualanTnpResep->kolom11+$sumSatuan ;
												}
											?>
											<?php } ?>
											<div class="col-lg-12 mb-30">
												<table>
													<tr>
														<td>Total Faktur &nbsp </td>
														<td><?php echo ': '.$sumCount.' faktur'; ?> </td>
													</tr>
													<tr>
														<td>Total Penjualan Produk &nbsp </td>
														<td><?php echo ': '.$sumProduk.' produk'; ?> </td>
													</tr>
													<tr>
														<td>Total Penjualan Satuan Produk &nbsp</td>
														<td><?php echo ': '.$sumSatuan.' satuan produk'; ?> </td>
													</tr>
													<tr>
														<td>Total Pemasukan &nbsp </td>
														<td><?php echo ': Rp.'.number_format($sumPemasukan, 0, ',', '.').',-'; ?> </td>
													</tr>
												</table>
											</div>
											<?php $no=0; ?>
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>ID Penjualan</th>
                                                        <th>Nama Pembuat</th>
                                                        <th>Tanggal Penjualan</th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th>Keterangan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($penjualanTnpResep_data as $penjualanTnpResep){ ?>
                                                    <tr>
                                                        <td><?php if (!empty($penjualanTnpResep->kolom3)){echo ++$no; }?></td>
                                                        <td><?php if (!empty($penjualanTnpResep->kolom3)){echo $penjualanTnpResep->kolom1; }?></td>
                                                        <td><?php echo $penjualanTnpResep->kolom2 ?></td>
                                                        <td><?php if (!empty($penjualanTnpResep->kolom3)){echo date('d-m-Y', strtotime($penjualanTnpResep->kolom3)); }?></td>
                                                        <td><?php echo $penjualanTnpResep->kolom4 ?></td>
                                                        <td><?php echo $penjualanTnpResep->kolom5 ?></td>
                                                        <td><?php echo $penjualanTnpResep->kolom6 ?></td>
                                                        <td><?php echo $penjualanTnpResep->kolom9.'Rp'.number_format($penjualanTnpResep->kolom7, 0, ',', '.').',-'.$penjualanTnpResep->kolom10 ?></td>
                                                        <td><?php echo $penjualanTnpResep->kolom8 ?></td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
