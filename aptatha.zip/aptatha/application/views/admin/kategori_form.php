

<!-- Breadcrumb Area -->
<div class="breadcrumb-area" style="padding:20px 5px">
	<div class="container-fluid">
		<nav aria-label="breadcrumb">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="#">Administrator</a></li>
				<li class="breadcrumb-item"><a href="<?php echo site_url('admin/produk') ?>">Produk</a></li>
				<li class="breadcrumb-item active" aria-current="page">Kategori Produk Baru</li>
			</ol>
		</nav>
	</div>
</div>

<!-- Wrapper -->
<div class="wrapper wrapper-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <!-- Ibox -->
				<div class="row">
                    <div class="col-lg-12">
                        <div class="ibox bg-boxshadow mb-50">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-30">
                                <h5>Form Kategori Produk<small></small></h5>
                            </div>
							<?php $idmessage = $this->session->flashdata('idmessage') ?>
							<?php $message = $this->session->flashdata('message') ?>
							<?php if ($message) { ?>
								<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
									<button data-dismiss="alert" class="close">
										&times;
									</button>
									<i class="fa fa-info-circle"></i>
									<strong><?php echo $message ?></strong>
								</div>
							<?php } ?>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">									
									<div class="form-group row">
										<?php foreach ($kategori_data as $kategori_row) { ?>
										<label class="col-sm-2 col-form-label"><?php echo $kategori_row->nmkategori; ?></label>
										<label class="col-sm-10"> <a href="<?php echo site_url('admin/hapusKategori/'.$kategori_row->idkategori) ?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Hapus"
									onclick="return confirm('Hapus Kategori?')"><i class="fa fa-times fa-white"></i></a> </label>
										<?php }	?>
									</div>
									
								<?php echo form_open_multipart($addKategori_action, "class='form-horizontal'") ?>
									<div class="form-group row">
										<div class="col-sm-2">
											<?php echo form_error('nmkategori') ?>    
											<?php echo form_input('nmkategori', $nmkategori, 'class="form-control" placeholder="Kategori Produk Baru"') ?>
										</div>
										<div class="col-sm-10">
											<button class="btn btn-xs btn-outline-default" type="submit"><i class="fa fa-check"></i></button>
										</div>
									</div>
									
								<?php echo form_close() ?>
                            </div>
						</div>
                    </div>
					
                </div>
            </div>
        </div>
    </div>
</div>

