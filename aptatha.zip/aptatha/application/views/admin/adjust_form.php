                <!-- Breadcrumb Area -->
                <div class="breadcrumb-area" style="padding:20px 5px">
                    <div class="container-fluid">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="dashboard-1.html">Adjustment</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Form Adjustment</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card bg-boxshadow mb-50">
									<div class="ibox-title basic-form mb-30">
										<h5>Form Adjustment<small></small></h5>
									</div>
									<?php $idmessage = $this->session->flashdata('idmessage') ?>
									<?php $message = $this->session->flashdata('message') ?>
									<?php if ($message) { ?>
										<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
											<button data-dismiss="alert" class="close">
												&times;
											</button>
											<i class="fa fa-info-circle"></i>
											<strong><?php echo $message ?></strong>
										</div>
									<?php } ?>
									
                                    <div class="card-header mb-5">
                                        <h5>Stok Opname <small> </small></h5>
										<?php echo form_open_multipart($stokOpname_action, "class='form-horizontal'") ?>
										<div class="form-group row">
											<div class="col-sm-4">
												<?php
												foreach ($produk_data as $produk_row) {
													$option_produk[$produk_row->idproduk] = $produk_row->nmproduk.' - Stok Sistem: '.$produk_row->stok;
												}
												echo form_dropdown('idproduk', $option_produk, $idproduk, 'class="form-control selectpicker" data-style="btn-select-tag" data-live-search="true"')
												?>
											</div>
											<div class="col-sm-4">
												<?php echo form_error('stokfisik') ?>    
												<?php
												$stokfisik_=array(
													'type'=> 'number',
													'name'=> 'stokfisik',
													'class'=>'form-control',
													'value'=>$stokfisik
												);
												?>
												<?php echo form_input($stokfisik_) ?>
											</div>
											<div class="col-sm-4">
												<button class="btn btn-info btn-sm" type="submit">Simpan</button>
											</div>
										</div>
										<?php echo form_close() ?>
                                    </div>
                                    <div class="card-header mb-5">
                                        <h5>Harga Jual dan Harga Beli<small> </small></h5>
										<?php echo form_open_multipart($hargaAdjust_action, "class='form-horizontal'") ?>
										<div class="form-group row">
											<div class="col-sm-4">
												<?php
												foreach ($produk_data as $produk_row) {
													$option_produk[$produk_row->idproduk] = $produk_row->nmproduk.' - Jual: '.$produk_row->hargasatuanjual.' - Beli: '.$produk_row->hargasatuanbeli;
												}
												echo form_dropdown('idproduk', $option_produk, $idproduk, 'class="form-control selectpicker" data-style="btn-select-tag" data-live-search="true"')
												?>
											</div>
											<div class="col-sm-3">
												<?php echo form_error('hargabeli') ?>    
												<?php
												$hargabeli_=array(
													'type'=> 'text',
													'name'=> 'hargabeli',
													'class'=>'form-control',
													'value'=>$hargabeli,
													'placeholder'=>'harga beli terbaru'
												);
												?>
												<?php echo form_input($hargabeli_) ?>
											</div>
											<div class="col-sm-3">
												<?php echo form_error('hargajual') ?>    
												<?php
												$hargajual_=array(
													'type'=> 'text',
													'name'=> 'hargajual',
													'class'=>'form-control',
													'value'=>$hargajual,
													'placeholder'=>'harga jual terbaru'
												);
												?>
												<?php echo form_input($hargajual_) ?>
											</div>
											<div class="col-sm-2">
												<button class="btn btn-info btn-sm" type="submit">Simpan</button>
											</div>
										</div>
										<?php echo form_close() ?>
                                    </div>
                                </div>
                            </div>
							
                        </div>
                    </div>
                </div>
				