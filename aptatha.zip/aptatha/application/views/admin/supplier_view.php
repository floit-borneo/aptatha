

<!-- Breadcrumb Area -->
<div class="breadcrumb-area" style="padding:20px 5px">
	<div class="container-fluid">
		<nav aria-label="breadcrumb">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="#">Administrator</a></li>
				<li class="breadcrumb-item"><a href="<?php echo site_url('admin/supplier') ?>">Supplier</a></li>
				<li class="breadcrumb-item active" aria-current="page">Daftar Supplier</li>
			</ol>
		</nav>
	</div>
</div>

<!-- Wrapper -->
<div class="wrapper wrapper-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <!-- Ibox -->
				<div class="row">
                    <div class="col-lg-12">
                        <div class="ibox bg-boxshadow mb-30">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-30">
                                <h5>Detail Supplier <small></small></h5>
                            </div>
							<?php $idmessage = $this->session->flashdata('idmessage') ?>
							<?php $message = $this->session->flashdata('message') ?>
							<?php if ($message) { ?>
								<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
									<button data-dismiss="alert" class="close">
										&times;
									</button>
									<i class="fa fa-info-circle"></i>
									<strong><?php echo $message ?></strong>
								</div>
							<?php } ?>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">ID Supplier</label>
										<label class="col-sm-10 col-form-label">
											<?php echo $idsupplier; ?>
										</label>
									</div>
									
									
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Nama Supplier</label>
										<label class="col-sm-10 col-form-label">
											<?php echo $nmsupplier; ?>
										</label>
									</div>
																		
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Alamat</label>
										<label class="col-sm-10 col-form-label">
											<?php echo $alamat; ?>
										</label>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">No. HP</label>
										<label class="col-sm-10 col-form-label">
											<?php echo $nohp; ?>
										</label>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Email</label>
										<label class="col-sm-10 col-form-label">
											<?php echo $email; ?>
										</label>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Keterangan</label>
										<label class="col-sm-10 col-form-label">
											<?php echo $keterangan; ?>
										</label>
									</div>
                            </div>
							
						</div>
                    </div>
                    
					
                </div>
            </div>
        </div>
    </div>
</div>

