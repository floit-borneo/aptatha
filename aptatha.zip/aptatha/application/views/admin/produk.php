

                <!-- Breadcrumb Area -->
                <div class="breadcrumb-area" style="padding:20px 5px">
                    <div class="container-fluid">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Administrator</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Daftar Produk</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox bg-boxshadow">
                                    <div class="ibox-title mb-10">
                                        <h5>Daftar Produk</h5>
                                    </div>
									<?php $idmessage = $this->session->flashdata('idmessage') ?>
									<?php $message = $this->session->flashdata('message') ?>
									<?php if ($message) { ?>
										<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
											<button data-dismiss="alert" class="close">
												&times;
											</button>
											<i class="fa fa-info-circle"></i>
											<strong><?php echo $message ?></strong>
										</div>
									<?php } ?>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											<div class="">
												<p><a href="<?php echo site_url('admin/addProduk') ?>" class="btn btn-info"><i class="fa fa-plus"></i> Produk Baru </a>
												<a href="<?php echo site_url('admin/addKategori') ?>" class="btn btn-info"><i class="fa fa-plus"></i> Kategori Produk Baru</a></p>
											</div>
											
											<?php $no=0; ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-full-produk">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>Nama Produk</th>
                                                        <th>Kategori</th>
                                                        <th>Harga Beli</th>
                                                        <th>Satuan Beli</th>
                                                        <th>Harga Jual</th>
                                                        <th>Satuan Jual</th>
                                                        <th>Stok</th>
                                                        <th width="150"></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($produk_data as $produk){ ?>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td><?php echo $produk->nmproduk ?></td>
                                                        <td><?php echo $produk->nmkategori ?></td>
                                                        <td><?php echo $produk->hargasatuanbeli ?></td>
                                                        <td><?php echo $produk->satuanbeli ?></td>
                                                        <td><?php echo $produk->hargasatuanjual ?></td>
                                                        <td><?php echo $produk->satuanjual ?></td>
                                                        <td><?php echo $produk->stok ?></td>
                                                        <td class="text-right">
															<a href="<?php echo site_url('admin/viewProduk/'.$produk->idproduk)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Lihat"><i class="fa fa-eye fa-white"></i></a>
															<a href="<?php echo site_url('admin/editProduk/'.$produk->idproduk)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Edit"><i class="fa fa-edit fa-white"></i></a>
															<a href="<?php echo site_url('admin/hapusProduk/'.$produk->idproduk)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Hapus"
															   onclick="return confirm('Hapus Produk <?php echo $produk->nmproduk ?>?')"><i class="fa fa-times fa-white"></i></a>
														</td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Nama Produk</th>
                                                        <th>Kategori</th>
                                                        <th>Harga Beli</th>
                                                        <th>Satuan Beli</th>
                                                        <th>Harga Jual</th>
                                                        <th>Satuan Jual</th>
                                                        <th>Stok</th>
                                                        <th></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
