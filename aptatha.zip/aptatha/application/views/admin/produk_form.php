

<!-- Breadcrumb Area -->
<div class="breadcrumb-area" style="padding:20px 5px">
	<div class="container-fluid">
		<nav aria-label="breadcrumb">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="#">Administrator</a></li>
				<li class="breadcrumb-item"><a href="<?php echo site_url('admin/produk') ?>">Produk</a></li>
				<li class="breadcrumb-item active" aria-current="page">Form Produk</li>
			</ol>
		</nav>
	</div>
</div>

<!-- Wrapper -->
<div class="wrapper wrapper-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <!-- Ibox -->
				<div class="row">
                    <div class="col-lg-12">
                        <div class="ibox bg-boxshadow mb-50">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-30">
                                <h5>Form Produk<small></small></h5>
                            </div>
							<?php $idmessage = $this->session->flashdata('idmessage') ?>
							<?php $message = $this->session->flashdata('message') ?>
							<?php if ($message) { ?>
								<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
									<button data-dismiss="alert" class="close">
										&times;
									</button>
									<i class="fa fa-info-circle"></i>
									<strong><?php echo $message ?></strong>
								</div>
							<?php } ?>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
								<?php if ($state == 'create') { ?>
								<?php echo form_open_multipart($addProduk_action, "class='form-horizontal'") ?>
								<?php } elseif ($state == 'update') { ?>
								<?php echo form_open_multipart($editProduk_action, "class='form-horizontal'") ?>
								<?php echo form_hidden('idproduk', $idproduk) ?>
								<?php }  ?>									
									
									<div class="form-group row row">
										<label class="col-sm-2 col-form-label">Nama Produk</label>
										<div class="col-sm-10">
											<?php echo form_error('nmproduk') ?>    
											<?php echo form_input('nmproduk', $nmproduk, 'class="form-control"') ?>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Kategori</label>
										<div class="col-sm-10">
											<?php
											foreach ($kategori_data as $kategori_row) {
												$option_kategori[$kategori_row->idkategori] = $kategori_row->nmkategori;
											}
											echo form_dropdown('idkategori', $option_kategori, $idkategori, 'class="form-control selectpicker" data-style="btn-select-tag" data-live-search="true"')
											?>
										</div>
									</div>
												
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Deskripsi</label>
										<div class="col-sm-10">
											<?php echo form_error('deskripsi') ?>    
											<?php
											$deskripsi_=array(
												'type'=> 'text',
												'name'=> 'deskripsi',
												'class'=>'form-control',
												'value'=>$deskripsi
											);
											?>
											<?php echo form_textarea($deskripsi_) ?>
										</div>
									</div>
										
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Satuan Beli</label>
										<div class="col-sm-10">
											<?php echo form_error('satuanbeli') ?>    
											<?php
											$satuanbeli_=array(
												'type'=> 'text',
												'name'=> 'satuanbeli',
												'class'=>'form-control',
												'value'=>$satuanbeli
											);
											?>
											<?php echo form_input($satuanbeli_) ?>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Satuan Jual</label>
										<div class="col-sm-10">
											<?php echo form_error('satuanjual') ?>    
											<?php
											$satuanjual_=array(
												'type'=> 'text',
												'name'=> 'satuanjual',
												'class'=>'form-control',
												'value'=>$satuanjual
											);
											?>
											<?php echo form_input($satuanjual_) ?>
										</div>
									</div>
									
												
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Harga Satuan Beli</label>
										<div class="col-sm-10">
											<?php echo form_error('satuanbeli') ?>    
											<?php
											$hargasatuanbeli_=array(
												'type'=> 'number',
												'name'=> 'hargasatuanbeli',
												'class'=>'form-control',
												'value'=>$hargasatuanbeli
											);
											?>
											<?php echo form_input($hargasatuanbeli_) ?>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Harga Satuan Jual</label>
										<div class="col-sm-10">
											<?php echo form_error('hargasatuanjual') ?>    
											<?php
											$hargasatuanjual_=array(
												'type'=> 'number',
												'name'=> 'hargasatuanjual',
												'class'=>'form-control',
												'value'=>$hargasatuanjual
											);
											?>
											<?php echo form_input($hargasatuanjual_) ?>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Lokasi Rak</label>
										<div class="col-sm-10">
											<?php echo form_error('lokasirak') ?>    
											<?php
											$lokasirak_=array(
												'type'=> 'text',
												'name'=> 'lokasirak',
												'class'=>'form-control',
												'value'=>$lokasirak
											);
											?>
											<?php echo form_input($lokasirak_) ?>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Stok</label>
										<div class="col-sm-10">
											<?php echo form_error('stok') ?>    
											<?php
											$stok_=array(
												'type'=> 'number',
												'name'=> 'stok',
												'class'=>'form-control',
												'value'=>$stok
											);
											?>
											<?php echo form_input($stok_) ?>
										</div>
									</div>
														
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Keterangan</label>
										<div class="col-sm-10">
											<?php echo form_error('keterangan') ?>    
											<?php
											$keterangan_=array(
												'type'=> 'textarea',
												'name'=> 'keterangan',
												'class'=>'form-control',
												'value'=>$keterangan
											);
											?>
											<?php echo form_textarea($keterangan_) ?>
										</div>
									</div>
									
                                    <div class="form-group mb-0 row">
                                        <div class="col-12">
											<a href="<?php echo site_url('admin/produk') ?>" class="btn btn-white btn-sm mr-10">Batal</a>
                                            <button class="btn btn-info btn-sm" type="submit">Simpan</button>
                                        </div>
                                    </div>
								<?php echo form_close() ?>
                            </div>
						</div>
                    </div>
					
                </div>
            </div>
        </div>
    </div>
</div>

