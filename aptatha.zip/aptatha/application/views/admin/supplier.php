

                <!-- Breadcrumb Area -->
                <div class="breadcrumb-area" style="padding:20px 5px">
                    <div class="container-fluid">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Administrator</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Daftar Supplier</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Wrapper -->
                <div class="wrapper wrapper-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Ibox -->
                                <div class="ibox bg-boxshadow">
                                    <div class="ibox-title mb-10">
                                        <h5>Daftar Supplier</h5>
                                    </div>

                                    <!-- Ibox Content -->
                                    <div class="ibox-content">
                                        <!-- Table Responsive -->
                                        <div class="table-responsive">
											<div class="">
												<p><a href="<?php echo site_url('admin/addSupplier') ?>" class="btn btn-info"><i class="fa fa-plus"></i> Supplier Baru </a></p>
											</div>
											<?php $no=0; ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-full-supplier">
                                                <thead>
                                                    <tr>
                                                        <th width="50">No</th>
                                                        <th>Nama Supplier</th>
                                                        <th>Alamat</th>
                                                        <th>No. HP</th>
                                                        <th>Email</th>
                                                        <th width="150"></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach ($supplier_data as $supplier){ ?>
                                                    <tr>
                                                        <td><?php echo ++$no ?></td>
                                                        <td><?php echo $supplier->nmsupplier ?></td>
                                                        <td><?php echo $supplier->alamat ?></td>
                                                        <td><?php echo $supplier->nohp ?></td>
                                                        <td><?php echo $supplier->email ?></td>
                                                        <td class="text-right">
															<a href="<?php echo site_url('admin/viewSupplier/'.$supplier->idsupplier)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Lihat"><i class="fa fa-eye fa-white"></i></a>
															<a href="<?php echo site_url('admin/editSupplier/'.$supplier->idsupplier)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Edit"><i class="fa fa-edit fa-white"></i></a>
															<a href="<?php echo site_url('admin/hapusSupplier/'.$supplier->idsupplier)?>" class="btn m-1 btn-xs btn-outline-default" data-placement="top" data-original-title="Hapus"
															   onclick="return confirm('Hapus Supplier <?php echo $supplier->nmsupplier ?>?')"><i class="fa fa-times fa-white"></i></a>
														</td>
                                                    </tr>
													<?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Nama Supplier</th>
                                                        <th>Alamat</th>
                                                        <th>No. HP</th>
                                                        <th>Email</th>
                                                        <th></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
