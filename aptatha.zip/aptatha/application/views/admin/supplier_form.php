

<!-- Breadcrumb Area -->
<div class="breadcrumb-area" style="padding:20px 5px">
	<div class="container-fluid">
		<nav aria-label="breadcrumb">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="#">Administrator</a></li>
				<li class="breadcrumb-item"><a href="<?php echo site_url('admin/supplier') ?>">Supplier</a></li>
				<li class="breadcrumb-item active" aria-current="page">Form Supplier</li>
			</ol>
		</nav>
	</div>
</div>

<!-- Wrapper -->
<div class="wrapper wrapper-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <!-- Ibox -->
				<div class="row">
                    <div class="col-lg-12">
                        <div class="ibox bg-boxshadow mb-50">
                            <!-- Title -->
                            <div class="ibox-title basic-form mb-30">
                                <h5>Form Supplier<small></small></h5>
                            </div>
							<?php $idmessage = $this->session->flashdata('idmessage') ?>
							<?php $message = $this->session->flashdata('message') ?>
							<?php if ($message) { ?>
								<div class="alert <?php echo $idmessage == 1 ? 'alert-danger' : 'alert-info' ?>">
									<button data-dismiss="alert" class="close">
										&times;
									</button>
									<i class="fa fa-info-circle"></i>
									<strong><?php echo $message ?></strong>
								</div>
							<?php } ?>
							
                            <!-- Ibox-content -->
                            <div class="ibox-content">
								<?php if ($state == 'create') { ?>
								<?php echo form_open_multipart($addSupplier_action, "class='form-horizontal'") ?>
								<?php } elseif ($state == 'update') { ?>
								<?php echo form_open_multipart($editSupplier_action, "class='form-horizontal'") ?>
								<?php echo form_hidden('idsupplier', $idsupplier) ?>
								<?php }  ?>									
									
									<div class="form-group row row">
										<label class="col-sm-2 col-form-label">Nama Supplier</label>
										<div class="col-sm-10">
											<?php echo form_error('nmsupplier') ?>    
											<?php echo form_input('nmsupplier', $nmsupplier, 'class="form-control"') ?>
										</div>
									</div>
																					
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Alamat</label>
										<div class="col-sm-10">
											<?php echo form_error('alamat') ?>    
											<?php
											$alamat_=array(
												'type'=> 'text',
												'name'=> 'alamat',
												'class'=>'form-control',
												'value'=>$alamat
											);
											?>
											<?php echo form_textarea($alamat_) ?>
										</div>
									</div>
										
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">No. HP</label>
										<div class="col-sm-10">
											<?php echo form_error('nohp') ?>    
											<?php
											$nohp_=array(
												'type'=> 'text',
												'name'=> 'nohp',
												'class'=>'form-control',
												'value'=>$nohp
											);
											?>
											<?php echo form_input($nohp_) ?>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Email</label>
										<div class="col-sm-10">
											<?php echo form_error('email') ?>    
											<?php
											$email_=array(
												'type'=> 'email',
												'name'=> 'email',
												'class'=>'form-control',
												'value'=>$email
											);
											?>
											<?php echo form_input($email_) ?>
										</div>
									</div>
									
									<div class="form-group row">
										<label class="col-sm-2 col-form-label">Keterangan</label>
										<div class="col-sm-10">
											<?php echo form_error('keterangan') ?>    
											<?php
											$keterangan_=array(
												'type'=> 'textarea',
												'name'=> 'keterangan',
												'class'=>'form-control',
												'value'=>$keterangan
											);
											?>
											<?php echo form_textarea($keterangan_) ?>
										</div>
									</div>
									
                                    <div class="form-group mb-0 row">
                                        <div class="col-12">
											<a href="<?php echo site_url('admin/supplier') ?>" class="btn btn-white btn-sm mr-10">Batal</a>
                                            <button class="btn btn-info btn-sm" type="submit">Simpan</button>
                                        </div>
                                    </div>
								<?php echo form_close() ?>
                            </div>
						</div>
                    </div>
					
                </div>
            </div>
        </div>
    </div>
</div>

