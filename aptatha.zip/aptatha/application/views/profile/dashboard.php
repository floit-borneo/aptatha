<!-- Breadcrumb Area -->
<div class="breadcrumb-area" style="padding:20px 5px">
    <div class="container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard-1.html">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Profile</li>
            </ol>
        </nav>
    </div>
</div>

                <!-- Wrapper -->
<div class="wrapper wrapper-content">
    <div class="container-fluid">

        <div class="row">
            <div class="col">
                <div class="card-- bg-boxshadow mb-30">
                     <h3> Welcome, SuperAdmin! Selamat Bekerja! </h3>
                </div>		
            </div>
        </div>
    </div>
</div>
				
<script>
$(document).ready(function() {
	var options1 = {};
	options1.ui = {
		container: "#pwd-container1",
		showVerdictsInsideProgressBar: true,
		viewports: {
			progress: ".pwstrength_viewport_progress"
		}
	};
	options1.common = {
		debug: false
	};
	$('.example1').pwstrength(options1);
} );



</script>