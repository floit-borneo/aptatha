<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class TransaksiModel extends CI_Model {
	
	/* ^barang masuk */
    function get_all_barangMasuk() {
        $sql = "select atha_barangmasuk.*,
				atha_karyawan.nmkaryawan as nmpembuat,
				atha_supplier.nmsupplier as nmsupplier
                from atha_barangmasuk
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_barangmasuk.idpembuat
				left join atha_supplier on atha_supplier.idsupplier = atha_barangmasuk.idsupplier
				order by idbarangmasuk DESC";
        return $this->db->query($sql)->result();
    }
	
    function get_barangMasuk($idbarangmasuk) {
        $sql = "select atha_barangmasuk.*,
				atha_karyawan.nmkaryawan as nmpembuat,
				atha_supplier.nmsupplier as nmsupplier
                from atha_barangmasuk
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_barangmasuk.idpembuat
				left join atha_supplier on atha_supplier.idsupplier = atha_barangmasuk.idsupplier
                where idbarangmasuk = '$idbarangmasuk'";
        return $this->db->query($sql)->row();
    }
	
    function get_latest_barangMasuk() {
        $sql = "select atha_barangmasuk.idbarangmasuk
                from atha_barangmasuk
				order by idbarangmasuk DESC
                limit 1";
        $row=$this->db->query($sql)->row();
		return $row->idbarangmasuk;
    }
		
    function get_all_itemBarangMasuk($idbarangmasuk) {
        $sql = "select atha_itembarangmasuk.*,
				atha_produk.nmproduk as nmproduk,
				atha_produk.stok as stok
                from atha_itembarangmasuk
				left join atha_produk on atha_produk.idproduk = atha_itembarangmasuk.idproduk
                where idbarangmasuk = '$idbarangmasuk'";
        return $this->db->query($sql)->result();
    }
	
    function get_itemBarangMasuk($iditembarangmasuk) {
        $sql = "select atha_itembarangmasuk.*,
				atha_produk.nmproduk as nmproduk,
				atha_produk.stok as stok
                from atha_itembarangmasuk
				left join atha_produk on atha_produk.idproduk = atha_itembarangmasuk.idproduk
                where iditembarangmasuk = '$iditembarangmasuk'";
        return $this->db->query($sql)->row();
    }
	
	/* ^atha_penjualan dengan resep */
    function get_all_penjualanDgnResep() {
        $sql = "select 
				atha_penjualandgnresep.*,
				atha_karyawan.nmkaryawan as nmpembuat
                from atha_penjualandgnresep
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_penjualandgnresep.idpembuat";
        return $this->db->query($sql)->result();
    }
	
    function get_penjualanDgnResep($idpenjualan) {
        $sql = "select 
				atha_penjualandgnresep.*,
				atha_karyawan.nmkaryawan as nmpembuat
                from atha_penjualandgnresep
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_penjualandgnresep.idpembuat
                where idpenjualan = '$idpenjualan'";
        return $this->db->query($sql)->row();
    }
	
	
    function get_latest_penjualanDgnResep() {
        $sql = "select atha_penjualandgnresep.idpenjualan
                from atha_penjualandgnresep
				order by idpenjualan DESC
                limit 1";
        $row=$this->db->query($sql)->row();
		return $row->idpenjualan;
    }
	
    function get_itemResep($iditemresep) {
        $sql = "select atha_itemresep.*
                from atha_itemresep
				where iditemresep = '$iditemresep'";
        return $this->db->query($sql)->row();
    }
	
    function get_all_itemRacikan($idpenjualan) {
        $sql = "select 
				CONCAT(atha_itemresep.idpenjualan,'/',atha_itemresep.iditemresep) as idpenjualan,
				CONCAT(' -- ',atha_itemresep.idpenjualan,' - ',atha_itemresep.tipe) as id,
				('') as produk,
				atha_itemresep.jumlah,
				atha_itemresep.subtotal,
				atha_itemresep.tipe as tiperesep,
				('') as tipe,
				atha_itemresep.satuan as satuan
				from atha_itemresep
				where atha_itemresep.idpenjualan = '$idpenjualan'
				
				union 
				
				select 
				CONCAT(atha_itemresep.idpenjualan,'/',atha_itemresep.iditemresep,'/',atha_itemracikan.iditemracikan) as idpenjualan,
				CONCAT(' ---- ',atha_itemresep.idpenjualan,' - #',atha_itemracikan.nourut) as id,
				atha_produk.nmproduk as produk,
				atha_itemracikan.jumlah,
				atha_itemracikan.subtotal,
				('') as tiperesep,
				atha_itemresep.tipe as tipe,
				atha_produk.satuanjual as satuan
                from atha_itemracikan
				left join atha_produk on atha_produk.idproduk = atha_itemracikan.idproduk
				left join atha_itemresep on atha_itemresep.iditemresep = atha_itemracikan.iditemresep
				where atha_itemresep.idpenjualan = '$idpenjualan'
				ORDER by idpenjualan";
        return $this->db->query($sql)->result();
    }

    function get_all_itemRacikan_minor($iditemresep) {
        $sql = "select 
				atha_itemracikan.*,
				atha_produk.nmproduk,
				atha_itemresep.iditemresep,
				atha_itemresep.idpenjualan,
				atha_itemresep.tipe
                from atha_itemracikan
				left join atha_produk on atha_produk.idproduk = atha_itemracikan.idproduk
				left join atha_itemresep on atha_itemresep.iditemresep = atha_itemracikan.iditemresep
				where atha_itemracikan.iditemresep = '$iditemresep'";
        return $this->db->query($sql)->result();
    }

    function get_itemRacikan($iditemracikan) {
        $sql = "select 
				atha_itemracikan.*,
				atha_produk.nmproduk,
				atha_itemresep.iditemresep,
				atha_itemresep.idpenjualan,
				atha_itemresep.tipe
                from atha_itemracikan
				left join atha_produk on atha_produk.idproduk = atha_itemracikan.idproduk
				left join atha_itemresep on atha_itemresep.iditemresep = atha_itemracikan.iditemresep
				where iditemracikan = '$iditemracikan'";
        return $this->db->query($sql)->row();
    }
	
    function get_itemNonRacikan($iditemracikan) {
        $sql = "select 
				atha_itemracikan.*,
				atha_produk.nmproduk,
				atha_itemresep.iditemresep,
				atha_itemresep.idpenjualan,
				atha_itemresep.tipe
                from atha_itemracikan
				left join atha_produk on atha_produk.idproduk = atha_itemracikan.idproduk
				left join atha_itemresep on atha_itemresep.iditemresep = atha_itemracikan.iditemresep
				where iditemracikan = '$iditemracikan'";
        return $this->db->query($sql)->row();
    }
	
    function get_latest_itemResep() {
        $sql = "select atha_itemresep.iditemresep
                from atha_itemresep
				order by iditemresep DESC
                limit 1";
        $row=$this->db->query($sql)->row();
		return $row->iditemresep;
    }
	
	function sum_itemResep($idpenjualan){
        $sql = "(select sum(atha_itemresep.subtotal) as subtotal from atha_itemresep where atha_itemresep.idpenjualan = '$idpenjualan')";
        $row=$this->db->query($sql)->row();
		return $row->subtotal;
	}
	
	/* ^atha_penjualan tanpa resep */
    function get_all_penjualanTnpResep() {
        $sql = "select 
				atha_penjualan.*,
				atha_karyawan.nmkaryawan as nmpembuat
                from atha_penjualan
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_penjualan.idpembuat";
        return $this->db->query($sql)->result();
    }
	
    function get_penjualanTnpResep($idpenjualan) {
        $sql = "select atha_penjualan.*,
				atha_karyawan.nmkaryawan as nmpembuat
                from atha_penjualan
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_penjualan.idpembuat
                where idpenjualan = '$idpenjualan'";
        return $this->db->query($sql)->row();
    }
	
    function get_latest_penjualanTnpResep() {
        $sql = "select atha_penjualan.idpenjualan
                from atha_penjualan
				order by idpenjualan DESC
                limit 1";
        $row=$this->db->query($sql)->row();
		return $row->idpenjualan;
    }
	
    function get_all_itemPenjualanTnpResep($idpenjualan) {
        $sql = "select atha_itempenjualan.*,
				atha_produk.satuanjual as satuan,
				atha_produk.nmproduk as nmproduk
                from atha_itempenjualan
				left join atha_produk on atha_produk.idproduk = atha_itempenjualan.idproduk
                where idpenjualan = '$idpenjualan'";
        return $this->db->query($sql)->result();
    }
	
    function get_itemPenjualanTnpResep($iditempenjualan) {
        $sql = "select atha_itempenjualan.*,
				atha_produk.nmproduk as nmproduk
                from atha_itempenjualan
				left join atha_produk on atha_produk.idproduk = atha_itempenjualan.idproduk
                where iditempenjualan = '$iditempenjualan'";
        return $this->db->query($sql)->row();
    }

}
