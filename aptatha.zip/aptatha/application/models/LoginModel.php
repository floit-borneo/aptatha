<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class LoginModel extends CI_Model {
       
    function get_pengguna($email, $password) {
        $sql = "select atha_karyawan.*
                from atha_karyawan
                where                 
                atha_karyawan.email = '$email' and
                atha_karyawan.password = '$password'";
        return $this->db->query($sql)->row();
    }
	
    function get_log($idkaryawan) {
        $sql = "select log.*
				from log
                where                 
                idkaryawan = '$idkaryawan'";
        return $this->db->query($sql)->result();
    }
    function get_hakakses($idkaryawan) {
        $sql = "select atha_hakakses.*,
				bagian.nmbagian
                from hakakses
                left join bagian on bagian.idbagian = hakakses.idbagian 
                where hakakses.idkaryawan = '$idkaryawan'";
        return $this->db->query($sql)->result();
    }
    function get_captcha(){
        $this->load->helper('captcha');
        $this->load->helper('string');
        
        $word = strtoupper(random_string('nozero', 4));
        $this->session->set_userdata('captcha', $word);
        
        $captcha = array(
            'word' => $word,
            'img_path' => './assets/captcha/',
            'img_url' => base_url('assets/captcha'),
            'font_path' => base_url('assets/fonts/monaco.ttf'),
            'img_width' => '135',
            'img_height' => '35',
            'expiration' => '1',
        );
        
        $img = create_captcha($captcha);
        return $img['image'];
    }

}
