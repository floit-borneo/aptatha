<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class AdminModel extends CI_Model {

    function get_pengguna($email) {
        $sql = "select atha_karyawan.*,
                hakakses.idbagian
                from atha_karyawan, hakakses
                where 
                hakakses.idkaryawan = atha_karyawan.idkaryawan and
                atha_karyawan.email = '$email'";
        return $this->db->query($sql)->row();
    }

    function get_password($idkaryawan, $password) {
        $sql = "select atha_karyawan.*
                from atha_karyawan
                where idkaryawan = '$idkaryawan' and
                password = md5('$password')";
        return $this->db->query($sql)->row();
    }
	
	
	/* ^atha_produk */
    function get_all_produk() {
        $sql = "select atha_produk.*,
				atha_kategoriproduk.nmkategori
                from atha_produk
				left join atha_kategoriproduk on atha_kategoriproduk.idkategori = atha_produk.idkategori";
        return $this->db->query($sql)->result();
    }
    function get_produk($idproduk) {
        $sql = "select atha_produk.*,
				atha_kategoriproduk.nmkategori
                from atha_produk
				left join atha_kategoriproduk on atha_kategoriproduk.idkategori = atha_produk.idkategori
                where idproduk = '$idproduk'";
        return $this->db->query($sql)->row();
    }
	
	/* ^kategori atha_produk */
    function get_all_kategori() {
        $sql = "select atha_kategoriproduk.*
                from atha_kategoriproduk
";
        return $this->db->query($sql)->result();
    }
    function get_kategori($idkategori) {
        $sql = "select atha_kategoriproduk.*
                from atha_kategoriproduk
                where idkategori = '$idkategori'";
        return $this->db->query($sql)->row();
    }
	
	/* ^atha_karyawan */
    function get_all_karyawan() {
        $sql = "select atha_karyawan.*
                from atha_karyawan";
        return $this->db->query($sql)->result();
    }
	
    function get_karyawan($idkaryawan) {
        $sql = "select atha_karyawan.*
                from atha_karyawan
                where atha_karyawan.idkaryawan = $idkaryawan";
        return $this->db->query($sql)->row();
    }
	
    function get_latest_karyawan() {
        $sql = "select atha_karyawan.idkaryawan
                from atha_karyawan
				order by idkaryawan DESC
                limit 1";
        $row=$this->db->query($sql)->row();
		return $row->idkaryawan;
    }
	
	/* ^atha_supplier */
    function get_all_supplier() {
        $sql = "select atha_supplier.*
                from atha_supplier";
        return $this->db->query($sql)->result();
    }
    function get_supplier($idsupplier) {
        $sql = "select atha_supplier.*
                from atha_supplier
                where idsupplier = '$idsupplier'";
        return $this->db->query($sql)->row();
    }
	

}
