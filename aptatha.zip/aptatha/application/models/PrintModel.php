<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class PrintModel extends CI_Model {

	/* ^penjualan dengan resep */
	
    function get_penjualanDgnResep($idpenjualan) {
        $sql = "select 
				atha_penjualandgnresep.*,
				atha_karyawan.nmkaryawan as nmpembuat,
				atha_penjualandgnresep.nmdokter as nmdokter
                from atha_penjualandgnresep
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_penjualandgnresep.idpembuat
                where idpenjualan = '$idpenjualan'";
        return $this->db->query($sql)->row();
    }
    function get_all_itemRacikan($idpenjualan) {
        $sql = "select 
				CONCAT(atha_itemresep.idpenjualan,'/',atha_itemresep.iditemresep) as idpenjualan,
				CONCAT(' -- ',atha_itemresep.idpenjualan,' - ',atha_itemresep.tipe) as id,
				('') as produk,
				atha_itemresep.jumlah,
				atha_itemresep.subtotal,
				atha_itemresep.tipe as tiperesep,
				('') as tuslah,
				atha_itemresep.satuan as satuan
				from atha_itemresep
				where atha_itemresep.idpenjualan = '$idpenjualan'
				
				union 
				
				select 
				CONCAT(atha_itemresep.idpenjualan,'/',atha_itemresep.iditemresep,'/',atha_itemracikan.iditemracikan) as idpenjualan,
				CONCAT(' ---- ',atha_itemresep.idpenjualan,' - #',atha_itemracikan.nourut) as id,
				atha_produk.nmproduk as produk,
				atha_itemracikan.jumlah,
				atha_itemracikan.subtotal,
				atha_itemresep.tipe as tiperesep,
				('') as tuslah,
				atha_produk.satuanjual as satuan
                from atha_itemracikan
				left join atha_produk on atha_produk.idproduk = atha_itemracikan.idproduk
				left join atha_itemresep on atha_itemresep.iditemresep = atha_itemracikan.iditemresep
				where atha_itemresep.idpenjualan = '$idpenjualan'
				
				union
				
				select 
				CONCAT(atha_itemresep.idpenjualan,'/',atha_itemresep.iditemresep,'/tuslah') as idpenjualan,
				CONCAT(' -- ',atha_itemresep.idpenjualan,' - ',atha_itemresep.tipe) as id,
				('Kapsul/Puyer') as produk,
				atha_itemresep.jumlah,
				atha_itemresep.tuslah as subtotal,
				atha_itemresep.tipe as tiperesep,
				('tuslah') as tuslah,
				atha_itemresep.satuan as satuan
				from atha_itemresep
				where atha_itemresep.idpenjualan = '$idpenjualan'
				ORDER by idpenjualan";
        return $this->db->query($sql)->result();
    }


}
