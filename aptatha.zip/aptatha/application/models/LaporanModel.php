<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class LaporanModel extends CI_Model {

	function get_total_penjualantnpresep(){
        $sql = "SELECT SUM(atha_penjualan.total) AS result
				FROM atha_penjualan;";
        $row = $this->db->query($sql)->row();
		return $row->result;
	}
	
	function get_total_penjualandgnresep(){
        $sql = "SELECT SUM(atha_penjualandgnresep.total) AS result
				FROM atha_penjualandgnresep;";
        $row = $this->db->query($sql)->row();
		return $row->result;
	}
	
	function get_total_persediaanbarang(){
        $sql = "SELECT SUM(atha_produk.stok*atha_produk.hargasatuanbeli) AS result
				FROM atha_produk;";
        $row = $this->db->query($sql)->row();
		return $row->result;
	}
	
	function get_total_laba(){
        $sql1 = "SELECT SUM(atha_itemracikan.labaperitem) AS result
				FROM atha_itemracikan;";
        $row1 = $this->db->query($sql1)->row();
		$laba1= $row1->result;
		
        $sql2 = "SELECT SUM(atha_itempenjualan.labaperitem) AS result
				FROM atha_itempenjualan;";
        $row2 = $this->db->query($sql2)->row();
		$laba2= $row2->result;
		
		return $laba1+$laba2;
	}
	
	function get_total_potonganpembelian(){
        $sql = "SELECT SUM((100*atha_itembarangmasuk.subtotal)/(100-atha_itembarangmasuk.diskon)) AS result
				FROM atha_itembarangmasuk;";
        $row = $this->db->query($sql)->row();
				
		return $row->result;
	}
	
	function get_total_potonganpenjualan(){
        $sql1 = "SELECT SUM(((100*atha_penjualandgnresep.total)/(100-atha_penjualandgnresep.diskon))*atha_penjualandgnresep.diskon/100) AS result
				FROM atha_penjualandgnresep;";
        $row1 = $this->db->query($sql1)->row();
		
		
        $sql2 = "SELECT SUM(((100*atha_penjualan.total)/(100-atha_penjualan.diskon))*atha_penjualan.diskon/100) AS result
				FROM atha_penjualan;";
        $row2 = $this->db->query($sql2)->row();
		
		return $row1->result+$row2->result;
	}
	
	function get_total_pendapatantuslah(){
        $sql = "SELECT SUM(atha_itemresep.tuslah) AS result
				FROM atha_itemresep;";
        $row = $this->db->query($sql)->row();
		return $row->result;
	}
	/*	
	function get_total_hutangdagang(){
        $sql = "SELECT SUM(atha_barangmasuk.sisa) AS result
				FROM atha_barangmasuk;";
        $row = $this->db->query($sql)->row();
		return $row->result;
	}*/
	function get_total_hutangdagang(){
        $sql = "SELECT SUM(pembayaran.jumlah) AS result
				FROM pembayaran;";
        $row = $this->db->query($sql)->row();
		return $row->result;
	}
		
    function get_latest_bukubesar() {
        $sql = "select atha_bukubesar.idbukubesar
                from atha_bukubesar
				order by atha_bukubesar.idbukubesar DESC
                limit 1";
        $row=$this->db->query($sql)->row();
		return $row->idbukubesar;
    }
	
    function get_bukuBesar($idbukubesar) {
        $sql = "select atha_bukubesar.*
                from atha_bukubesar
				where idbukubesar = '$idbukubesar'";
        return $this->db->query($sql)->row();
    }
	
    function get_all_bukuBesar() {
        $sql = "select atha_bukubesar.*
                from atha_bukubesar
				order by idbukubesar DESC";
        return $this->db->query($sql)->result();
    }
	
    function get_barangMasuk($idbarangmasuk) {
        $sql = "select atha_barangmasuk.*,
				atha_karyawan.nmkaryawan as nmpembuat,
				atha_supplier.nmsupplier as nmsupplier,
				atha_supplier.alamat as alamat,
				atha_supplier.nohp as nohp,
				atha_supplier.email as email
                from atha_barangmasuk
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_barangmasuk.idpembuat
				left join atha_supplier on atha_supplier.idsupplier = atha_barangmasuk.idsupplier
                where idbarangmasuk = '$idbarangmasuk'";
        return $this->db->query($sql)->row();
    }
	
    function get_pembayaran($idbarangmasuk) {
        $sql = "select pembayaran.*,
				atha_karyawan.nmkaryawan as nmpembuat,
				atha_supplier.nmsupplier as nmsupplier,
				atha_barangmasuk.tglfaktur as tglfaktur,
				atha_barangmasuk.nofaktur as nofaktur,
				atha_barangmasuk.tglbarangmasuk as tglbarangmasuk
                from pembayaran
				left join atha_barangmasuk on atha_barangmasuk.idbarangmasuk = pembayaran.idbarangmasuk
				left join atha_karyawan on atha_karyawan.idkaryawan = pembayaran.idpembuat
				left join atha_supplier on atha_supplier.idsupplier = atha_barangmasuk.idsupplier
				where pembayaran.idbarangmasuk ='$idbarangmasuk'
				order by idpembayaran DESC";
        return $this->db->query($sql)->row();
    }
	
    function get_all_pembayaran() {
        $sql = "select pembayaran.*,
				atha_karyawan.nmkaryawan as nmpembuat,
				atha_supplier.nmsupplier as nmsupplier,
				atha_barangmasuk.tglfaktur as tglfaktur,
				atha_barangmasuk.nofaktur as nofaktur,
				atha_barangmasuk.tglbarangmasuk as tglbarangmasuk,
				atha_barangmasuk.total as total,
				atha_barangmasuk.total_sementara as total_sementara,
				atha_barangmasuk.sisa as sisa,
				atha_barangmasuk.status as status
                from pembayaran
				left join atha_barangmasuk on atha_barangmasuk.idbarangmasuk = pembayaran.idbarangmasuk
				left join atha_karyawan on atha_karyawan.idkaryawan = pembayaran.idpembuat
				left join atha_supplier on atha_supplier.idsupplier = atha_barangmasuk.idsupplier
				order by idpembayaran DESC";
        return $this->db->query($sql)->result();
    }
	
    function get_all_transaksi() {
        $sql = "select 
				CONCAT('Res-',atha_penjualandgnresep.idpenjualan) as kolom1,
				atha_penjualandgnresep.tglpenjualan as kolom2,
				('') as kolom3,
				('') as kolom4,
				atha_penjualandgnresep.total as kolom5,
				atha_penjualandgnresep.keterangan as kolom6,
				(select sum(atha_itemracikan.labaperitem)) as kolom7
                from atha_penjualandgnresep
				left join atha_itemresep on atha_penjualandgnresep.idpenjualan = atha_itemresep.idpenjualan
				left join atha_itemracikan on atha_itemresep.iditemresep = atha_itemracikan.iditemresep
				
				union
				
				select 
				CONCAT('NRes-',atha_penjualan.idpenjualan) as kolom1,
				atha_penjualan.tglpenjualan as kolom2,
				('') as kolom3,
				('') as kolom4,
				atha_penjualan.total as kolom5,
				atha_penjualan.keterangan as kolom6,
				(select sum(atha_itempenjualan.labaperitem)) as kolom7
				from atha_penjualan
				left join atha_itempenjualan on atha_penjualan.idpenjualan = atha_itempenjualan.idpenjualan

				union
				
				select 
				CONCAT('BM-',atha_barangmasuk.idbarangmasuk) as kolom1,
				atha_barangmasuk.tglbarangmasuk as kolom2,
				atha_supplier.nmsupplier as kolom3,
				atha_barangmasuk.total as kolom4,
				('') as kolom5,
				atha_barangmasuk.keterangan as kolom6,
				('') as kolom7
				from atha_barangmasuk
				left join atha_supplier on atha_barangmasuk.idsupplier = atha_supplier.idsupplier
				";
        return $this->db->query($sql)->result();
		
	}
	
    function get_all_barangMasuk() {
        $sql = "select 
				atha_barangmasuk.idbarangmasuk as kolom1,
				atha_karyawan.nmkaryawan as kolom2,
				atha_barangmasuk.tglbarangmasuk as kolom3,
				atha_supplier.nmsupplier as kolom4,
				atha_barangmasuk.nofaktur as kolom5,
				atha_barangmasuk.tglfaktur as kolom6,
				CONCAT(atha_barangmasuk.jumlah,' atha_produk') as kolom7,
				CONCAT('PPN: ',atha_barangmasuk.ppn,'%') as kolom8,
				atha_barangmasuk.total as kolom9,
				atha_barangmasuk.status as kolom10,
				atha_barangmasuk.keterangan as kolom11,
				atha_barangmasuk.jumlah as kolom12,
				('<b>') as kolom13,
				('</b>') as kolom14,
				('') as kolom15
                from atha_barangmasuk
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_barangmasuk.idpembuat
				left join atha_supplier on atha_supplier.idsupplier = atha_barangmasuk.idsupplier
				
				union 
				
				select 
				CONCAT(atha_itembarangmasuk.idbarangmasuk,'/',atha_itembarangmasuk.iditembarangmasuk) as kolom1,
				('') as kolom2,
				('') as kolom3,
				atha_produk.nmproduk as kolom4,
				atha_itembarangmasuk.batch as kolom5,
				atha_itembarangmasuk.tglkdluarsa as kolom6,
				CONCAT(atha_itembarangmasuk.jumlah,' ',atha_produk.satuanbeli,' @',atha_itembarangmasuk.harga) as kolom7,
				CONCAT('Diskon: ',atha_itembarangmasuk.diskon,'%') as kolom8,
				atha_itembarangmasuk.subtotal as kolom9,
				('') as kolom10,
				('') as kolom11,
				('') as kolom12,
				('') as kolom13,
				('') as kolom14,
				atha_itembarangmasuk.jumlah as kolom15
                from atha_itembarangmasuk
				left join atha_produk on atha_produk.idproduk = atha_itembarangmasuk.idproduk
				
				ORDER by kolom1";
        return $this->db->query($sql)->result();
    }
	
	function get_all_penjualan() {
        $sql = "select 
				CONCAT('Res-',atha_penjualandgnresep.idpenjualan) as kolom1,
				atha_karyawan.nmkaryawan as kolom2,
				atha_penjualandgnresep.tglpenjualan as kolom3,
				atha_penjualandgnresep.nmdokter as kolom4,
				CONCAT(atha_penjualandgnresep.jumlah,' atha_produk') as kolom5,
				CONCAT('Diskon: ',atha_penjualandgnresep.diskon,'%') as kolom6,
				atha_penjualandgnresep.total as kolom7,
				atha_penjualandgnresep.keterangan as kolom8,
				('<b>') as kolom9,
				('</b>') as kolom10,
				('') as kolom11,
				('') as kolom12
                from atha_penjualandgnresep
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_penjualandgnresep.idpembuat
				
				union 
				
				select 
				CONCAT('Res-',atha_itemresep.idpenjualan,'/',atha_itemresep.iditemresep) as kolom1,
				('') as kolom2,
				('') as kolom3,
				CONCAT('<b>',atha_itemresep.tipe,'</b>') as kolom4,
				CONCAT(atha_itemresep.jumlah_produk,' atha_produk, ',atha_itemresep.jumlah,' ',atha_itemresep.satuan) as kolom5,
				('Subtotal') as kolom6,
				atha_itemresep.subtotal as kolom7,
				('') as kolom8,
				('') as kolom9,
				('') as kolom10,
				('') as kolom11,
				atha_itemresep.jumlah_produk as kolom12
                from atha_itemresep
				
				union
				
				select 
				CONCAT('Res-',atha_itemresep.idpenjualan,'/',atha_itemresep.iditemresep,'/',atha_itemracikan.nourut) as kolom1,
				('') as kolom2,
				('') as kolom3,
				atha_produk.nmproduk as kolom4,
				CONCAT(atha_itemracikan.jumlah,' ',atha_itemresep.satuan,' @',atha_itemracikan.harga) as kolom5,
				('') as kolom6,
				atha_itemracikan.subtotal as kolom7,
				('') as kolom8,
				('') as kolom9,
				('') as kolom10,
				atha_itemracikan.jumlah as kolom11,
				('') as kolom12
                from atha_itemracikan
				left join atha_produk on atha_produk.idproduk = atha_itemracikan.idproduk
				left join atha_itemresep on atha_itemresep.iditemresep = atha_itemracikan.iditemresep
				
				union				
				
				select 
				CONCAT('NRes-',atha_penjualan.idpenjualan) as kolom1,
				atha_karyawan.nmkaryawan as kolom2,
				atha_penjualan.tglpenjualan as kolom3,
				('-') as kolom4,
				CONCAT(atha_penjualan.jumlah,' atha_produk') as kolom5,
				CONCAT('Diskon: ',atha_penjualan.diskon,'%') as kolom6,
				atha_penjualan.total as kolom7,
				atha_penjualan.keterangan as kolom8,
				('<b>') as kolom9,
				('</b>') as kolom10,
				('') as kolom11,
				atha_penjualan.jumlah as kolom12
                from atha_penjualan
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_penjualan.idpembuat
				
				union 
				
				select 
				CONCAT('NRes-',atha_itempenjualan.idpenjualan,'/',atha_itempenjualan.iditempenjualan) as kolom1,
				('') as kolom2,
				('') as kolom3,
				atha_produk.nmproduk as kolom4,
				CONCAT(atha_itempenjualan.jumlah,' ',atha_produk.satuanjual,' @',atha_itempenjualan.harga) as kolom5,
				CONCAT('Diskon: ',atha_itempenjualan.diskon,'%') as kolom6,
				atha_itempenjualan.subtotal as kolom7,
				('') as kolom8,
				('') as kolom9,
				('') as kolom10,
				atha_itempenjualan.jumlah as kolom11,
				('') as kolom12
                from atha_itempenjualan
				left join atha_produk on atha_produk.idproduk = atha_itempenjualan.idproduk
				
				ORDER by kolom1
				";
        return $this->db->query($sql)->result();
    }
	
    function get_all_penjualanDgnResep() {
        $sql = "select 
				atha_penjualandgnresep.idpenjualan as kolom1,
				atha_karyawan.nmkaryawan as kolom2,
				atha_penjualandgnresep.tglpenjualan as kolom3,
				atha_penjualandgnresep.nmdokter as kolom4,
				CONCAT(atha_penjualandgnresep.jumlah,' atha_produk') as kolom5,
				CONCAT('Diskon: ',atha_penjualandgnresep.diskon,'%') as kolom6,
				atha_penjualandgnresep.total as kolom7,
				atha_penjualandgnresep.keterangan as kolom8,
				('<b>') as kolom9,
				('</b>') as kolom10,
				('') as kolom11,
				('') as kolom12
                from atha_penjualandgnresep
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_penjualandgnresep.idpembuat
				
				union 
				
				select 
				CONCAT(atha_itemresep.idpenjualan,'/',atha_itemresep.iditemresep) as kolom1,
				('') as kolom2,
				('') as kolom3,
				CONCAT('<b>',atha_itemresep.tipe,'</b>') as kolom4,
				CONCAT(atha_itemresep.jumlah_produk,' atha_produk, ',atha_itemresep.jumlah,' ',atha_itemresep.satuan) as kolom5,
				('Subtotal') as kolom6,
				atha_itemresep.subtotal as kolom7,
				('') as kolom8,
				('') as kolom9,
				('') as kolom10,
				('') as kolom11,
				atha_itemresep.jumlah_produk as kolom12
                from atha_itemresep
				
				union
				
				select 
				CONCAT(atha_itemresep.idpenjualan,'/',atha_itemresep.iditemresep,'/',atha_itemracikan.nourut) as kolom1,
				('') as kolom2,
				('') as kolom3,
				atha_produk.nmproduk as kolom4,
				CONCAT(atha_itemracikan.jumlah,' ',atha_itemresep.satuan,' @',atha_itemracikan.harga) as kolom5,
				('') as kolom6,
				atha_itemracikan.subtotal as kolom7,
				('') as kolom8,
				('') as kolom9,
				('') as kolom10,
				atha_itemracikan.jumlah as kolom11,
				('') as kolom12
                from atha_itemracikan
				left join atha_produk on atha_produk.idproduk = atha_itemracikan.idproduk
				left join atha_itemresep on atha_itemresep.iditemresep = atha_itemracikan.iditemresep
				
				ORDER by kolom1
				";
        return $this->db->query($sql)->result();
    }
	
    function get_all_penjualanTnpResep() {
        $sql = "select 
				atha_penjualan.idpenjualan as kolom1,
				atha_karyawan.nmkaryawan as kolom2,
				atha_penjualan.tglpenjualan as kolom3,
				('') as kolom4,
				CONCAT(atha_penjualan.jumlah,' atha_produk') as kolom5,
				CONCAT('Diskon: ',atha_penjualan.diskon,'%') as kolom6,
				atha_penjualan.total as kolom7,
				atha_penjualan.keterangan as kolom8,
				('<b>') as kolom9,
				('</b>') as kolom10,
				('') as kolom11,
				atha_penjualan.jumlah as kolom12
                from atha_penjualan
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_penjualan.idpembuat
				
				union 
				
				select 
				CONCAT(atha_itempenjualan.idpenjualan,'/',atha_itempenjualan.iditempenjualan) as kolom1,
				('') as kolom2,
				('') as kolom3,
				atha_produk.nmproduk as kolom4,
				CONCAT(atha_itempenjualan.jumlah,' ',atha_produk.satuanjual,' @',atha_itempenjualan.harga) as kolom5,
				CONCAT('Diskon: ',atha_itempenjualan.diskon,'%') as kolom6,
				atha_itempenjualan.subtotal as kolom7,
				('') as kolom8,
				('') as kolom9,
				('') as kolom10,
				atha_itempenjualan.jumlah as kolom11,
				('') as kolom12
                from atha_itempenjualan
				left join atha_produk on atha_produk.idproduk = atha_itempenjualan.idproduk
				
				ORDER by kolom1
				";
        return $this->db->query($sql)->result();
    }

	/* ^print laporan */
    function get_print_penjualan($tglawal,$tglakhir) {
        $sql = "select 
				CONCAT('Res-',atha_penjualandgnresep.idpenjualan) as kolom1,
				atha_karyawan.nmkaryawan as kolom2,
				atha_penjualandgnresep.tglpenjualan as kolom3,
				atha_penjualandgnresep.nmdokter as kolom4,
				CONCAT(atha_penjualandgnresep.jumlah,' atha_produk') as kolom5,
				CONCAT('Diskon: ',atha_penjualandgnresep.diskon,'%') as kolom6,
				atha_penjualandgnresep.total as kolom7,
				atha_penjualandgnresep.keterangan as kolom8,
				('<b>') as kolom9,
				('</b>') as kolom10,
				('') as kolom11,
				('') as kolom12
                from atha_penjualandgnresep
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_penjualandgnresep.idpembuat
				where atha_penjualandgnresep.tglpenjualan >= '$tglawal' AND atha_penjualandgnresep.tglpenjualan <= '$tglakhir' 
				
				union 
				
				select 
				CONCAT('Res-',atha_itemresep.idpenjualan,'/',atha_itemresep.iditemresep) as kolom1,
				('') as kolom2,
				('') as kolom3,
				CONCAT('<b>',atha_itemresep.tipe,'</b>') as kolom4,
				CONCAT(atha_itemresep.jumlah_produk,' atha_produk, ',atha_itemresep.jumlah,' ',atha_itemresep.satuan) as kolom5,
				('Subtotal') as kolom6,
				atha_itemresep.subtotal as kolom7,
				('') as kolom8,
				('') as kolom9,
				('') as kolom10,
				('') as kolom11,
				atha_itemresep.jumlah_produk as kolom12
                from atha_itemresep
				left join atha_penjualandgnresep on atha_penjualandgnresep.idpenjualan = atha_itemresep.idpenjualan
				where atha_penjualandgnresep.tglpenjualan >= '$tglawal' AND atha_penjualandgnresep.tglpenjualan <= '$tglakhir' 
				
				union
				
				select 
				CONCAT('Res-',atha_itemresep.idpenjualan,'/',atha_itemresep.iditemresep,'/',atha_itemracikan.nourut) as kolom1,
				('') as kolom2,
				('') as kolom3,
				atha_produk.nmproduk as kolom4,
				CONCAT(atha_itemracikan.jumlah,' ',atha_itemresep.satuan,' @',atha_itemracikan.harga) as kolom5,
				('') as kolom6,
				atha_itemracikan.subtotal as kolom7,
				('') as kolom8,
				('') as kolom9,
				('') as kolom10,
				atha_itemracikan.jumlah as kolom11,
				('') as kolom12
                from atha_itemracikan
				left join atha_produk on atha_produk.idproduk = atha_itemracikan.idproduk
				left join atha_itemresep on atha_itemresep.iditemresep = atha_itemracikan.iditemresep
				left join atha_penjualandgnresep on atha_penjualandgnresep.idpenjualan = atha_itemresep.idpenjualan
				where atha_penjualandgnresep.tglpenjualan >= '$tglawal' AND atha_penjualandgnresep.tglpenjualan <= '$tglakhir' 
				
				union				
				
				select 
				CONCAT('NRes-',atha_penjualan.idpenjualan) as kolom1,
				atha_karyawan.nmkaryawan as kolom2,
				atha_penjualan.tglpenjualan as kolom3,
				('-') as kolom4,
				CONCAT(atha_penjualan.jumlah,' atha_produk') as kolom5,
				CONCAT('Diskon: ',atha_penjualan.diskon,'%') as kolom6,
				atha_penjualan.total as kolom7,
				atha_penjualan.keterangan as kolom8,
				('<b>') as kolom9,
				('</b>') as kolom10,
				('') as kolom11,
				atha_penjualan.jumlah as kolom12
                from atha_penjualan
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_penjualan.idpembuat
				where atha_penjualan.tglpenjualan >= '$tglawal' AND atha_penjualan.tglpenjualan <= '$tglakhir' 
				
				union 
				
				select 
				CONCAT('NRes-',atha_itempenjualan.idpenjualan,'/',atha_itempenjualan.iditempenjualan) as kolom1,
				('') as kolom2,
				('') as kolom3,
				atha_produk.nmproduk as kolom4,
				CONCAT(atha_itempenjualan.jumlah,' ',atha_produk.satuanjual,' @',atha_itempenjualan.harga) as kolom5,
				CONCAT('Diskon: ',atha_itempenjualan.diskon,'%') as kolom6,
				atha_itempenjualan.subtotal as kolom7,
				('') as kolom8,
				('') as kolom9,
				('') as kolom10,
				atha_itempenjualan.jumlah as kolom11,
				('') as kolom12
                from atha_itempenjualan
				left join atha_produk on atha_produk.idproduk = atha_itempenjualan.idproduk
				left join atha_penjualan on atha_penjualan.idpenjualan = atha_itempenjualan.idpenjualan
				where atha_penjualan.tglpenjualan >= '$tglawal' AND atha_penjualan.tglpenjualan <= '$tglakhir' 
				
				ORDER by kolom1
				";
        return $this->db->query($sql)->result();
    }
	
    function get_print_penjualanTnpResep($tglawal,$tglakhir) {
        $sql = "select 
				atha_penjualan.idpenjualan as kolom1,
				atha_karyawan.nmkaryawan as kolom2,
				atha_penjualan.tglpenjualan as kolom3,
				('') as kolom4,
				CONCAT(atha_penjualan.jumlah,' atha_produk') as kolom5,
				CONCAT('Diskon: ',atha_penjualan.diskon,'%') as kolom6,
				atha_penjualan.total as kolom7,
				atha_penjualan.keterangan as kolom8,
				('<b>') as kolom9,
				('</b>') as kolom10,
				('') as kolom11,
				atha_penjualan.jumlah as kolom12
                from atha_penjualan
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_penjualan.idpembuat
				where atha_penjualan.tglpenjualan >= '$tglawal' AND atha_penjualan.tglpenjualan <= '$tglakhir' 
				
				union 
				
				select 
				CONCAT(atha_itempenjualan.idpenjualan,'/',atha_itempenjualan.iditempenjualan) as kolom1,
				('') as kolom2,
				('') as kolom3,
				atha_produk.nmproduk as kolom4,
				CONCAT(atha_itempenjualan.jumlah,' ',atha_produk.satuanjual,' @',atha_itempenjualan.harga) as kolom5,
				CONCAT('Diskon: ',atha_itempenjualan.diskon,'%') as kolom6,
				atha_itempenjualan.subtotal as kolom7,
				('') as kolom8,
				('') as kolom9,
				('') as kolom10,
				atha_itempenjualan.jumlah as kolom11,
				('') as kolom12
                from atha_itempenjualan
				left join atha_produk on atha_produk.idproduk = atha_itempenjualan.idproduk
				left join atha_penjualan on atha_penjualan.idpenjualan = atha_itempenjualan.idpenjualan
				where atha_penjualan.tglpenjualan >= '$tglawal' AND atha_penjualan.tglpenjualan <= '$tglakhir' 
				
				ORDER by kolom1
				";
        return $this->db->query($sql)->result();
    }
	
    function get_print_penjualanDgnResep($tglawal,$tglakhir) {
        $sql = "select 
				atha_penjualandgnresep.idpenjualan as kolom1,
				atha_karyawan.nmkaryawan as kolom2,
				atha_penjualandgnresep.tglpenjualan as kolom3,
				atha_penjualandgnresep.nmdokter as kolom4,
				CONCAT(atha_penjualandgnresep.jumlah,' atha_produk') as kolom5,
				CONCAT('Diskon: ',atha_penjualandgnresep.diskon,'%') as kolom6,
				atha_penjualandgnresep.total as kolom7,
				atha_penjualandgnresep.keterangan as kolom8,
				('<b>') as kolom9,
				('</b>') as kolom10,
				('') as kolom11,
				('') as kolom12
                from atha_penjualandgnresep
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_penjualandgnresep.idpembuat
				where atha_penjualandgnresep.tglpenjualan >= '$tglawal' AND atha_penjualandgnresep.tglpenjualan <= '$tglakhir' 
				
				union 
				
				select 
				CONCAT(atha_itemresep.idpenjualan,'/',atha_itemresep.iditemresep) as kolom1,
				('') as kolom2,
				('') as kolom3,
				CONCAT('<b>',atha_itemresep.tipe,'</b>') as kolom4,
				CONCAT(atha_itemresep.jumlah_produk,' atha_produk, ',atha_itemresep.jumlah,' ',atha_itemresep.satuan) as kolom5,
				('Subtotal') as kolom6,
				atha_itemresep.subtotal as kolom7,
				('') as kolom8,
				('') as kolom9,
				('') as kolom10,
				('') as kolom11,
				atha_itemresep.jumlah_produk as kolom12
                from atha_itemresep
				left join atha_penjualandgnresep on atha_penjualandgnresep.idpenjualan = atha_itemresep.idpenjualan
				where atha_penjualandgnresep.tglpenjualan >= '$tglawal' AND atha_penjualandgnresep.tglpenjualan <= '$tglakhir' 
				
				union
				
				select 
				CONCAT(atha_itemresep.idpenjualan,'/',atha_itemresep.iditemresep,'/',atha_itemracikan.nourut) as kolom1,
				('') as kolom2,
				('') as kolom3,
				atha_produk.nmproduk as kolom4,
				CONCAT(atha_itemracikan.jumlah,' ',atha_itemresep.satuan,' @',atha_itemracikan.harga) as kolom5,
				('') as kolom6,
				atha_itemracikan.subtotal as kolom7,
				('') as kolom8,
				('') as kolom9,
				('') as kolom10,
				atha_itemracikan.jumlah as kolom11,
				('') as kolom12
                from atha_itemracikan
				left join atha_produk on atha_produk.idproduk = atha_itemracikan.idproduk
				left join atha_itemresep on atha_itemresep.iditemresep = atha_itemracikan.iditemresep
				left join atha_penjualandgnresep on atha_penjualandgnresep.idpenjualan = atha_itemresep.idpenjualan
				where atha_penjualandgnresep.tglpenjualan >= '$tglawal' AND atha_penjualandgnresep.tglpenjualan <= '$tglakhir' 
				
				ORDER by kolom1
				";
        return $this->db->query($sql)->result();
    }
	
    function get_print_barangMasuk($tglawal,$tglakhir) {
        $sql = "select 
				atha_barangmasuk.idbarangmasuk as kolom1,
				atha_karyawan.nmkaryawan as kolom2,
				atha_barangmasuk.tglbarangmasuk as kolom3,
				atha_supplier.nmsupplier as kolom4,
				atha_barangmasuk.nofaktur as kolom5,
				atha_barangmasuk.tglfaktur as kolom6,
				CONCAT(atha_barangmasuk.jumlah,' atha_produk') as kolom7,
				CONCAT('PPN: ',atha_barangmasuk.ppn,'%') as kolom8,
				atha_barangmasuk.total as kolom9,
				atha_barangmasuk.status as kolom10,
				atha_barangmasuk.keterangan as kolom11,
				atha_barangmasuk.jumlah as kolom12,
				('<b>') as kolom13,
				('</b>') as kolom14,
				('') as kolom15
                from atha_barangmasuk
				left join atha_karyawan on atha_karyawan.idkaryawan = atha_barangmasuk.idpembuat
				left join atha_supplier on atha_supplier.idsupplier = atha_barangmasuk.idsupplier
				where atha_barangmasuk.tglbarangmasuk >= '$tglawal' AND atha_barangmasuk.tglbarangmasuk <= '$tglakhir' 
				
				union 
				
				select 
				CONCAT(atha_itembarangmasuk.idbarangmasuk,'/',atha_itembarangmasuk.iditembarangmasuk) as kolom1,
				('') as kolom2,
				('') as kolom3,
				atha_produk.nmproduk as kolom4,
				atha_itembarangmasuk.batch as kolom5,
				atha_itembarangmasuk.tglkdluarsa as kolom6,
				CONCAT(atha_itembarangmasuk.jumlah,' ',atha_produk.satuanbeli,' @',atha_itembarangmasuk.harga) as kolom7,
				CONCAT('Diskon: ',atha_itembarangmasuk.diskon,'%') as kolom8,
				atha_itembarangmasuk.subtotal as kolom9,
				('') as kolom10,
				('') as kolom11,
				('') as kolom12,
				('') as kolom13,
				('') as kolom14,
				atha_itembarangmasuk.jumlah as kolom15
                from atha_itembarangmasuk
				left join atha_produk on atha_produk.idproduk = atha_itembarangmasuk.idproduk
				left join atha_barangmasuk on atha_barangmasuk.idbarangmasuk = atha_itembarangmasuk.idbarangmasuk
				where atha_barangmasuk.tglbarangmasuk >= '$tglawal' AND atha_barangmasuk.tglbarangmasuk <= '$tglakhir' 
				
				ORDER by kolom1";
        return $this->db->query($sql)->result();
    }
	
    //function get_print_produk($tglawal,$tglakhir) {
	function get_print_produk() {
        $sql = "select atha_produk.*,
				atha_kategoriproduk.nmkategori
                from atha_produk
				left join atha_kategoriproduk on atha_kategoriproduk.idkategori = atha_produk.idkategori";
        return $this->db->query($sql)->result();
    }
	
    function get_print_pembayaran($tglawal,$tglakhir) {
        $sql = "select pembayaran.*,
				atha_karyawan.nmkaryawan as nmpembuat,
				atha_supplier.nmsupplier as nmsupplier,
				atha_barangmasuk.tglfaktur as tglfaktur,
				atha_barangmasuk.nofaktur as nofaktur,
				atha_barangmasuk.tglbarangmasuk as tglbarangmasuk
                from pembayaran
				left join atha_barangmasuk on atha_barangmasuk.idbarangmasuk = pembayaran.idbarangmasuk
				left join atha_karyawan on atha_karyawan.idkaryawan = pembayaran.idpembuat
				left join atha_supplier on atha_supplier.idsupplier = atha_barangmasuk.idsupplier
				where pembayaran.tglpembayaran >= '$tglawal' AND pembayaran.tglpembayaran <= '$tglakhir' 
				order by idpembayaran DESC";
        return $this->db->query($sql)->result();
    }
	
    function get_print_transaksi_penjualan($tglawal,$tglakhir) {
        $sql = "select 
				CONCAT('Res-',atha_penjualandgnresep.idpenjualan) as kolom1,
				atha_penjualandgnresep.tglpenjualan as kolom2,
				('') as kolom3,
				('') as kolom4,
				atha_penjualandgnresep.total as kolom5,
				atha_penjualandgnresep.keterangan as kolom6,
				(select sum(atha_itemracikan.labaperitem)) as kolom7
                from atha_penjualandgnresep
				left join atha_itemresep on atha_penjualandgnresep.idpenjualan = atha_itemresep.idpenjualan
				left join atha_itemracikan on atha_itemresep.iditemresep = atha_itemracikan.iditemresep
				where atha_penjualandgnresep.tglpenjualan >= '$tglawal' AND atha_penjualandgnresep.tglpenjualan <= '$tglakhir' 
				
				union
				
				select 
				CONCAT('NRes-',atha_penjualan.idpenjualan) as kolom1,
				atha_penjualan.tglpenjualan as kolom2,
				('') as kolom3,
				('') as kolom4,
				atha_penjualan.total as kolom5,
				atha_penjualan.keterangan as kolom6,
				(select sum(atha_itempenjualan.labaperitem)) as kolom7
				from atha_penjualan
				left join atha_itempenjualan on atha_penjualan.idpenjualan = atha_itempenjualan.idpenjualan
				where atha_penjualan.tglpenjualan >= '$tglawal' AND atha_penjualan.tglpenjualan <= '$tglakhir' 
				";
        return $this->db->query($sql)->result();
		
	}
	
    function get_print_transaksi($tglawal,$tglakhir) {
        $sql = "select 
				CONCAT('Res-',atha_penjualandgnresep.idpenjualan) as kolom1,
				atha_penjualandgnresep.tglpenjualan as kolom2,
				('') as kolom3,
				('') as kolom4,
				atha_penjualandgnresep.total as kolom5,
				atha_penjualandgnresep.keterangan as kolom6,
				(select sum(atha_itemracikan.labaperitem)) as kolom7
                from atha_penjualandgnresep
				left join atha_itemresep on atha_penjualandgnresep.idpenjualan = atha_itemresep.idpenjualan
				left join atha_itemracikan on atha_itemresep.iditemresep = atha_itemracikan.iditemresep
				where atha_penjualandgnresep.tglpenjualan >= '$tglawal' AND atha_penjualandgnresep.tglpenjualan <= '$tglakhir' 
				
				union
				
				select 
				CONCAT('NRes-',atha_penjualan.idpenjualan) as kolom1,
				atha_penjualan.tglpenjualan as kolom2,
				('') as kolom3,
				('') as kolom4,
				atha_penjualan.total as kolom5,
				atha_penjualan.keterangan as kolom6,
				(select sum(atha_itempenjualan.labaperitem)) as kolom7
				from atha_penjualan
				left join atha_itempenjualan on atha_penjualan.idpenjualan = atha_itempenjualan.idpenjualan
				where atha_penjualan.tglpenjualan >= '$tglawal' AND atha_penjualan.tglpenjualan <= '$tglakhir' 

				union
				
				select 
				CONCAT('BM-',atha_barangmasuk.idbarangmasuk) as kolom1,
				atha_barangmasuk.tglbarangmasuk as kolom2,
				atha_supplier.nmsupplier as kolom3,
				atha_barangmasuk.total as kolom4,
				('') as kolom5,
				atha_barangmasuk.keterangan as kolom6,
				('') as kolom7
				from atha_barangmasuk
				left join atha_supplier on atha_barangmasuk.idsupplier = atha_supplier.idsupplier
				where atha_barangmasuk.tglbarangmasuk >= '$tglawal' AND atha_barangmasuk.tglbarangmasuk <= '$tglakhir' 
				";
        return $this->db->query($sql)->result();
		
	}

	
    function get_print_transaksi_pembelian($tglawal,$tglakhir){
        $sql = "select 
				CONCAT('BM-',atha_barangmasuk.idbarangmasuk) as kolom1,
				atha_barangmasuk.tglbarangmasuk as kolom2,
				atha_supplier.nmsupplier as kolom3,
				atha_barangmasuk.total as kolom4,
				('') as kolom5,
				atha_barangmasuk.keterangan as kolom6,
				('') as kolom7
				from atha_barangmasuk
				left join atha_supplier on atha_barangmasuk.idsupplier = atha_supplier.idsupplier
				where atha_barangmasuk.tglbarangmasuk >= '$tglawal' AND atha_barangmasuk.tglbarangmasuk <= '$tglakhir' 
				";
        return $this->db->query($sql)->result();
		
	}
	//new buku besar
	
	function rilisbb_penjualantnpresep($tglawal,$tglakhir){
        $sql = "SELECT SUM(atha_penjualan.total) AS result
				FROM atha_penjualan
				where atha_penjualan.tglpenjualan >= '$tglawal' AND atha_penjualan.tglpenjualan <= '$tglakhir';";
        $row = $this->db->query($sql)->row();
		return $row->result;
	}
	
	function rilisbb_penjualandgnresep($tglawal,$tglakhir){
        $sql = "SELECT SUM(atha_penjualandgnresep.total) AS result
				FROM atha_penjualandgnresep
				where atha_penjualandgnresep.tglpenjualan >= '$tglawal' AND atha_penjualandgnresep.tglpenjualan <= '$tglakhir';";
        $row = $this->db->query($sql)->row();
		return $row->result;
	}
	
	function rilisbb_persediaanbarang(){
        $sql = "SELECT SUM(atha_produk.stok*atha_produk.hargasatuanbeli) AS result
				FROM atha_produk;";
        $row = $this->db->query($sql)->row();
		return $row->result;
	}
	
	function rilisbb_laba($tglawal,$tglakhir){
        $sql1 = "SELECT SUM(atha_itemracikan.labaperitem) AS result
				FROM atha_itemracikan
				left join atha_penjualandgnresep on atha_penjualandgnresep.idpenjualan = atha_itempenjualan.idpenjualan
				where atha_penjualandgnresep.tglpenjualan >= '$tglawal' AND atha_penjualandgnresep.tglpenjualan <= '$tglakhir';";
        $row1 = $this->db->query($sql1)->row();
		$laba1= $row1->result;
		
        $sql2 = "SELECT SUM(atha_itempenjualan.labaperitem) AS result
				FROM atha_itempenjualan
				left join atha_penjualan on atha_penjualan.idpenjualan = atha_itempenjualan.idpenjualan
				where atha_penjualan.tglpenjualan >= '$tglawal' AND atha_penjualan.tglpenjualan <= '$tglakhir';";
        $row2 = $this->db->query($sql2)->row();
		$laba2= $row2->result;
		
		return $laba1+$laba2;
	}
	
	function rilisbb_potonganpembelian($tglawal,$tglakhir){
        $sql = "SELECT SUM((100*atha_itembarangmasuk.subtotal)/(100-atha_itembarangmasuk.diskon)) AS result
				FROM atha_itembarangmasuk
				left join atha_barangmasuk on atha_barangmasuk.idbarangmasuk = atha_itembarangmasuk.idbarangmasuk
				where atha_barangmasuk.tglbarangmasuk >= '$tglawal' AND atha_barangmasuk.tglbarangmasuk <= '$tglakhir';";
        $row = $this->db->query($sql)->row();
				
		return $row->result;
	}
	
	function rilisbb_potonganpenjualan($tglawal,$tglakhir){
        $sql1 = "SELECT SUM(((100*atha_penjualandgnresep.total)/(100-atha_penjualandgnresep.diskon))*atha_penjualandgnresep.diskon/100) AS result
				FROM atha_penjualandgnresep
				where atha_penjualandgnresep.tglpenjualan >= '$tglawal' AND atha_penjualandgnresep.tglpenjualan <= '$tglakhir';";
        $row1 = $this->db->query($sql1)->row();
		
		
        $sql2 = "SELECT SUM(((100*atha_penjualan.total)/(100-atha_penjualan.diskon))*atha_penjualan.diskon/100) AS result
				FROM atha_penjualan
				where atha_penjualan.tglpenjualan >= '$tglawal' AND atha_penjualan.tglpenjualan <= '$tglakhir';";
        $row2 = $this->db->query($sql2)->row();
		
		return $row1->result+$row2->result;
	}
	
	function rilisbb_pendapatantuslah($tglawal,$tglakhir){
        $sql = "SELECT SUM(atha_itemresep.tuslah) AS result
				FROM atha_itemresep
				left join atha_penjualandgnresep on atha_penjualandgnresep.idpenjualan = atha_itemresep.idpenjualan
				where atha_penjualandgnresep.tglpenjualan >= '$tglawal' AND atha_penjualandgnresep.tglpenjualan <= '$tglakhir';";
        $row = $this->db->query($sql)->row();
		return $row->result;
	}
	
	function rilisbb_hutangdagang($tglawal,$tglakhir){
        $sql = "SELECT SUM(atha_barangmasuk.sisa) AS result
				FROM atha_barangmasuk
				where atha_barangmasuk.tglbarangmasuk >= '$tglawal' AND atha_barangmasuk.tglbarangmasuk <= '$tglakhir';";
        $row = $this->db->query($sql)->row();
		return $row->result;
	}
}
