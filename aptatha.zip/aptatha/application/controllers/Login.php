<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('LoginModel');
    }

    public function index() {
        $data = array(
            'action' => site_url('login/login_action'),
            'header' => 'Login',
            'email' => set_value('email', 'email'),
            'password' => set_value('password', 'password')
        );

        $this->template->load('template/login', 'login/login_form', $data);
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('login');
    }

    public function login_action() {
        $this->login_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->index();
        } else {
            $email = $this->input->post('email', TRUE);
            $password = $this->input->post('password', TRUE);
			
            $pengguna = $this->LoginModel->get_pengguna($email, $password);
            if ($pengguna) {
				
                $this->session->set_userdata('idkaryawan', $pengguna->idkaryawan);
                $this->session->set_userdata('nmkaryawan', $pengguna->nmkaryawan);
				$this->session->set_userdata('hakakses', $pengguna->hakakses);
								
                redirect(site_url('profile'));
				
            } else {
                $this->pesanerror('Username dan Password tidak cocok!');
                redirect(site_url('login'));
            }
        }
		
    }
	
    public function login_rules() {
        $this->form_validation->set_rules('email', 'Alamat E-Mail', 'trim|required|max_length[50]');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|max_length[50]');
        $this->form_validation->set_error_delimiters('<span class="label label-danger">', '</span><br><br>');
    }

    public function _validate_captcha() {
        if ($this->session->userdata('captcha') == $this->input->post('captcha', true)) {
            return true;
        } else {
            $this->form_validation->set_message('_validate_captcha', 'Input Captcha Salah!');
            return false;
        }
    }

    public function pesanerror($message) {
        $this->session->set_flashdata('idmessage', 1);
        $this->session->set_flashdata('message', $message);
    }

    public function pesaninfo($message) {
        $this->session->set_flashdata('idmessage', 2);
        $this->session->set_flashdata('message', $message);
    }

}
