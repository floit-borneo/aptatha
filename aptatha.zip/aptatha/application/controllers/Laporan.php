<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('TransaksiModel');
        $this->load->model('LoginModel');
        $this->load->model('AdminModel');
        $this->load->model('LaporanModel');
        $hakakses = $this->session->userdata('hakakses');
		
        if (empty($hakakses)) {
            $this->pesanerror('Anda tidak mempunyai akses ke halaman ini');
            redirect(site_url('login'));
        }
		
    }
	
	public function index(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses_data = $this->session->userdata('hakakses_data');
        $data = array(
            'header' => 'Administrator',
			'changePassword_action' => 'profile/changePassword/',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses_data' => $hakakses_data
        );
		 $this->template->load('template/welcome', 'welcome/landing', $data);
	}
	
	public function barangMasuk(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$barangMasuk_data = $this->LaporanModel->get_all_barangMasuk();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			'laporanBarangMasuk_print' => site_url('cprint/laporanBarangMasuk'),
		
			'barangMasuk_data' => $barangMasuk_data
        );
		 $this->template->load('template/laporan', 'laporan/barangMasuk', $data);
	}
	
	public function penjualan(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$penjualan_data = $this->LaporanModel->get_all_penjualan();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			'laporanPenjualan_print' => site_url('cprint/laporanPenjualan'),
		
			'penjualan_data' => $penjualan_data
        );
		 $this->template->load('template/laporan', 'laporan/penjualan', $data);
	}
	
	public function penjualanDgnResep(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$penjualanDgnResep_data = $this->LaporanModel->get_all_penjualanDgnResep();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			'laporanPenjualanDgnResep_print' => site_url('cprint/laporanPenjualanDgnResep'),
		
			'penjualanDgnResep_data' => $penjualanDgnResep_data
        );
		 $this->template->load('template/laporan', 'laporan/penjualanDgnResep', $data);
	}
	
	public function penjualanTnpResep(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$penjualanTnpResep_data = $this->LaporanModel->get_all_penjualanTnpResep();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			'laporanPenjualanTnpResep_print' => site_url('cprint/laporanPenjualanTnpResep'),
		
			'penjualanTnpResep_data' => $penjualanTnpResep_data
        );
		 $this->template->load('template/laporan', 'laporan/penjualanTnpResep', $data);
	}
	
	public function transaksi(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		$transaksi_data = $this->LaporanModel->get_all_transaksi();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			'laporanTransaksi_print' => site_url('cprint/laporanTransaksi'),
			'transaksi_data' => $transaksi_data
        );
		 $this->template->load('template/laporan', 'laporan/transaksi', $data);
	}
	
	public function pembayaran(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$pembayaran_data = $this->LaporanModel->get_all_pembayaran();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			'laporanPembayaran_print' => site_url('cprint/laporanPembayaran'),
		
			'pembayaran_data' => $pembayaran_data
        );
		 $this->template->load('template/laporan', 'laporan/pembayaran', $data);
	}
	
	public function stokProduk(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$produk_data = $this->AdminModel->get_all_produk();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			'laporanStok_print' => site_url('cprint/laporanStokProduk'),
		
			'produk_data' => $produk_data
        );
		 $this->template->load('template/laporan', 'laporan/stokProduk', $data);
	}
	
	public function bukuBesar(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$bukuBesar_data = $this->LaporanModel->get_all_bukuBesar();
		
		$idbukubesar = $this->LaporanModel->get_latest_bukubesar();
		$bukubesar = $this->LaporanModel->get_bukuBesar($idbukubesar);
		
		$check = $idbukubesar->idbukubesar+0;
		if ($check==0){
			$this->generateBukuBesar();
			$idbukubesar = $this->LaporanModel->get_latest_bukubesar();
			$bukubesar = $this->LaporanModel->get_bukuBesar($idbukubesar);
			
			redirect(site_url('laporan/viewBukuBesar/'.$idbukubesar));
		}else{
			$idbukubesar = $this->LaporanModel->get_latest_bukubesar();
			$bukubesar = $this->LaporanModel->get_bukuBesar($idbukubesar);
			redirect(site_url('laporan/viewBukuBesar/'.$idbukubesar));
		}
		
	}
	
	public function generateBukuBesar(){
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		$hakakses_data = $this->LoginModel->get_hakakses($idkaryawan_header);
		
        $tglawal =  date('Y-m-d');
        $tglakhir =  date('Y-m-d');
        $penjualantnpresep = $this->LaporanModel->get_total_penjualantnpresep();
        $penjualandgnresep = $this->LaporanModel->get_total_penjualandgnresep();
        $persediaanbarang = $this->LaporanModel->get_total_persediaanbarang();
        $laba = $this->LaporanModel->get_total_laba();
        $potonganpembelian = $this->LaporanModel->get_total_potonganpembelian();
        $potonganpenjualan = $this->LaporanModel->get_total_potonganpenjualan();
        $pendapatantuslah = $this->LaporanModel->get_total_pendapatantuslah();
        $hutangdagang = $this->LaporanModel->get_total_hutangdagang();
		$pemasukanLain=$this->input->post('pemasukanLain');
		$pengeluaranLain=$this->input->post('pengeluaranLain');
		
        $totalmasuk = $penjualantnpresep+$penjualandgnresep+$pendapatantuslah+$pemasukanLain;
        $totalkeluar = $hutangdagang+$pengeluaranLain;
		
		$bukubesar_new = array(
            'tglawal' => $tglawal,
            'tglakhir' => $tglakhir,
            'penjualan' => $penjualantnpresep+$penjualandgnresep,
            'penjualantnpresep' => $penjualantnpresep,
            'penjualandgnresep' => $penjualandgnresep,
            'persediaanbarang' => $persediaanbarang,
            'laba' => $laba,
            'potonganpembelian' => $potonganpembelian,
            'potonganpenjualan' => $potonganpenjualan,
            'pendapatantuslah' => $pendapatantuslah,
            //'pendapatanembalase' => $pendapatanembalase,
            'hutangdagang' => $hutangdagang,
            'pemasukanLain' => $pemasukanLain,
            'pengeluaranLain' => $pengeluaranLain,
            'totalmasuk' => $totalmasuk,
			'totalkeluar' => $totalkeluar,
        );
        if ($this->db->insert('bukubesar', $bukubesar_new)){;
		
		$idbukubesar = $this->LaporanModel->get_latest_bukubesar();
        $bukubesar = $this->LaporanModel->get_bukuBesar($idbukubesar);
		
				$datalog = array(	
					'idkaryawan' => $idkaryawan_header,
					'aktivitas' => 'Generate buku besar:'.$bukubesar->tglawal.'-'.$bukubesar->tglakhir,
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				
        $this->pesaninfo('Data Berhasil Disimpan.');
        redirect(site_url('laporan/viewBukuBesar/'.$idbukubesar));
		} else {
			$this->pesaninfo('Data Gagal Disimpan');
			redirect(site_url('profile'));
		}
	}
		
	public function rilisBukuBesar(){
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		$hakakses_data = $this->LoginModel->get_hakakses($idkaryawan_header);
		
        $tglawal =  $this->input->post('tglawal');
        $tglakhir =  $this->input->post('tglakhir');
        $penjualantnpresep = $this->LaporanModel->rilisbb_penjualantnpresep($tglawal,$tglakhir);
        $penjualandgnresep = $this->LaporanModel->rilisbb_penjualandgnresep($tglawal,$tglakhir);
        $persediaanbarang = $this->LaporanModel->rilisbb_persediaanbarang();
        //$laba = $this->LaporanModel->rilisbb_laba($tglawal,$tglakhir);
        $potonganpembelian = $this->LaporanModel->rilisbb_potonganpembelian($tglawal,$tglakhir);
        $potonganpenjualan = $this->LaporanModel->rilisbb_potonganpenjualan($tglawal,$tglakhir);
        $pendapatantuslah = $this->LaporanModel->rilisbb_pendapatantuslah($tglawal,$tglakhir);
        $hutangdagang = $this->LaporanModel->rilisbb_hutangdagang($tglawal,$tglakhir);
		$pemasukanLain=$this->input->post('pemasukanLain');
		$pengeluaranLain=$this->input->post('pengeluaranLain');
		
        $totalmasuk = $penjualantnpresep+$penjualandgnresep+$pendapatantuslah+$pemasukanLain;
        $totalkeluar = $hutangdagang+$pengeluaranLain;
		
		$bukubesar_new = array(
            'tglawal' => $tglawal,
            'tglakhir' => $tglakhir,
            'penjualan' => $penjualantnpresep+$penjualandgnresep,
            'penjualantnpresep' => $penjualantnpresep,
            'penjualandgnresep' => $penjualandgnresep,
            'persediaanbarang' => $persediaanbarang,
            //'laba' => $laba,
            'potonganpembelian' => $potonganpembelian,
            'potonganpenjualan' => $potonganpenjualan,
            'pendapatantuslah' => $pendapatantuslah,
            'hutangdagang' => $hutangdagang,
            'pemasukanLain' => $pemasukanLain,
            'pengeluaranLain' => $pengeluaranLain,
            'totalmasuk' => $totalmasuk,
			'totalkeluar' => $totalkeluar,
        );
        if ($this->db->insert('bukubesar', $bukubesar_new)){;
		
		$idbukubesar = $this->LaporanModel->get_latest_bukubesar();
        $bukubesar = $this->LaporanModel->get_bukuBesar($idbukubesar);
		
				$datalog = array(	
					'idkaryawan' => $idkaryawan_header,
					'aktivitas' => 'Rilis buku besar:'.$bukubesar->tglawal.'-'.$bukubesar->tglakhir,
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				
        $this->pesaninfo('Data Berhasil Disimpan.');
        redirect(site_url('laporan/viewBukuBesar/'.$idbukubesar));
		} else {
			$this->pesaninfo('Data Gagal Disimpan');
			redirect(site_url('profile'));
		}
	}
	
	public function viewBukuBesar($idbukubesar){
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		$hakakses_data = $this->LoginModel->get_hakakses($idkaryawan_header);
		
		$bukuBesar = $this->LaporanModel->get_bukuBesar($idbukubesar);
		$bukuBesar_data = $this->LaporanModel->get_all_bukuBesar();
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan_header,
			'nmkaryawan' => $nmkaryawan_header,
			'pemasukanLain' => set_value('pemasukanLain',0),
			'pengeluaranLain' => set_value('pengeluaranLain',0),
			'state' => set_value('state','ready'),
			'rilisBukuBesar' => site_url('laporan/rilisBukuBesar'),
			'hakakses' => $hakakses,
		
			'bukuBesar_data' => $bukuBesar_data,
			'idbukubesar' => $idbukubesar,
            'tglawal' => set_value('tglawal',$bukuBesar->tglawal),
            'tglakhir' => set_value('tglakhir',$bukuBesar->tglakhir),
            'penjualan' => set_value('penjualan',$bukuBesar->penjualan),
            'penjualantnpresep' => set_value('penjualantnpresep',$bukuBesar->penjualantnpresep),
            'penjualandgnresep' => set_value('penjualandgnresep',$bukuBesar->penjualandgnresep),
            'persediaanbarang' => set_value('persediaanbarang',$bukuBesar->persediaanbarang),
            'laba' => $bukuBesar->laba,
            'potonganpembelian' => $bukuBesar->potonganpembelian,
            'potonganpenjualan' => $bukuBesar->potonganpenjualan,
            'pendapatantuslah' => $bukuBesar->pendapatantuslah,
            'pendapatanembalase' => $bukuBesar->pendapatanembalase,
            'hutangdagang' => $bukuBesar->hutangdagang,
            'pemasukanlain' => $bukuBesar->pemasukanlain,
            'pengeluaranlain' => $bukuBesar->pengeluaranlain,
            'totalmasuk' => $bukuBesar->totalmasuk,
			'totalkeluar' => $bukuBesar->totalkeluar,
        );
		 $this->template->load('template/laporan', 'laporan/bukuBesar', $data);
	}
	
    public function hapusBukuBesar($idbukubesar) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        
        $bukubesar = $this->LaporanModel->get_bukuBesar($idbukubesar);
        if ($bukubesar) {
            $this->db->where('idbukubesar', $idbukubesar);
            if ($this->db->delete('bukubesar')) {
				$datalog = array(	
					'idkaryawan' => $idkaryawan_header,
					'aktivitas' => 'Hapus history buku besar:'.$bukubesar->tglawal.'-'.$bukubesar->tglakhir,
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				
                $this->pesaninfo('Data berhasil dihapus');
            } else {
                $this->pesanerror('Data tidak berhasil dihapus');
            }
            redirect(site_url('laporan/bukubesar/'));
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('laporan/bukubesar/'));
        }
    }
		
	public function logaction($datalog){
        $this->db->insert('log', $datalog);	
	}
	
    public function pesanerror($message) {
        $this->session->set_flashdata('idmessage', 1);
        $this->session->set_flashdata('message', $message);
    }

    public function pesaninfo($message) {
        $this->session->set_flashdata('idmessage', 2);
        $this->session->set_flashdata('message', $message);
    }
}
