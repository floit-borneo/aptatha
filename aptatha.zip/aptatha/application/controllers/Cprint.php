<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cprint extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('TransaksiModel');
        $this->load->model('LoginModel');
        $this->load->model('AdminModel');
        $this->load->model('LaporanModel');
        $this->load->model('PrintModel');
        $hakakses = $this->session->userdata('hakakses');
		
        if (empty($hakakses)) {
            $this->pesanerror('Anda tidak mempunyai akses ke halaman ini');
            redirect(site_url('login'));
        }
		
    }
	
	public function index(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses_data = $this->session->userdata('hakakses_data');
        $data = array(
            'header' => 'Administrator',
			'changePassword_action' => 'profile/changePassword/',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses_data' => $hakakses_data
        );
		 $this->template->load('template/welcome', 'welcome/landing', $data);
	}
	
	/* ^barang masuk */
	
	public function barangMasuk($idbarangmasuk) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $barangmasuk = $this->LaporanModel->get_barangMasuk($idbarangmasuk);
        $itemBarangMasuk_data = $this->TransaksiModel->get_all_itemBarangMasuk($idbarangmasuk);
        if ($barangmasuk) {
            $data = array(
                'idbarangmasuk' => $idbarangmasuk,
                'nmpembuat' => set_value('nmpembuat', $barangmasuk->nmpembuat),
                'tglbarangmasuk' => set_value('tglbarangmasuk', $barangmasuk->tglbarangmasuk),
				'jumlah' => set_value('jumlah', $barangmasuk->jumlah),
				'total' => set_value('total', $barangmasuk->total),
				'status' => set_value('status', $barangmasuk->status),
				'nmsupplier' => set_value('nmsupplier', $barangmasuk->nmsupplier),
				'tgljatuhtempo' => set_value('tgljatuhtempo', $barangmasuk->tgljatuhtempo),
				'payment' => set_value('payment', $barangmasuk->payment),
				'nofaktur' => set_value('nofaktur', $barangmasuk->nofaktur),
				'tglfaktur' => set_value('tglfaktur', $barangmasuk->tglfaktur),
				'ppn' => set_value('ppn', $barangmasuk->ppn),
				'diskon' => set_value('diskon', $barangmasuk->diskon),
				'keterangan' => set_value('keterangan', $barangmasuk->keterangan),
				'alamat' => set_value('alamat', $barangmasuk->alamat),
				'nohp' => set_value('nohp', $barangmasuk->nohp),
				'email' => set_value('email', $barangmasuk->email),
				'itemBarangMasuk_data' => $itemBarangMasuk_data
            );

				$datalog = array(	
					'idkaryawan' => $idkaryawan_header,
					'aktivitas' => 'Mempersiapkan cetak tanda terima barang masuk: '.$idbarangmasuk,
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				
				
			$this->template->load('template/print', 'print/barangMasuk_inv', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/barangMasuk'));
        }
    }
		
	
	/* ^pembayaran */
	public function pembayaran($idbarangmasuk,$idpembayaran){
	     //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		$hakakses_data = $this->LoginModel->get_hakakses($idkaryawan_header);
		
		
		$pembayaran = $this->LaporanModel->get_pembayaran($idbarangmasuk);
        $barangmasuk = $this->LaporanModel->get_barangMasuk($idbarangmasuk);
        $itemBarangMasuk_data = $this->TransaksiModel->get_all_itemBarangMasuk($idbarangmasuk);
        if ($barangmasuk) {
            $data = array(
                'idbarangmasuk' => $idbarangmasuk,
                'nmpembuat' => set_value('nmpembuat', $pembayaran->nmpembuat),
                'tglbarangmasuk' => set_value('tglbarangmasuk', $barangmasuk->tglbarangmasuk),
				'jumlah' => set_value('jumlah', $barangmasuk->jumlah),
				'total' => set_value('total', $barangmasuk->total),
				'status' => set_value('status', $barangmasuk->status),
				'nmsupplier' => set_value('nmsupplier', $barangmasuk->nmsupplier),
				'tgljatuhtempo' => set_value('tgljatuhtempo', $barangmasuk->tgljatuhtempo),
				'payment' => set_value('payment', $barangmasuk->payment),
				'nofaktur' => set_value('nofaktur', $barangmasuk->nofaktur),
				'tglfaktur' => set_value('tglfaktur', $barangmasuk->tglfaktur),
				'ppn' => set_value('ppn', $barangmasuk->ppn),
				'keterangan' => set_value('keterangan', $barangmasuk->keterangan),
				'alamat' => set_value('alamat', $barangmasuk->alamat),
				'nohp' => set_value('nohp', $barangmasuk->nohp),
				'email' => set_value('email', $barangmasuk->email),
				'nmpenerima' => set_value('nmpenerima', $pembayaran->nmpenerima),
				'tglpembayaran' => set_value('tglpembayaran', $pembayaran->tglpembayaran),
				'jumlah_pembayaran' => set_value('jumlah_pembayaran', $pembayaran->jumlah),
				'keterangan_pembayaran' => set_value('keterangan_pembayaran', $pembayaran->keterangan),
				'itemBarangMasuk_data' => $itemBarangMasuk_data
            );
			
				$datalog = array(	
					'idkaryawan' => $idkaryawan_header,
					'aktivitas' => 'Mempersiapkan cetak tanda pembayaran: '.$idpembayaran,
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				
		 $this->template->load('template/print', 'print/pembayaran_inv', $data);
		 } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/pembayaran'));
        }
	}
	

	/* ^penjualan dgn resep */
    public function penjualanDgnResep($idpenjualan) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $produk_data = $this->AdminModel->get_all_produk();
        $penjualan = $this->PrintModel->get_penjualanDgnResep($idpenjualan);
        $itemracikan_data = $this->PrintModel->get_all_itemRacikan($idpenjualan);
        if ($penjualan) {
            $data = array(
                'idpenjualan' => $idpenjualan,
                'nmpembuat' => set_value('nmpembuat', $penjualan->nmpembuat),
                'nmdokter' => set_value('nmdokter', $penjualan->nmdokter),
                'tglpenjualan' => set_value('tglpenjualan', $penjualan->tglpenjualan),
				'jumlah' => set_value('jumlah', $penjualan->jumlah),
				'total' => set_value('total', $penjualan->total),
				'diskon' => set_value('diskon', $penjualan->diskon),
				'keterangan' => set_value('keterangan', $penjualan->keterangan),
				'komisi' => set_value('komisi', $penjualan->komisi),
				
				'produk_data' => $produk_data,
				'itemracikan_data' => $itemracikan_data
				
            );

				$datalog = array(	
					'idkaryawan' => $idkaryawan_header,
					'aktivitas' => 'Mempersiapkan cetak invoice penjualan dengan resep: '.$idpenjualan,
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				
			$this->template->load('template/print', 'print/penjualanDgnResep_inv', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/addPenjualanDgnResep'));
        }
    }
	
	
	/* ^penjualan tanpa resep */
	public function penjualanTnpResep($idpenjualan){
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $penjualan = $this->TransaksiModel->get_penjualanTnpResep($idpenjualan);
        $itemPenjualanTnpResep_data = $this->TransaksiModel->get_all_itemPenjualanTnpResep($idpenjualan);
        if ($penjualan) {
            $data = array(
                'idpenjualan' => $idpenjualan,
                'nmpembuat' => set_value('nmpembuat', $penjualan->nmpembuat),
                'tglpenjualan' => set_value('tglpenjualan', $penjualan->tglpenjualan),
				'jumlah' => set_value('jumlah', $penjualan->jumlah),
				'total' => set_value('total', $penjualan->total),
				'diskon' => set_value('diskon', $penjualan->diskon),
				'keterangan' => set_value('keterangan', $penjualan->keterangan),
				'itemPenjualanTnpResep_data' => $itemPenjualanTnpResep_data
            );

				$datalog = array(	
					'idkaryawan' => $idkaryawan_header,
					'aktivitas' => 'Mempersiapkan cetak invoice penjualan tanpa resep: '.$idpenjualan,
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				
			$this->template->load('template/print', 'print/penjualanTnpResep_inv', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/penjualan'));
        }
	}
	public function laporanBarangMasuk(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		
		$tglawal=date('Y-m-d', strtotime($this->input->post('tglawal', TRUE)));
		$tglakhir=date('Y-m-d', strtotime($this->input->post('tglakhir', TRUE)));
		
		$barangMasuk_data = $this->LaporanModel->get_print_barangMasuk($tglawal,$tglakhir);
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			
			'barangMasuk_data' => $barangMasuk_data
        );
				$datalog = array(	
					'idkaryawan' => $idkaryawan,
					'aktivitas' => 'Mempersiapkan cetak laporan barang masuk',
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				
		 $this->template->load('template/print', 'print/barangMasuk', $data);
	}
	
	public function laporanPenjualan(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		
		$tglawal=date('Y-m-d', strtotime($this->input->post('tglawal', TRUE)));
		$tglakhir=date('Y-m-d', strtotime($this->input->post('tglakhir', TRUE)));
		$penjualan_data = $this->LaporanModel->get_print_penjualan($tglawal,$tglakhir);
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			
			'penjualan_data' => $penjualan_data
        );
				$datalog = array(	
					'idkaryawan' => $idkaryawan,
					'aktivitas' => 'Mempersiapkan cetak laporan penjualan',
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				
		 $this->template->load('template/print', 'print/penjualan', $data);
	}
	
	public function laporanPenjualanDgnResep(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		
		$tglawal=date('Y-m-d', strtotime($this->input->post('tglawal', TRUE)));
		$tglakhir=date('Y-m-d', strtotime($this->input->post('tglakhir', TRUE)));
		$penjualanDgnResep_data = $this->LaporanModel->get_print_penjualanDgnResep($tglawal,$tglakhir);
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			
			'penjualanDgnResep_data' => $penjualanDgnResep_data
        );
				$datalog = array(	
					'idkaryawan' => $idkaryawan,
					'aktivitas' => 'Mempersiapkan cetak laporan penjualan dengan resep',
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				
		 $this->template->load('template/print', 'print/penjualanDgnResep', $data);
	}
	
	public function laporanPenjualanTnpResep(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		
		$tglawal=date('Y-m-d', strtotime($this->input->post('tglawal', TRUE)));
		$tglakhir=date('Y-m-d', strtotime($this->input->post('tglakhir', TRUE)));
		$penjualanTnpResep_data = $this->LaporanModel->get_print_penjualanTnpResep($tglawal,$tglakhir);
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			
			'penjualanTnpResep_data' => $penjualanTnpResep_data
        );
				$datalog = array(	
					'idkaryawan' => $idkaryawan,
					'aktivitas' => 'Mempersiapkan cetak laporan penjualan tanpa resep',
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				
		 $this->template->load('template/print', 'print/penjualanTnpResep', $data);
	}
	
	public function laporanStokProduk(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		
		//$tglawal=date('Y-m-d', strtotime($this->input->post('tglawal', TRUE)));
		//$tglakhir=date('Y-m-d', strtotime($this->input->post('tglakhir', TRUE)));
		//$produk_data = $this->LaporanModel->get_print_produk($tglawal,$tglakhir);
		
		$produk_data = $this->LaporanModel->get_print_produk();
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			
			'produk_data' => $produk_data
        );
				$datalog = array(	
					'idkaryawan' => $idkaryawan,
					'aktivitas' => 'Mempersiapkan cetak laporan stok produk',
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				
		 $this->template->load('template/print', 'print/stokProduk', $data);
	}

	public function laporanTransaksi(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$tglawal=date('Y-m-d', strtotime($this->input->post('tglawal', TRUE)));
		$tglakhir=date('Y-m-d', strtotime($this->input->post('tglakhir', TRUE)));
		$jenis_laporan=$this->input->post('jenis_laporan',TRUE);
		if ($jenis_laporan=='penjualan'){
			$transaksi_data = $this->LaporanModel->get_print_transaksi_penjualan($tglawal,$tglakhir);
		} elseif($jenis_laporan=='pembelian'){
			$transaksi_data = $this->LaporanModel->get_print_transaksi_pembelian($tglawal,$tglakhir);
		} elseif($jenis_laporan=='semua'){
			$transaksi_data = $this->LaporanModel->get_print_transaksi($tglawal,$tglakhir);
		}
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			'transaksi_data' => $transaksi_data,
			'tglawal' => $tglawal,
			'tglakhir' => $tglakhir,
			'jenis_laporan' => $jenis_laporan
        );
				
		 $this->template->load('template/print', 'print/transaksi', $data);
	}
	
	public function laporanPembayaran(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		
		$tglawal=date('Y-m-d', strtotime($this->input->post('tglawal', TRUE)));
		$tglakhir=date('Y-m-d', strtotime($this->input->post('tglakhir', TRUE)));
		$pembayaran_data = $this->LaporanModel->get_print_pembayaran($tglawal,$tglakhir);
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			
			'pembayaran_data' => $pembayaran_data
        );
				
		 $this->template->load('template/print', 'print/pembayaran', $data);
	}
	
	public function laporanBukuBesar($idbukubesar){
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		$hakakses_data = $this->LoginModel->get_hakakses($idkaryawan_header);
		
		$bukuBesar = $this->LaporanModel->get_bukuBesar($idbukubesar);
		$bukuBesar_data = $this->LaporanModel->get_all_bukuBesar();
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan_header,
			'nmkaryawan' => $nmkaryawan_header,
			'pemasukanLain' => set_value('pemasukanLain',0),
			'pengeluaranLain' => set_value('pengeluaranLain',0),
			'state' => set_value('state','ready'),
			'generateBukuBesar' => site_url('laporan/generateBukuBesar'),
			'hakakses' => $hakakses,
			
			'bukuBesar_data' => $bukuBesar_data,
			'idbukubesar' => $idbukubesar,
            'tglawal' => set_value('tglawal',$bukuBesar->tglawal),
            'tglakhir' => set_value('tglakhir',$bukuBesar->tglakhir),
            'penjualan' => set_value('penjualan',$bukuBesar->penjualan),
            'penjualantnpresep' => set_value('penjualantnpresep',$bukuBesar->penjualantnpresep),
            'penjualandgnresep' => set_value('penjualandgnresep',$bukuBesar->penjualandgnresep),
            'persediaanbarang' => set_value('persediaanbarang',$bukuBesar->persediaanbarang),
            'laba' => $bukuBesar->laba,
            'potonganpembelian' => $bukuBesar->potonganpembelian,
            'potonganpenjualan' => $bukuBesar->potonganpenjualan,
            'pendapatantuslah' => $bukuBesar->pendapatantuslah,
            'pendapatankomisi' => $bukuBesar->pendapatankomisi,
            'hutangdagang' => $bukuBesar->hutangdagang,
            'pemasukanlain' => $bukuBesar->pemasukanlain,
            'pengeluaranlain' => $bukuBesar->pengeluaranlain,
            'totalmasuk' => $bukuBesar->totalmasuk,
			'totalkeluar' => $bukuBesar->totalkeluar,
        );
		 $this->template->load('template/print', 'print/bukuBesar', $data);
	}
	
	public function logaction($datalog){
        //$this->db->insert('log', $datalog);		
	}
		
    public function pesanerror($message) {
        $this->session->set_flashdata('idmessage', 1);
        $this->session->set_flashdata('message', $message);
    }

    public function pesaninfo($message) {
        $this->session->set_flashdata('idmessage', 2);
        $this->session->set_flashdata('message', $message);
    }
}
