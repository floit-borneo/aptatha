<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('AdminModel');
        $this->load->model('LoginModel');
		/*
        $hakakses = $this->session->userdata('hakakses');
        if (!$hakakses) {
            $this->pesanerror('Anda tidak mempunyai akses ke halaman ini');
            redirect(site_url('login'));
        }
		*/
    }
	
	public function index(){
        $data = array(
		
        );
		$this->template->load('template/profile', 'profile/dashboard', $data);
	}
	/*
	public function index()
	{
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		$hakakses_data = $this->LoginModel->get_hakakses($idkaryawan);
		
		$log_data = $this->LoginModel->get_log($idkaryawan);
		$karyawan = $this->AdminModel->get_karyawan($idkaryawan);
        $data = array(
            'header' => 'profile',
			'editPassword_action' => site_url('profile/editPassword_action'),
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			'jabatan' => set_value('jabatan', $karyawan->jabatan),
			'tmptlahir' => set_value('tmptlahir', $karyawan->tmptlahir),
			'tgllahir' => set_value('tgllahir', $karyawan->tgllahir),
			'nohp' => set_value('nohp', $karyawan->nohp),
			'email' => set_value('email', $karyawan->email),
			'alamat' => set_value('alamat', $karyawan->alamat),
			'log_data' => $log_data,
			'hakakses_data' => $hakakses_data
        );
		 $this->template->load('template/main', 'profile/landing', $data);
	}
	public function editPassword_action()
	{
		$idkaryawan = $this->session->userdata('idkaryawan');
        $password = $this->input->post('passwordbaru', TRUE);
        $karyawan = $this->AdminModel->get_karyawan($idkaryawan);
        if ($karyawan) {
            $data_karyawan = array(
                'password' => md5($password)
            );
            $this->db->where('idkaryawan', $idkaryawan);
            $this->db->update('karyawan', $data_karyawan);

            $this->pesaninfo('Ganti Password Berhasil');
            redirect(site_url('profile'));
        }
	}*/
	
    public function pesanerror($message) {
        $this->session->set_flashdata('idmessage', 1);
        $this->session->set_flashdata('message', $message);
    }

    public function pesaninfo($message) {
        $this->session->set_flashdata('idmessage', 2);
        $this->session->set_flashdata('message', $message);
    }
}
