<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Adjust extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('AdminModel');
        $this->load->model('LoginModel');
        $hakakses = $this->session->userdata('hakakses');
        if (!in_array(3, $hakakses)) {
            $this->pesanerror('Anda tidak mempunyai akses ke halaman ini');
            redirect(site_url('login'));
        }
		
    }

	public function index()
	{
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$produk_data = $this->AdminModel->get_all_produk();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			
			'stokOpname_action' => site_url('adjust/stokOpname_action'),
			'hargaJual_action' => site_url('adjust/hargaJual_action'),
			'idproduk' => set_value('idproduk',1),
			'stokfisik' => set_value('stokfisik',0),
			'hargajual' => set_value('hargajual',0),
			'produk_data' => $produk_data
        );
		 $this->template->load('template/main', 'adjust/adjust_form', $data);
	}
	
    public function stokOpname_rules() {
        $this->form_validation->set_rules('stokfisik', 'Stok Fisik', 'trim|required');
        $this->form_validation->set_error_delimiters('<span class="label label-danger">', '</span><br><br>');
    }
	
	public function stokOpname_action(){
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
		$this->stokOpname_rules();
        $idproduk = $this->input->post('idproduk', TRUE);

        if ($this->form_validation->run() == FALSE) {
            $this->index();
        } else {			
            $data = array(	
                'stok' => $this->input->post('stokfisik', TRUE),
            );
            $this->db->where('idproduk', $idproduk);
            if ($this->db->update('produk', $data)){

				$datalog = array(	
					'idkaryawan' => $idkaryawan_header,
					'aktivitas' => 'Adjust Stok Produk ID:'.$idproduk,
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				$this->pesaninfo('Data Berhasil Disimpan');
				redirect(site_url('adjust'));
			} else {

				$this->pesaninfo('Data Gagal Disimpan');
				redirect(site_url('adjust'));
			}
        }
	}
	
    public function hargaJual_rules() {
        $this->form_validation->set_rules('hargajual', 'Harga Satuan Jual', 'trim|required');
        $this->form_validation->set_error_delimiters('<span class="label label-danger">', '</span><br><br>');
    }
	
	public function hargaJual_action(){
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
		$this->hargaJual_rules();
        $idproduk = $this->input->post('idproduk', TRUE);

        if ($this->form_validation->run() == FALSE) {
            $this->index();
        } else {			
            $data = array(	
                'hargasatuanjual' => $this->input->post('hargajual', TRUE),
            );
            $this->db->where('idproduk', $idproduk);
            if ($this->db->update('produk', $data)){
				
				$datalog = array(	
					'idkaryawan' => $idkaryawan_header,
					'aktivitas' => 'Adjust Harga Jual Produk ID:'.$idproduk,
					'tglaktivitas' => date('Y-m-d H:i:s'),
				);
				$this->logaction($datalog);
				$this->pesaninfo('Data Berhasil Disimpan');
				redirect(site_url('adjust'));
			} else {

				$this->pesaninfo('Data Gagal Disimpan');
				redirect(site_url('adjust'));
			}
        }
	}
	
	public function logaction($datalog){
		
        $this->db->insert('log', $datalog);
		
	}
	
    public function pesanerror($message) {
        $this->session->set_flashdata('idmessage', 1);
        $this->session->set_flashdata('message', $message);
    }

    public function pesaninfo($message) {
        $this->session->set_flashdata('idmessage', 2);
        $this->session->set_flashdata('message', $message);
    }
}
