<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('AdminModel');
        $this->load->model('LoginModel');
        $hakakses = $this->session->userdata('hakakses');
		
        if (empty($hakakses)) {
            $this->pesanerror('Anda tidak mempunyai akses ke halaman ini');
            redirect(site_url('login'));
        }
		
    }
	
	public function index(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        
        $data = array(
            'header' => 'Administrator',
			'changePassword_action' => 'profile/changePassword/',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			
        );
		 $this->template->load('template/welcome', 'welcome/landing', $data);
	}
	
	/* ^produk */
	public function produk(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		$produk_data = $this->AdminModel->get_all_produk();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			'produk_data' => $produk_data
        );
		 $this->template->load('template/admin', 'admin/produk', $data);
	}
	
	public function viewProduk($idproduk) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $produk = $this->AdminModel->get_produk($idproduk);
        if ($produk) {
            $data = array(
				'header' => 'Administrator',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'atha_produk',
                'state' => 'view',
                'idproduk' => $idproduk,
                'nmproduk' => set_value('nmproduk', $produk->nmproduk),
                'nmkategori' => set_value('nmkategori', $produk->nmkategori),
				'deskripsi' => set_value('deskripsi', $produk->deskripsi),
				'satuanbeli' => set_value('satuanbeli', $produk->satuanbeli),
				'satuanjual' => set_value('satuanjual', $produk->satuanjual),
				'hargasatuanbeli' => set_value('hargasatuanbeli', $produk->hargasatuanbeli),
				'hargasatuanjual' => set_value('hargasatuanjual', $produk->hargasatuanjual),
				'stok' => set_value('stok', $produk->stok),
				'lokasirak' => set_value('lokasirak', $produk->lokasirak),
				'keterangan' => set_value('keterangan', $produk->keterangan),
            );

			$this->template->load('template/admin', 'admin/produk_view', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('admin/produk'));
        }
    }
		
	public function addProduk() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $kategori_data = $this->AdminModel->get_all_kategori();
        $data = array(
            'header' => 'Administrator',
			'idkaryawan_header' => $idkaryawan_header,
			'nmkaryawan_header' => $nmkaryawan_header,
			'hakakses' => $hakakses,
            'page' => 'atha_produk',
            'addProduk_action' => site_url('admin/addProduk_action'),
            'state' => 'create',
            'nmproduk' => set_value('nmproduk'),
            'idkategori' => set_value('idkategori'),
			'deskripsi' => set_value('deskripsi'),
			'satuanbeli' => set_value('satuanbeli'),
			'satuanjual' => set_value('satuanjual'),
			'hargasatuanbeli' => set_value('hargasatuanbeli', 0),
			'hargasatuanjual' => set_value('hargasatuanjual',0),
			'stok' => set_value('stok', 0),
			'lokasirak' => set_value('lokasirak'),
			'keterangan' => set_value('keterangan'),
            'kategori_data' => $kategori_data,
        );

		$this->template->load('template/admin', 'admin/produk_form', $data);
    }

    public function addProduk_rules() {
        $this->form_validation->set_rules('nmproduk', 'Nama Produk', 'trim|required');
        $this->form_validation->set_rules('satuanjual', 'Satuan Jual', 'trim|required');
        $this->form_validation->set_rules('satuanbeli', 'Satuan Beli', 'trim|required');
        $this->form_validation->set_rules('hargasatuanjual', 'Harga Satuan Jual', 'trim|required');
        $this->form_validation->set_rules('hargasatuanbeli', 'Harga Satuan Beli', 'trim|required');
        $this->form_validation->set_error_delimiters('<span class="label label-danger">', '</span><br><br>');
    }
	
	public function addProduk_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
        $this->addProduk_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->addProduk();
        } else {
			$nmproduk=$this->input->post('nmproduk', TRUE);
            $data = array(
                'nmproduk' => $this->input->post('nmproduk', TRUE),
                'idkategori' => $this->input->post('idkategori', TRUE),
                'deskripsi' => $this->input->post('deskripsi', TRUE),
                'satuanbeli' => $this->input->post('satuanbeli', TRUE),
                'satuanjual' => $this->input->post('satuanjual', TRUE),
                'hargasatuanbeli' => $this->input->post('hargasatuanbeli', TRUE),
                'hargasatuanjual' => $this->input->post('hargasatuanjual', TRUE),
                'stok' => $this->input->post('stok', TRUE),
                'lokasirak' => $this->input->post('lokasirak', TRUE),
                'keterangan' => $this->input->post('keterangan', TRUE),
            );
            $this->db->insert('atha_produk', $data);
			
            $this->pesaninfo('Data Berhasil Disimpan');
            redirect(site_url('admin/produk/'));
        }
    }

    public function hapusProduk($idproduk) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
        $produk = $this->AdminModel->get_produk($idproduk);
        if ($produk) {
            $this->db->where('idproduk', $idproduk);
            if ($this->db->delete('atha_produk')) {
                $this->pesaninfo('Data berhasil dihapus');
            } else {
                $this->pesanerror('Data tidak berhasil dihapus');
            }
            redirect(site_url('admin/produk'));
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('admin/produk'));
        }
    }
	
    public function editProduk($idproduk) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $kategori_data = $this->AdminModel->get_all_kategori();
        $produk = $this->AdminModel->get_produk($idproduk);
        if ($produk) {
            $data = array(
				'header' => 'Administrator',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'atha_produk',
				'editProduk_action' => site_url('admin/editProduk_action'),
                'state' => 'update',
                'idproduk' => $idproduk,
                'nmproduk' => set_value('nmproduk', $produk->nmproduk),
                'idkategori' => set_value('idkategori', $produk->idkategori),
				'deskripsi' => set_value('deskripsi', $produk->deskripsi),
				'satuanbeli' => set_value('satuanbeli', $produk->satuanbeli),
				'satuanjual' => set_value('satuanjual', $produk->satuanjual),
				'hargasatuanbeli' => set_value('hargasatuanbeli', $produk->hargasatuanbeli),
				'hargasatuanjual' => set_value('hargasatuanjual', $produk->hargasatuanjual),
				'stok' => set_value('stok', $produk->stok),
				'lokasirak' => set_value('lokasirak', $produk->lokasirak),
				'keterangan' => set_value('keterangan', $produk->keterangan),
				'kategori_data' => $kategori_data,
            );

			$this->template->load('template/admin', 'admin/produk_form', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('admin/produk'));
        }
    }

    public function editProduk_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
        $this->addProduk_rules();
        $idproduk = $this->input->post('idproduk', TRUE);

        if ($this->form_validation->run() == FALSE) {
            $this->editProduk($idproduk);
        } else {
            $data_produk = array(
                'nmproduk' => $this->input->post('nmproduk', TRUE),
                'idkategori' => $this->input->post('idkategori', TRUE),
                'deskripsi' => $this->input->post('deskripsi', TRUE),
                'satuanbeli' => $this->input->post('satuanbeli', TRUE),
                'satuanjual' => $this->input->post('satuanjual', TRUE),
                'hargasatuanbeli' => $this->input->post('hargasatuanbeli', TRUE),
                'hargasatuanjual' => $this->input->post('hargasatuanjual', TRUE),
                'stok' => $this->input->post('stok', TRUE),
                'lokasirak' => $this->input->post('lokasirak', TRUE),
                'keterangan' => $this->input->post('keterangan', TRUE),
            );
            $this->db->where('idproduk', $idproduk);
            if ($this->db->update('atha_produk', $data_produk)){

            $this->pesaninfo('Data Berhasil Disimpan');
            redirect(site_url('admin/editProduk/'.$idproduk));
			} else {

            $this->pesaninfo('Data Gagal Disimpan');
            redirect(site_url('admin/editProduk/'.$idproduk));
			}
        }
    }
	
	public function editIDproduk($idproduk) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $kategori_data = $this->AdminModel->get_all_kategori();
        $produk = $this->AdminModel->get_produk($idproduk);
        if ($produk) {
            $data = array(
				'header' => 'Administrator',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'atha_produk',
				'editIDproduk_action' => site_url('admin/editIDproduk_action'),
                'state' => 'update',
                'idprodukold' => $idproduk,
                'idproduknew' => set_value('idproduknew'),
            );

			$this->template->load('template/admin', 'admin/idproduk_form', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('admin/produk'));
        }
    }
	
    public function IDproduk_rules() {
        $this->form_validation->set_rules('idproduknew', 'ID Produk Baru', 'trim|required');
        $this->form_validation->set_error_delimiters('<span class="label label-danger">', '</span><br><br>');
    }
		
	public function editIDproduk_action() {
        $this->IDproduk_rules();
        $idprodukold = $this->input->post('idprodukold', TRUE);
        $idproduknew = $this->input->post('idproduknew', TRUE);

        if ($this->form_validation->run() == FALSE) {
            $this->editIDproduk($idproduk);
        } else {
            $data_produk = array(
                'idproduk' => $idproduknew
            );
            $this->db->where('idproduk', $idprodukold);
            if ($this->db->update('atha_produk', $data_produk)){

            $this->pesaninfo('Data Berhasil Disimpan');
            redirect(site_url('admin/editProduk/'.$idprodukold));
			} else {

            $this->pesaninfo('Data Gagal Disimpan');
            redirect(site_url('admin/editProduk/'.$idprodukold));
			}
        }
    }
	
	/* ^kategori produk */
	public function addKategori() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $kategori_data = $this->AdminModel->get_all_kategori();
        $data = array(
            'header' => 'Administrator',
			'idkaryawan_header' => $idkaryawan_header,
			'nmkaryawan_header' => $nmkaryawan_header,
			'hakakses' => $hakakses,
            'page' => 'kategori',
            'addKategori_action' => site_url('admin/addKategori_action'),
            'state' => 'create',
            'nmkategori' => set_value('nmkategori'),
            'kategori_data' => $kategori_data,
        );

		$this->template->load('template/admin', 'admin/kategori_form', $data);
    }
	
	public function addKategori_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
        $this->addKategori_rules();
		
        if ($this->form_validation->run() == FALSE) {
            $this->addProduk();
        } else {
            $data = array(
                'nmkategori' => $this->input->post('nmkategori', TRUE),
            );
            $this->db->insert('atha_kategoriproduk', $data);

            $this->pesaninfo('Data Berhasil Disimpan');
			redirect(site_url('admin/addKategori'));
        }
    }
	
    public function addKategori_rules() {
        $this->form_validation->set_rules('nmkategori', 'Nama Kategori', 'trim|required');
        $this->form_validation->set_error_delimiters('<span class="label label-danger">', '</span><br><br>');
    }
		
	public function hapusKategori($idkategori) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
        //data header
        $kategori = $this->AdminModel->get_kategori($idkategori);
        if ($kategori) {
            $this->db->where('idkategori', $idkategori);
            if ($this->db->delete('atha_kategoriproduk')) {
								
                $this->pesaninfo('Data kategori berhasil dihapus');
            } else {
                $this->pesanerror('Data kategori terpakai pada salah satu produk');
            }
			redirect(site_url('admin/addKategori'));
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
			redirect(site_url('admin/addKategori'));
        }
    }
		
	/* ^supplier */
	public function supplier(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$supplier_data = $this->AdminModel->get_all_supplier();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			'supplier_data' => $supplier_data
        );
		 $this->template->load('template/admin', 'admin/supplier', $data);
	}
		
	public function viewSupplier($idsupplier) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $supplier = $this->AdminModel->get_supplier($idsupplier);
        if ($supplier) {
            $data = array(
				'header' => 'Administrator',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'supplier',
                'state' => 'view',
                'idsupplier' => $idsupplier,
                'nmsupplier' => set_value('nmsupplier', $supplier->nmsupplier),
                'alamat' => set_value('alamat', $supplier->alamat),
				'nohp' => set_value('nohp', $supplier->nohp),
				'email' => set_value('email', $supplier->email),
				'keterangan' => set_value('keterangan', $supplier->keterangan),
            );

			$this->template->load('template/admin', 'admin/supplier_view', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('admin/supplier'));
        }
    }
		
	public function addSupplier() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $data = array(
            'header' => 'Administrator',
			'idkaryawan_header' => $idkaryawan_header,
			'nmkaryawan_header' => $nmkaryawan_header,
			'hakakses' => $hakakses,
            'page' => 'supplier',
            'addSupplier_action' => site_url('admin/addSupplier_action'),
            'state' => 'create',
            'nmsupplier' => set_value('nmsupplier'),
            'alamat' => set_value('alamat'),
            'nohp' => set_value('nohp'),
            'email' => set_value('email'),
            'keterangan' => set_value('keterangan'),
        );

		$this->template->load('template/admin', 'admin/supplier_form', $data);
    }
    
    public function addSupplier_rules() {
        $this->form_validation->set_rules('nmsupplier', 'Nama Supplier', 'trim|required');
        $this->form_validation->set_rules('nohp', 'No HP', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required');
        $this->form_validation->set_error_delimiters('<span class="label label-danger">', '</span><br><br>');
    }
	
	public function addSupplier_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $this->addSupplier_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->addSupplier();
        } else {
            $data = array(
                'nmsupplier' => $this->input->post('nmsupplier', TRUE),
                'alamat' => $this->input->post('alamat', TRUE),
                'nohp' => $this->input->post('nohp', TRUE),
                'email' => $this->input->post('email', TRUE),
                'keterangan' => $this->input->post('keterangan', TRUE),
            );
            $this->db->insert('atha_supplier', $data);

            $this->pesaninfo('Data Berhasil Disimpan');
            redirect(site_url('admin/supplier'));
        }
    }
	
    public function hapusSupplier($idsupplier) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
        $supplier = $this->AdminModel->get_supplier($idsupplier);
        if ($supplier) {
            $this->db->where('idsupplier', $idsupplier);
            if ($this->db->delete('atha_supplier')) {
                $this->pesaninfo('Data berhasil dihapus');
            } else {
                $this->pesanerror('Data tidak berhasil dihapus, data sedang digunakan pada tabel lain');
            }
            redirect(site_url('admin/supplier'));
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('admin/supplier'));
        }
    }
	
    public function editSupplier($idsupplier) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $supplier = $this->AdminModel->get_supplier($idsupplier);
        if ($supplier) {
            $data = array(
				'header' => 'Administrator',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'supplier',
				'editSupplier_action' => site_url('admin/editSupplier_action'),
                'state' => 'update',
                'idsupplier' => $idsupplier,
                'nmsupplier' => set_value('nmsupplier', $supplier->nmsupplier),
                'alamat' => set_value('alamat', $supplier->alamat),
				'nohp' => set_value('nohp', $supplier->nohp),
				'email' => set_value('email', $supplier->email),
				'keterangan' => set_value('keterangan', $supplier->keterangan),
            );

			$this->template->load('template/admin', 'admin/supplier_form', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('admin/supplier'));
        }
    }

    public function editSupplier_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
        $this->addSupplier_rules();
        $idsupplier = $this->input->post('idsupplier', TRUE);

        if ($this->form_validation->run() == FALSE) {
            $this->editSupplier($idsupplier);
        } else {
            $data_supplier = array(
                'nmsupplier' => $this->input->post('nmsupplier', TRUE),
                'alamat' => $this->input->post('alamat', TRUE),
                'nohp' => $this->input->post('nohp', TRUE),
                'email' => $this->input->post('email', TRUE),
                'keterangan' => $this->input->post('keterangan', TRUE),
            );
            $this->db->where('idsupplier', $idsupplier);
			
            if ($this->db->update('atha_supplier', $data_supplier)){
				
				$this->pesaninfo('Data Berhasil Disimpan');
				redirect(site_url('admin/editSupplier/'.$idsupplier));
			} else {
				$this->pesaninfo('Data Gagal Disimpan');
				redirect(site_url('admin/editSupplier/'.$idsupplier));
			}
        }
    }
	
	public function adjust()
	{
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$produk_data = $this->AdminModel->get_all_produk();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			'stokOpname_action' => site_url('admin/stokOpname_action'),
			'hargaAdjust_action' => site_url('admin/hargaAdjust_action'),
			'idproduk' => set_value('idproduk',1),
			'stokfisik' => set_value('stokfisik'),
			'hargajual' => set_value('hargajual'),
			'hargabeli' => set_value('hargabeli'),
			'produk_data' => $produk_data
        );
		 $this->template->load('template/admin', 'admin/adjust_form', $data);
	}
	
    public function stokOpname_rules() {
        $this->form_validation->set_rules('stokfisik', 'Stok Fisik', 'trim|required');
        $this->form_validation->set_error_delimiters('<span class="label label-danger">', '</span><br><br>');
    }
	
	public function stokOpname_action(){
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
		$this->stokOpname_rules();
        $idproduk = $this->input->post('idproduk', TRUE);

        if ($this->form_validation->run() == FALSE) {
            $this->adjust();
        } else {	
            $get_produk=$this->AdminModel->get_produk($idproduk);
            $stok_awal=$get_produk->stok;

            $data = array(	
                'stok' => $this->input->post('stokfisik', TRUE),
            );
            $this->db->where('idproduk', $idproduk);
            if ($this->db->update('atha_produk', $data)){

                $adjust_stok = array(	
                    'tipe'  => 'Stok',
                    'idproduk'  => $idproduk,
                    'sebelum' => $stok_awal,
                    'sesudah' => $this->input->post('stokfisik', TRUE),
                );
                $this->db->insert('atha_adjusment', $adjust_stok);

				$this->pesaninfo('Data Berhasil Disimpan');
				redirect(site_url('admin/adjust'));
			} else {

				$this->pesaninfo('Data Gagal Disimpan');
				redirect(site_url('admin/adjust'));
			}
        }
	}
	
    public function hargaAdjust_rules() {
        $this->form_validation->set_rules('hargajual', 'Harga Satuan Jual', 'trim|required');
        $this->form_validation->set_rules('hargabeli', 'Harga Satuan Beli', 'trim|required');
        $this->form_validation->set_error_delimiters('<span class="label label-danger">', '</span><br><br>');
    }
	
	public function hargaAdjust_action(){
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
		$this->hargaAdjust_rules();
        $idproduk = $this->input->post('idproduk', TRUE);

        if ($this->form_validation->run() == FALSE) {
            $this->index();
        } else {			
            $get_produk=$this->AdminModel->get_produk($idproduk);
            $hargajual_awal=$get_produk->hargasatuanjual;
            $hargabeli_awal=$get_produk->hargasatuanbeli;

            $data = array(	
                'hargasatuanjual' => $this->input->post('hargajual', TRUE),
                'hargasatuanbeli' => $this->input->post('hargabeli', TRUE),
            );
            $this->db->where('idproduk', $idproduk);
            if ($this->db->update('atha_produk', $data)){
				
                $adjust_hargajual = array(	
                    'tipe'  => 'Harga Jual',
                    'idproduk'  => $idproduk,
                    'sebelum' => $hargajual_awal,
                    'sesudah' => $this->input->post('hargajual', TRUE),
                );
                $this->db->insert('atha_adjusment', $adjust_hargajual);

                $adjust_hargabeli = array(	
                    'tipe'  => 'Harga Beli',
                    'idproduk'  => $idproduk,
                    'sebelum' => $hargabeli_awal,
                    'sesudah' => $this->input->post('hargabeli', TRUE),
                );
                $this->db->insert('atha_adjusment', $adjust_hargabeli);

				$this->pesaninfo('Data Berhasil Disimpan');
				redirect(site_url('admin/adjust'));
			} else {

				$this->pesaninfo('Data Gagal Disimpan');
				redirect(site_url('admin/adjust'));
			}
        }
    }
    
    public function pesanerror($message) {
        $this->session->set_flashdata('idmessage', 1);
        $this->session->set_flashdata('message', $message);
    }

    public function pesaninfo($message) {
        $this->session->set_flashdata('idmessage', 2);
        $this->session->set_flashdata('message', $message);
    }
}
