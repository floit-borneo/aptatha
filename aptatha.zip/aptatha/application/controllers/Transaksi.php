<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('TransaksiModel');
        $this->load->model('LoginModel');
        $this->load->model('AdminModel');
        $hakakses = $this->session->userdata('hakakses');
		
        if (empty($hakakses)) {
            $this->pesanerror('Anda tidak mempunyai akses ke halaman ini');
            redirect(site_url('login'));
        }
		
    }
	
	public function index(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses_data = $this->session->userdata('hakakses_data');
        $data = array(
            'header' => 'Administrator',
			'changePassword_action' => 'profile/changePassword/',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses_data' => $hakakses_data
        );
		 $this->template->load('template/welcome', 'welcome/landing', $data);
	}
	
	/* ^barang masuk */
	public function barangMasuk(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$barangMasuk_data = $this->TransaksiModel->get_all_barangMasuk();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
			'barangMasuk_data' => $barangMasuk_data
        );
		 $this->template->load('template/transaksi', 'transaksi/barangMasuk', $data);
	}
	
	public function viewBarangMasuk($idbarangmasuk) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $barangmasuk = $this->TransaksiModel->get_barangMasuk($idbarangmasuk);
        $itemBarangMasuk_data = $this->TransaksiModel->get_all_itemBarangMasuk($idbarangmasuk);
        if ($barangmasuk) {
            $data = array(
				'header' => 'Administrator',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'barangMasuk',
                'state' => 'view',
                'idbarangmasuk' => $idbarangmasuk,
                'nmpembuat' => set_value('nmpembuat', $barangmasuk->nmpembuat),
                'tglbarangmasuk' => set_value('tglbarangmasuk', $barangmasuk->tglbarangmasuk),
				'jumlah' => set_value('jumlah', $barangmasuk->jumlah),
				'total' => set_value('total', $barangmasuk->total),
				'status' => set_value('status', $barangmasuk->status),
				'nmsupplier' => set_value('nmsupplier', $barangmasuk->nmsupplier),
				'tgljatuhtempo' => set_value('tgljatuhtempo', $barangmasuk->tgljatuhtempo),
				'payment' => set_value('payment', $barangmasuk->payment),
				'nofaktur' => set_value('nofaktur', $barangmasuk->nofaktur),
				'tglfaktur' => set_value('tglfaktur', $barangmasuk->tglfaktur),
				'diskon' => set_value('diskon', $barangmasuk->diskon),
				'ppn' => set_value('ppn', $barangmasuk->ppn),
				'keterangan' => set_value('keterangan', $barangmasuk->keterangan),
				'itemBarangMasuk_data' => $itemBarangMasuk_data
            );

			$this->template->load('template/transaksi', 'transaksi/barangMasuk_view', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/barangMasuk'));
        }
    }
		
	public function addBarangMasuk() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $supplier_data = $this->AdminModel->get_all_supplier();
        $data = array(
            'header' => 'Administrator',
			'idkaryawan_header' => $idkaryawan_header,
			'nmkaryawan_header' => $nmkaryawan_header,
			'hakakses' => $hakakses,
            'page' => 'barangMasuk',
            'addBarangMasuk_action' => site_url('transaksi/addBarangMasuk_action'),
            'state' => 'create',
            'idbarangmasuk' => set_value('idbarangmasuk'),
            'idpembuat' => set_value('idpembuat', 1),
            'tglbarangmasuk' => set_value('tglbarangmasuk', date("Y-m-d")),
			'jumlah' => set_value('jumlah', 0),
			'total' => set_value('total',0 ),
			'status' => set_value('status'),
			'idsupplier' => set_value('idsupplier', 1),
			'tgljatuhtempo' => set_value('tgljatuhtempo', date("Y-m-d")),
			'payment' => set_value('payment', 1),
			'nofaktur' => set_value('nofaktur'),
			'tglfaktur' => set_value('tglfaktur', date("Y-m-d")),
			'diskon_atas' => set_value('diskon_atas'),
			'ppn' => set_value('ppn'),
			'keterangan' => set_value('keterangan'),
            'supplier_data' => $supplier_data,
        );

		$this->template->load('template/transaksi', 'transaksi/barangMasuk_form', $data);
    }

    public function addBarangMasuk_rules() {
        $this->form_validation->set_rules('tglbarangmasuk', 'Tanggal Barang Masuk', 'trim|required');
        $this->form_validation->set_rules('nofaktur', 'Nomor faktur', 'trim|required');
        $this->form_validation->set_rules('tglfaktur', 'Tanggal Faktur', 'trim|required');
        $this->form_validation->set_error_delimiters('<span class="label label-danger">', '</span><br><br>');
    }
	
	public function addBarangMasuk_action() {
        $this->addBarangMasuk_rules();
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
        if ($this->form_validation->run() == FALSE) {
            $this->addBarangMasuk();
        } else {
			$payment=$this->input->post('payment', TRUE);
			if ($payment=="kontan"){
				$tgljatuhtempo=date("Y-m-d");
			}else{
				$tgljatuhtempo=date('Y-m-d', strtotime($this->input->post('tgljatuhtempo', TRUE)));
			}
			
            $data = array(
                'idpembuat' => $idkaryawan_header,
                'tglbarangmasuk' => date('Y-m-d', strtotime($this->input->post('tglbarangmasuk', TRUE))),
                'status' => 'Belum Lunas',
                'idsupplier' => $this->input->post('idsupplier', TRUE),
                'payment' => $payment,
                'tgljatuhtempo' => $tgljatuhtempo,
                'nofaktur' => $this->input->post('nofaktur', TRUE),
                'tglfaktur' => date('Y-m-d', strtotime($this->input->post('tglfaktur', TRUE))),
                'diskon' => $this->input->post('diskon_atas', TRUE),
                'ppn' => $this->input->post('ppn', TRUE),
                'keterangan' => $this->input->post('keterangan', TRUE),
            );
            $this->db->insert('atha_barangmasuk', $data);
			
				
			$idbarangmasuk = $this->TransaksiModel->get_latest_barangMasuk();
			
            $this->pesaninfo('Data Berhasil Disimpan. Masukkan Detail Per Item');
            redirect(site_url('transaksi/editBarangMasuk/'.$idbarangmasuk.'#itembarangmasuk'));
        }
    }
	
    public function hapusBarangMasuk($idbarangmasuk) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        
        $barangmasuk = $this->TransaksiModel->get_barangMasuk($idbarangmasuk);
        if ($barangmasuk) {
            $this->db->where('idbarangmasuk', $idbarangmasuk);
            if ($this->db->delete('atha_barangmasuk')) {
				
                $this->pesaninfo('Data berhasil dihapus');
            } else {
                $this->pesanerror('Data tidak berhasil dihapus');
            }
            redirect(site_url('transaksi/barangMasuk'));
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/barangMasuk'));
        }
    }
	
    public function editBarangMasuk($idbarangmasuk) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $supplier_data = $this->AdminModel->get_all_supplier();
        $produk_data = $this->AdminModel->get_all_produk();
        $barangmasuk = $this->TransaksiModel->get_barangMasuk($idbarangmasuk);
        $itemBarangMasuk_data = $this->TransaksiModel->get_all_itemBarangMasuk($idbarangmasuk);
        if ($barangmasuk) {
            $data = array(
				'header' => 'Administrator',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'barangMasuk',
				'editBarangMasuk_action' => site_url('transaksi/editBarangMasuk_action'),
				'addItemBarangMasuk_action' => site_url('transaksi/addItemBarangMasuk_action'),
				
                'state' => 'update',
                'idbarangmasuk' => $idbarangmasuk,
                'nmpembuat' => set_value('nmpembuat', $barangmasuk->nmpembuat),
                'tglbarangmasuk' => set_value('tglbarangmasuk', $barangmasuk->tglbarangmasuk),
				'jumlah' => set_value('jumlah', $barangmasuk->jumlah),
				'total' => set_value('total', $barangmasuk->total),
				'status' => set_value('status', $barangmasuk->status),
				'idsupplier' => set_value('idsupplier', $barangmasuk->idsupplier),
				'tgljatuhtempo' => set_value('tgljatuhtempo', $barangmasuk->tgljatuhtempo),
				'payment' => set_value('payment', $barangmasuk->payment),
				'nofaktur' => set_value('nofaktur', $barangmasuk->nofaktur),
				'tglfaktur' => set_value('tglfaktur', $barangmasuk->tglfaktur),
				'diskon_atas' => set_value('diskon', $barangmasuk->diskon),
				'ppn' => set_value('ppn', $barangmasuk->ppn),
				'keterangan' => set_value('keterangan', $barangmasuk->keterangan),
				'supplier_data' => $supplier_data,
				
				'item_state' => 'item_create',
				'iditembarangmasuk' => set_value('iditembarangmasuk'),
				'idproduk' => set_value('idproduk',1),
				'jumlah_item' => set_value('jumlah_item', 0),
				'harga_item' => set_value('harga_item', 0),
				'subtotal' => set_value('subtotal', 0),
				'tglkadaluarsa' => set_value('tglkadaluarsa', date('Y-m-d')),
				'diskon' => set_value('diskon'),
				'produk_data' => $produk_data,
				'itemBarangMasuk_data' => $itemBarangMasuk_data
            );

			$this->template->load('template/transaksi', 'transaksi/barangMasuk_form', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/barangMasuk'));
        }
    }

    public function editBarangMasuk_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
        $this->addBarangMasuk_rules();
        $idbarangmasuk = $this->input->post('idbarangmasuk', TRUE);

        if ($this->form_validation->run() == FALSE) {
            $this->editBarangMasuk($idbarangmasuk);
        } else {
			$payment=$this->input->post('payment', TRUE);
			if ($payment=="kontan"){
				$tgljatuhtempo=date("Y-m-d");
			}else{
				$tgljatuhtempo=date('Y-m-d', strtotime($this->input->post('tgljatuhtempo', TRUE)));
			}
			
            $data_barangmasuk = array(
                'tglbarangmasuk' => date('Y-m-d', strtotime($this->input->post('tglbarangmasuk', TRUE))),
                'status' => $this->input->post('status', TRUE),
                'idsupplier' => $this->input->post('idsupplier', TRUE),
                'payment' => $payment,
                'tgljatuhtempo' => $tgljatuhtempo,
                'nofaktur' => $this->input->post('nofaktur', TRUE),
                'tglfaktur' => $this->input->post('tglfaktur', TRUE),
                'diskon' => $this->input->post('diskon_atas', TRUE),
                'ppn' => $this->input->post('ppn', TRUE),
                'keterangan' => $this->input->post('keterangan', TRUE),
            );
            $this->db->where('idbarangmasuk', $idbarangmasuk);
            if ($this->db->update('atha_barangmasuk', $data_barangmasuk)){

				$this->pesaninfo('Data Berhasil Disimpan');
				redirect(site_url('transaksi/editBarangMasuk/'.$idbarangmasuk));
			} else {

				$this->pesaninfo('Data Gagal Disimpan');
				redirect(site_url('transaksi/editBarangMasuk/'.$idbarangmasuk));
			}
        }
    }
	
	public function addItemBarangMasuk_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		$idbarangmasuk = $this->input->post('idbarangmasuk', TRUE);
		$idproduk = $this->input->post('idproduk', TRUE);
        $produk = $this->AdminModel->get_produk($idproduk);
		$harga=$produk->hargasatuanbeli;
		
            $data = array(
                'idbarangmasuk' => $idbarangmasuk,
                'idproduk' => $idproduk,
                'jumlah' => $this->input->post('jumlah_item', TRUE),
                'harga' => $harga,
                'tglkdluarsa' => date('Y-m-d', strtotime($this->input->post('tglkadaluarsa', TRUE))),
            );
            if ($this->db->insert('atha_itembarangmasuk', $data)){
			
				
				$this->pesaninfo('Data Berhasil Disimpan');
			} else {
				$this->pesanerror('Data Gagal Disimpan');
			}
            redirect(site_url('transaksi/editBarangMasuk/'.$idbarangmasuk.'#itembarangmasuk'));
			
    }
		
    public function editItemBarangMasuk($idbarangmasuk, $iditembarangmasuk) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $supplier_data = $this->AdminModel->get_all_supplier();
        $produk_data = $this->AdminModel->get_all_produk();
        $barangmasuk = $this->TransaksiModel->get_barangMasuk($idbarangmasuk);
        $itemBarangMasuk_data = $this->TransaksiModel->get_all_itemBarangMasuk($idbarangmasuk);
        $itembarangmasuk = $this->TransaksiModel->get_itemBarangMasuk($iditembarangmasuk);
        if ($itembarangmasuk) {
            $data = array(
				'header' => 'Administrator',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'barangMasuk',
				'editBarangMasuk_action' => site_url('transaksi/editBarangMasuk_action'),
				
                'state' => 'update',
                'idbarangmasuk' => $idbarangmasuk,
                'nmpembuat' => set_value('nmpembuat', $barangmasuk->nmpembuat),
                'tglbarangmasuk' => set_value('tglbarangmasuk', $barangmasuk->tglbarangmasuk),
				'jumlah' => set_value('jumlah', $barangmasuk->jumlah),
				'total' => set_value('total', $barangmasuk->total),
				'status' => set_value('status', $barangmasuk->status),
				'idsupplier' => set_value('idsupplier', $barangmasuk->idsupplier),
				'tgljatuhtempo' => set_value('tgljatuhtempo', $barangmasuk->tgljatuhtempo),
				'payment' => set_value('payment', $barangmasuk->payment),
				'nofaktur' => set_value('nofaktur', $barangmasuk->nofaktur),
				'tglfaktur' => set_value('tglfaktur', $barangmasuk->tglfaktur),
				'ppn' => set_value('ppn', $barangmasuk->ppn),
				'diskon_atas' => set_value('ppn', $barangmasuk->diskon),
				'keterangan' => set_value('keterangan', $barangmasuk->keterangan),
				'supplier_data' => $supplier_data,
				
				'item_state' => 'item_update',
				'editItemBarangMasuk_action' => site_url('transaksi/editItemBarangMasuk_action'),
				'iditembarangmasuk' => set_value('iditembarangmasuk', $itembarangmasuk->iditembarangmasuk),
				'idproduk' => set_value('idproduk', $itembarangmasuk->idproduk),
				'jumlah_item' => set_value('jumlah_item', $itembarangmasuk->jumlah),
				'harga_item' => set_value('harga_item', $itembarangmasuk->harga),
				'subtotal' => set_value('subtotal', $itembarangmasuk->subtotal),
				'tglkadaluarsa' => set_value('tglkadaluarsa', date('Y-m-d', strtotime($itembarangmasuk->tglkdluarsa))),
				'diskon' => set_value('diskon', $itembarangmasuk->diskon),
				'produk_data' => $produk_data,
				'itemBarangMasuk_data' => $itemBarangMasuk_data
            );

			$this->template->load('template/transaksi', 'transaksi/barangMasuk_form', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/barangMasuk'));
        }
    }
	
	public function editItemBarangMasuk_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		$idbarangmasuk = $this->input->post('idbarangmasuk', TRUE);
		$iditembarangmasuk = $this->input->post('iditembarangmasuk', TRUE);
		$idproduk = $this->input->post('idproduk', TRUE);
        $produk = $this->AdminModel->get_produk($idproduk);
		$harga=$produk->hargasatuanbeli;
		
            $data = array(
                'idbarangmasuk' => $idbarangmasuk,
                'idproduk' => $idproduk,
                'jumlah' => $this->input->post('jumlah_item', TRUE),
                'harga' => $harga,
                'tglkdluarsa' => date('Y-m-d', strtotime($this->input->post('tglkadaluarsa', TRUE))),
            );
            $this->db->where('iditembarangmasuk', $iditembarangmasuk);
            if ($this->db->update('atha_itembarangmasuk', $data)){

				
				$this->pesaninfo('Data Berhasil Disimpan');
				redirect(site_url('transaksi/editBarangMasuk/'.$idbarangmasuk.'#itembarangmasuk'));
			} else {

				$this->pesaninfo('Data Gagal Disimpan');
				redirect(site_url('transaksi/editBarangMasuk/'.$idbarangmasuk));
			}
			
			
    }
	
    public function hapusItemBarangMasuk($idbarangmasuk, $iditembarangmasuk) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        
        $itemBarangMasuk = $this->TransaksiModel->get_itemBarangMasuk($iditembarangmasuk);
        if ($itemBarangMasuk) {
            $this->db->where('iditembarangmasuk', $iditembarangmasuk);
            if ($this->db->delete('atha_itembarangmasuk')) {
				
                $this->pesaninfo('Data berhasil dihapus');
            } else {
                $this->pesanerror('Data tidak berhasil dihapus');
            }
            redirect(site_url('transaksi/editBarangMasuk/'.$idbarangmasuk.'#tabelitembarangmasuk'));
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/editBarangMasuk/'.$idbarangmasuk.'#tabelitembarangmasuk'));
        }
    }
		
	/* ^penjualan dengan resep */
	public function penjualanDgnResep(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$penjualanDgnResep_data = $this->TransaksiModel->get_all_penjualanDgnResep();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
		
			'penjualanDgnResep_data' => $penjualanDgnResep_data
        );
		 $this->template->load('template/transaksi', 'transaksi/penjualanDgnResep', $data);
	}
	
    public function viewPenjualanDgnResep($idpenjualan) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $produk_data = $this->AdminModel->get_all_produk();
        $penjualan = $this->TransaksiModel->get_penjualanDgnResep($idpenjualan);
        $itemracikan_data = $this->TransaksiModel->get_all_itemRacikan($idpenjualan);
        if ($penjualan) {
            $data = array(
				'header' => 'Transaksi',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'penjualan',
				'editPenjualanDgnResep_action' => site_url('transaksi/editPenjualanDgnResep_action'),
				'addRacikan_action' => site_url('transaksi/addRacikan_action'),
				'addNonRacikan_action' => site_url('transaksi/addNonRacikan_action'),
				
                'state' => 'update',
                'idpenjualan' => $idpenjualan,
                'nmpembuat' => set_value('nmpembuat', $penjualan->nmpembuat),
                'nmdokter' => set_value('nmdokter', $penjualan->nmdokter),
                'tglpenjualan' => set_value('tglpenjualan', $penjualan->tglpenjualan),
				'jumlah' => set_value('jumlah', $penjualan->jumlah),
				'total' => set_value('total', $penjualan->total),
				'diskon' => set_value('diskon', $penjualan->diskon),
				'keterangan' => set_value('keterangan', $penjualan->keterangan),
				'komisi' => set_value('komisi', $penjualan->komisi),
				
				'iditemresep' => set_value('iditemresep'),
				
				'produk_data' => $produk_data,
				'itemracikan_data' => $itemracikan_data
				
            );

			$this->template->load('template/transaksi', 'transaksi/penjualanDgnResep_view', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/addPenjualanDgnResep'));
        }
    }
	
	public function addPenjualanDgnResep() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $data = array(
            'header' => 'Transaksi',
			'idkaryawan_header' => $idkaryawan_header,
			'nmkaryawan_header' => $nmkaryawan_header,
			'hakakses' => $hakakses,
            'page' => 'penjualan',
            'addPenjualanDgnResep_action' => site_url('transaksi/addPenjualanDgnResep_action'),
            'state' => 'create',
            'idpenjualan' => set_value('idpenjualan'),
            'idpembuat' => set_value('idpembuat'),
            'tglpenjualan' => set_value('tglpenjualan', date('Y-m-d')),
			'jumlah' => set_value('jumlah', 0),
			'dokter' => set_value('dokter'),
			'total_caps' => set_value('total_caps', 0),
			'total' => set_value('total', 0),
			'diskon' => set_value('diskon', 0),
			'keterangan' => set_value('keterangan'),
			'komisi' => set_value('komisi', 0)
        );

		$this->template->load('template/transaksi', 'transaksi/penjualanDgnResep_form', $data);
    }
	
    public function addPenjualanDgnResep_action(){
         $this->addPenjualan_rules();
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
        if ($this->form_validation->run() == FALSE) {
            $this->addPenjualanDgnResep();
        } else {			
            $data = array(
                'idpembuat' => $idkaryawan_header,
                'tglpenjualan' => date('Y-m-d', strtotime($this->input->post('tglpenjualan', TRUE))),
                'nmdokter' => $this->input->post('dokter', TRUE),
                'diskon' => $this->input->post('diskon', TRUE),
                'keterangan' => $this->input->post('keterangan', TRUE),
            );
            $this->db->insert('atha_penjualandgnresep', $data);
			
			$idpenjualan = $this->TransaksiModel->get_latest_penjualanDgnResep();
			
				
            $this->pesaninfo('Data Berhasil Disimpan. Masukkan Detail Per Item');
            redirect(site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan.'#itempenjualandenganresep'));
        }
    }

    public function editPenjualanDgnResep($idpenjualan) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $produk_data = $this->AdminModel->get_all_produk();
        $penjualan = $this->TransaksiModel->get_penjualanDgnResep($idpenjualan);
        $itemracikan_data = $this->TransaksiModel->get_all_itemRacikan($idpenjualan);
        if ($penjualan) {
            $data = array(
				'header' => 'Transaksi',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'penjualan',
				'editPenjualanDgnResep_action' => site_url('transaksi/editPenjualanDgnResep_action'),
				'addRacikan_action' => site_url('transaksi/addRacikan_action'),
				'addNonRacikan_action' => site_url('transaksi/addNonRacikan_action'),
				
                'state' => 'update',
                'idpenjualan' => $idpenjualan,
                'nmpembuat' => set_value('nmpembuat', $penjualan->nmpembuat),
				'dokter' => set_value('dokter', $penjualan->nmdokter),
                'tglpenjualan' => set_value('tglpenjualan', $penjualan->tglpenjualan),
				'jumlah' => set_value('jumlah', $penjualan->jumlah),
				'total' => set_value('total', $penjualan->total),
				'diskon' => set_value('diskon', $penjualan->diskon),
				'keterangan' => set_value('keterangan', $penjualan->keterangan),
				'komisi' => set_value('komisi', $penjualan->komisi),
				
				'iditemresep' => set_value('iditemresep'),
				
				'racikan_state' => 'racikan_create',
				'jumlah_caps_racikan' => set_value('jumlah_caps_racikan', 0),
				'jumlah_produk_racikan' => set_value('jumlah_produk_racikan', 0),
				'tuslah_racikan' => set_value('tuslah_racikan', 0),
				'subtotal_racikan' => set_value('subtotal_racikan', 0),
				
				'nonracikan_state' => 'nonracikan_create',
				'idproduk' => set_value('idproduk',1),
				'jumlah_caps_non' => set_value('jumlah_caps_non', 0),
				'harga_item_non' => set_value('harga_item_non', 0),
				'subtotal_non' => set_value('subtotal_non', 0),
				'produk_data' => $produk_data,
				'itemracikan_data' => $itemracikan_data
				
            );

			$this->template->load('template/transaksi', 'transaksi/penjualanDgnResep_form', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/addPenjualanDgnResep'));
        }
    }
	
    public function editPenjualanDgnResep_action(){
         $this->addPenjualan_rules();
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
		$idpenjualan = $this->input->post('idpenjualan', TRUE);
        if ($this->form_validation->run() == FALSE) {
            $this->addPenjualanDgnResep();
        } else {			
            $data = array(
                //'idpembuat' => $idkaryawan_header,
                'tglpenjualan' => date('Y-m-d', strtotime($this->input->post('tglpenjualan', TRUE))),
                'iddokter' => $this->input->post('iddokter', TRUE),
                'diskon' => $this->input->post('diskon', TRUE),
                'keterangan' => $this->input->post('keterangan', TRUE),
            );
            $this->db->where('idpenjualan', $idpenjualan);
            $this->db->update('atha_penjualandgnresep', $data);
						
				$this->total_penjualandgnresep($idpenjualan);
				
            $this->pesaninfo('Data Berhasil Disimpan.');
			//echo  $this->input->post('diskon', TRUE);
            redirect(site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan.'#itempenjualandenganresep'));
        }
    }
	
    public function hapusPenjualanDgnResep($idpenjualan) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        
        $penjualanDgnResep = $this->TransaksiModel->get_penjualanDgnResep($idpenjualan);
        if ($penjualanDgnResep) {
            $this->db->where('idpenjualan', $idpenjualan);
            if ($this->db->delete('atha_penjualandgnresep')) {
				
                $this->pesaninfo('Data berhasil dihapus');
            } else {
                $this->pesanerror('Data tidak berhasil dihapus');
            }
            redirect(site_url('transaksi/penjualanDgnResep/'));
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/penjualanDgnResep/'));
        }
    }
	
	public function addNonRacikan_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		$idpenjualan = $this->input->post('idpenjualan', TRUE);
            $data = array(
                'idpenjualan' => $idpenjualan,
                'jumlah' => $this->input->post('jumlah_caps_non', TRUE),
                'tuslah' => 500,
				'tipe' => 'Non Racikan'
            );
            $this->db->insert('atha_itemresep', $data);
			
		$iditemresep = $this->TransaksiModel->get_latest_itemResep();
            $data_item = array(
                'iditemresep' => $iditemresep,
                'idproduk' => $this->input->post('idproduk', TRUE),
                'jumlah' => $this->input->post('jumlah_caps_non', TRUE),
            );
            $this->db->insert('atha_itemracikan', $data_item);
			
				$this->total_penjualandgnresep($idpenjualan);
				
        $this->pesaninfo('Data Berhasil Disimpan.');
        redirect(site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan.'#tabelitempenjualandenganresep'));
			
    }
	
	public function addRacikan_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		$idpenjualan = $this->input->post('idpenjualan', TRUE);
            $data = array(
                'idpenjualan' => $idpenjualan,
                'jumlah' => $this->input->post('jumlah_caps_racikan', TRUE),
                'tuslah' => $this->input->post('tuslah_racikan', TRUE),
				'tipe' => 'Racikan'
            );
            $this->db->insert('atha_itemresep', $data);
			
		$iditemresep = $this->TransaksiModel->get_latest_itemResep();
			
				$this->total_penjualandgnresep($idpenjualan);
				
        $this->pesaninfo('Data Berhasil Disimpan. Masukkan Detail Per Item');
        redirect(site_url('transaksi/addItemRacikan/'.$idpenjualan.'/'.$iditemresep.'#tabelitempenjualandenganresep'));
    }
	
    public function addItemRacikan($idpenjualan, $iditemresep) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $produk_data = $this->AdminModel->get_all_produk();
		$itemresep = $this->TransaksiModel->get_itemResep($iditemresep);
        $itemracikan_data = $this->TransaksiModel->get_all_itemRacikan_minor($iditemresep);
        if ($itemresep) {
            $data = array(
				'header' => 'Transaksi',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'penjualan',
				'editRacikan_action' => site_url('transaksi/editRacikan_action'),
				'addItemRacikan_action' => site_url('transaksi/addItemRacikan_action'),
						
				'racikan_state' => 'racikan_update',
                'idpenjualan' => $idpenjualan,
				'iditemresep' => $iditemresep,
				'tipe' => set_value('tipe', $itemresep->tipe),
				'jumlah_caps_racikan' => set_value('jumlah_caps_racikan', $itemresep->jumlah),
				'jumlah_produk_racikan' => set_value('jumlah_produk_racikan', $itemresep->jumlah_produk),
				'tuslah_racikan' => set_value('tuslah_racikan', $itemresep->tuslah),
				'subtotal_racikan' => set_value('subtotal_racikan', $itemresep->subtotal),
				
				'item_state' => 'item_create',
				'idproduk' => set_value('idproduk',1),
				'jumlah_item' => set_value('jumlah', 0),
				'harga_item' => set_value('harga', 0),
				'subtotal_item' => set_value('subtotal', 0),
				'produk_data' => $produk_data,
				'itemracikan_data' => $itemracikan_data				
            );

			$this->template->load('template/transaksi', 'transaksi/itemRacikan_form', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/addPenjualanDgnResep'));
        }
    }
	
	public function editRacikan_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		$iditemresep = $this->input->post('iditemresep', TRUE);
		$idpenjualan = $this->input->post('idpenjualan', TRUE);
            $data = array(
                'jumlah' => $this->input->post('jumlah_caps_racikan', TRUE),
                'tuslah' => $this->input->post('tuslah_racikan', TRUE),
            );
            $this->db->where('iditemresep', $iditemresep);
            if ($this->db->update('atha_itemresep', $data)){

				$this->total_penjualandgnresep($idpenjualan);
				
				$this->pesaninfo('Data Berhasil Disimpan');
				redirect(site_url('transaksi/addItemRacikan/'.$idpenjualan.'/'.$iditemresep.'#tabelitemracikan'));
			} else {

				$this->pesaninfo('Data Gagal Disimpan');
				redirect(site_url('transaksi/addItemRacikan/'.$idpenjualan.'/'.$iditemresep.'#tabelitemracikan'));
			}
			
    }
	public function addItemRacikan_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
			
		$idpenjualan = $this->input->post('idpenjualan', TRUE);
		$iditemresep = $this->input->post('iditemresep', TRUE);
            $data_item = array(
                'iditemresep' => $iditemresep,
                'idproduk' => $this->input->post('idproduk', TRUE),
                'jumlah' => $this->input->post('jumlah_item', TRUE),
            );
            $this->db->insert('atha_itemracikan', $data_item);
			
				$this->total_penjualandgnresep($idpenjualan);
				
        $this->pesaninfo('Data Berhasil Disimpan. Masukkan Detail Per Item');
        redirect(site_url('transaksi/addItemRacikan/'.$idpenjualan.'/'.$iditemresep));
			
    }
	
    public function editItemRacikan($idpenjualan, $iditemresep, $iditemracikan) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $produk_data = $this->AdminModel->get_all_produk();
		$itemresep = $this->TransaksiModel->get_itemResep($iditemresep);
        $penjualan = $this->TransaksiModel->get_penjualanDgnResep($idpenjualan);
        $itemracikan_data = $this->TransaksiModel->get_all_itemRacikan_minor($iditemresep);
        $itemracikan = $this->TransaksiModel->get_itemRacikan($iditemracikan);
        if ($itemracikan) {
            $data = array(
				'header' => 'Transaksi',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'penjualan',
				'editRacikan_action' => site_url('transaksi/editRacikan_action'),
						
				'racikan_state' => 'racikan_update',
                'idpenjualan' => $idpenjualan,
				'iditemresep' => $iditemresep,
				'tipe' => set_value('tipe', $itemresep->tipe),
				'jumlah_caps_racikan' => set_value('jumlah_caps_racikan', $itemresep->jumlah),
				'jumlah_produk_racikan' => set_value('jumlah_produk_racikan', $itemresep->jumlah_produk),
				'tuslah_racikan' => set_value('tuslah_racikan', $itemresep->tuslah),
				'subtotal_racikan' => set_value('subtotal_racikan', $itemresep->subtotal),
				
				'item_state' => 'item_update',
				'editItemRacikan_action' => site_url('transaksi/editItemRacikan_action'),
				'iditemracikan' => set_value('iditemracikan', $itemracikan->iditemracikan),
				'idproduk' => set_value('idproduk', $itemracikan->idproduk),
				'jumlah_item' => set_value('jumlah_item', $itemracikan->jumlah),
				'harga_item' => set_value('harga_item', $itemracikan->harga),
				'subtotal_item' => set_value('subtotal_item', $itemracikan->subtotal),
				'produk_data' => $produk_data,
				'itemracikan_data' => $itemracikan_data				
            );

			$this->template->load('template/transaksi', 'transaksi/itemRacikan_form', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/addItemRacikan'));
        }
    }
	
	public function editItemRacikan_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		$idracikan = $this->input->post('idracikan', TRUE);
		$iditemresep = $this->input->post('iditemresep', TRUE);
		$iditemracikan = $this->input->post('iditemracikan', TRUE);
		$idpenjualan = $this->input->post('idpenjualan', TRUE);
            $data = array(
                'idproduk' => $this->input->post('idproduk', TRUE),
                'jumlah' => $this->input->post('jumlah_item', TRUE),
                'harga' => $this->input->post('harga_item', TRUE),
            );
            $this->db->where('iditemracikan', $iditemracikan);
            if ($this->db->update('atha_itemracikan', $data)){

				$this->total_penjualandgnresep($idpenjualan);
				
				$this->pesaninfo('Data Berhasil Disimpan');
				redirect(site_url('transaksi/editItemRacikan/'.$idpenjualan.'/'.$iditemresep.'/'.$iditemracikan.'#tabelitemracikan'));
			} else {

				$this->pesaninfo('Data Gagal Disimpan');
				redirect(site_url('transaksi/addItemRacikan/'.$idpenjualan.'/'.$iditemresep.'#tabelitemracikan'));
			}
			
    }
	
    public function hapusItemRacikan($idpenjualan, $iditemresep, $iditemracikan) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
                
        $itemRacikan = $this->TransaksiModel->get_itemRacikan($iditemracikan);
        if ($itemRacikan) {
            $this->db->where('iditemracikan', $iditemracikan);
            if ($this->db->delete('atha_itemracikan')) {
				$itemRacikan = $this->TransaksiModel->get_itemRacikan($iditemracikan);
				if ($itemRacikan) {
					
				$this->total_penjualandgnresep($idpenjualan);
				
					$this->pesaninfo('Data berhasil dihapus');	
					redirect(site_url('transaksi/addItemRacikan/'.$idpenjualan.'/'.$iditemresep.'#tabelitemracikan'));
				}else{
					$this->db->where('iditemresep', $iditemresep);
					if ($this->db->delete('atha_itemresep')) {
						
				
						$this->pesaninfo('Data berhasil dihapus');	
						redirect(site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan.'#tabelitemracikan'));
					}
				}
            } else {
                $this->pesanerror('Data tidak berhasil dihapus');
				redirect(site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan.'#tabelitemracikan'));
            }
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
			redirect(site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan.'#tabelitemracikan'));
        }
    }
	
    public function editItemNonRacikan($idpenjualan, $iditemresep, $iditemracikan) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $produk_data = $this->AdminModel->get_all_produk();
        $penjualan = $this->TransaksiModel->get_penjualanDgnResep($idpenjualan);
        $itemracikan_data = $this->TransaksiModel->get_all_itemRacikan($idpenjualan);
        $itemnonracikan = $this->TransaksiModel->get_itemNonRacikan($iditemracikan);
        if ($penjualan) {
            $data = array(
				'header' => 'Transaksi',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'penjualan',
				'editPenjualanDgnResep_action' => site_url('transaksi/editPenjualanDgnResep_action'),
				'addRacikan_action' => site_url('transaksi/addRacikan_action'),
				'editNonRacikan_action' => site_url('transaksi/editNonRacikan_action'),
				
                'state' => 'update',
                'idpenjualan' => $idpenjualan,
                'nmpembuat' => set_value('nmpembuat', $penjualan->nmpembuat),
                'dokter' => set_value('dokter', $penjualan->nmdokter),
                'tglpenjualan' => set_value('tglpenjualan', $penjualan->tglpenjualan),
				'jumlah' => set_value('jumlah', $penjualan->jumlah),
				'total' => set_value('total', $penjualan->total),
				'diskon' => set_value('diskon', $penjualan->diskon),
				'keterangan' => set_value('keterangan', $penjualan->keterangan),
				'komisi' => set_value('komisi', $penjualan->komisi),
				
				'iditemresep' => set_value('iditemresep'),
				
				'racikan_state' => 'racikan_create',
				'jumlah_caps_racikan' => set_value('jumlah_caps_racikan', 0),
				'jumlah_produk_racikan' => set_value('jumlah_produk_racikan', 0),
				'tuslah_racikan' => set_value('tuslah_racikan', 0),
				'subtotal_racikan' => set_value('subtotal_racikan', 0),
				
				'nonracikan_state' => 'nonracikan_update',
				'iditemracikan' => set_value('iditemracikan', $itemnonracikan->iditemracikan),
				'idproduk' => set_value('idproduk', $itemnonracikan->idproduk),
				'jumlah_caps_non' => set_value('jumlah_caps_non', $itemnonracikan->jumlah),
				'harga_item_non' => set_value('harga_item_non', $itemnonracikan->harga),
				'subtotal_non' =>  set_value('subtotal_non', $itemnonracikan->subtotal),
				'produk_data' => $produk_data,
				'itemracikan_data' => $itemracikan_data
				
            );

			$this->template->load('template/transaksi', 'transaksi/penjualanDgnResep_form', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/addPenjualanDgnResep'));
        }
    }
	
	public function editNonRacikan_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		$idracikan = $this->input->post('idracikan', TRUE);
		$iditemresep = $this->input->post('iditemresep', TRUE);
		$iditemracikan = $this->input->post('iditemracikan', TRUE);
		$idpenjualan = $this->input->post('idpenjualan', TRUE);
            $data = array(
                'idproduk' => $this->input->post('idproduk', TRUE),
                'jumlah' => $this->input->post('jumlah_caps_non', TRUE),
            );
            $this->db->where('iditemracikan', $iditemracikan);
            if ($this->db->update('atha_itemracikan', $data)){

				$this->total_penjualandgnresep($idpenjualan);
				
				$this->pesaninfo('Data Berhasil Disimpan');
				redirect(site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan.'#tabelitemracikan'));
			} else {

				$this->pesaninfo('Data Gagal Disimpan');
				redirect(site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan.'#tabelitemracikan'));
			}
			
    }
    public function hapusItemNonRacikan($idpenjualan, $iditemresep, $iditemracikan) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        
        $itemRacikan = $this->TransaksiModel->get_itemRacikan($iditemracikan);
        if ($itemRacikan) {
            $this->db->where('iditemracikan', $iditemracikan);
            if ($this->db->delete('atha_itemracikan')) {
				$itemRacikan = $this->TransaksiModel->get_itemRacikan($iditemracikan);
				if ($itemRacikan) {
				
				$this->total_penjualandgnresep($idpenjualan);
				
					$this->pesaninfo('Data berhasil dihapus');	
					redirect(site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan.'#tabelitemracikan'));
				}else{
					$this->db->where('iditemresep', $iditemresep);
					if ($this->db->delete('atha_itemresep')) {
						
						$this->total_penjualandgnresep($idpenjualan);
						$this->pesaninfo('Data berhasil dihapus');	
						redirect(site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan.'#tabelitemracikan'));
					}
				}
            } else {
                $this->pesanerror('Data tidak berhasil dihapus');
				redirect(site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan.'#tabelitemracikan'));
            }
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
			redirect(site_url('transaksi/editPenjualanDgnResep/'.$idpenjualan.'#tabelitemracikan'));
        }
    }
	
	/* ^penjualan tanpa resep */
	public function penjualanTnpResep(){
		$idkaryawan = $this->session->userdata('idkaryawan');
        $nmkaryawan = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
		$penjualanTnpResep_data = $this->TransaksiModel->get_all_penjualanTnpResep();
		
        $data = array(
            'header' => 'Administrator',
			'idkaryawan' => $idkaryawan,
			'nmkaryawan' => $nmkaryawan,
			'hakakses' => $hakakses,
		
			'penjualanTnpResep_data' => $penjualanTnpResep_data
        );
		 $this->template->load('template/transaksi', 'transaksi/penjualanTnpResep', $data);
	}
	
	public function viewPenjualanTnpResep($idpenjualan) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $penjualan = $this->TransaksiModel->get_penjualanTnpResep($idpenjualan);
        $itemPenjualanTnpResep_data = $this->TransaksiModel->get_all_itemPenjualanTnpResep($idpenjualan);
        if ($penjualan) {
            $data = array(
				'header' => 'Transaksi',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'penjualan',
                'state' => 'view',
                'idpenjualan' => $idpenjualan,
                'nmpembuat' => set_value('nmpembuat', $penjualan->nmpembuat),
                'tglpenjualan' => set_value('tglpenjualan', $penjualan->tglpenjualan),
				'jumlah' => set_value('jumlah', $penjualan->jumlah),
				'total' => set_value('total', $penjualan->total),
				'diskon' => set_value('diskon', $penjualan->diskon),
				'keterangan' => set_value('keterangan', $penjualan->keterangan),
				'itemPenjualanTnpResep_data' => $itemPenjualanTnpResep_data
            );

			$this->template->load('template/transaksi', 'transaksi/penjualanTnpResep_view', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/penjualan'));
        }
    }
		
	public function addPenjualanTnpResep() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $data = array(
            'header' => 'Transaksi',
			'idkaryawan_header' => $idkaryawan_header,
			'nmkaryawan_header' => $nmkaryawan_header,
			'hakakses' => $hakakses,
            'page' => 'penjualan',
            'addPenjualanTnpResep_action' => site_url('transaksi/addPenjualanTnpResep_action'),
            'state' => 'create',
            'idpenjualan' => set_value('idpenjualan'),
            'idpembuat' => set_value('idpembuat'),
            'tglpenjualan' => set_value('tglpenjualan', date('Y-m-d')),
			'jumlah' => set_value('jumlah', 0),
			'total' => set_value('total', 0),
			'diskon' => set_value('diskon', 0),
			'keterangan' => set_value('keterangan')
        );

		$this->template->load('template/transaksi', 'transaksi/penjualanTnpResep_form', $data);
    }

    public function addPenjualan_rules() {
        $this->form_validation->set_rules('tglpenjualan', 'Tanggal Penjualan', 'trim|required');
        $this->form_validation->set_error_delimiters('<span class="label label-danger">', '</span><br><br>');
    }
	
	public function addPenjualanTnpResep_action() {
        $this->addPenjualan_rules();
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
        if ($this->form_validation->run() == FALSE) {
            $this->addPenjualanTnpResep();
        } else {			
            $data = array(
                'idpembuat' => $idkaryawan_header,
                'tglpenjualan' => date('Y-m-d', strtotime($this->input->post('tglpenjualan', TRUE))),
                'diskon' => $this->input->post('diskon', TRUE),
                'keterangan' => $this->input->post('keterangan', TRUE),
            );
            $this->db->insert('atha_penjualan', $data);
			
			$idpenjualan = $this->TransaksiModel->get_latest_penjualanTnpResep();
			
				
            $this->pesaninfo('Data Berhasil Disimpan. Masukkan Detail Per Item');
            redirect(site_url('transaksi/editPenjualanTnpResep/'.$idpenjualan.'#itempenjualantanparesep'));
        }
    }
	
    public function hapusPenjualanTnpResep($idpenjualan) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        
        $penjualan = $this->TransaksiModel->get_penjualanTnpResep($idpenjualan);
        if ($penjualan) {
            $this->db->where('idpenjualan', $idpenjualan);
            if ($this->db->delete('atha_penjualan')) {
                $this->pesaninfo('Data berhasil dihapus');
            } else {
                $this->pesanerror('Data tidak berhasil dihapus');
            }
				
            redirect(site_url('transaksi/penjualanTnpResep'));
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/penjualanTnpResep'));
        }
    }
	
    public function editPenjualanTnpResep($idpenjualan) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $produk_data = $this->AdminModel->get_all_produk();
        $penjualan = $this->TransaksiModel->get_penjualanTnpResep($idpenjualan);
        $itemPenjualanTnpResep_data = $this->TransaksiModel->get_all_itemPenjualanTnpResep($idpenjualan);
        if ($penjualan) {
            $data = array(
				'header' => 'Transaksi',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'penjualan',
				'editPenjualanTnpResep_action' => site_url('transaksi/editPenjualanTnpResep_action'),
				'addItemPenjualanTnpResep_action' => site_url('transaksi/addItemPenjualanTnpResep_action'),
				
                'state' => 'update',
                'idpenjualan' => $idpenjualan,
                'nmpembuat' => set_value('nmpembuat', $penjualan->nmpembuat),
                'tglpenjualan' => set_value('tglpenjualan', $penjualan->tglpenjualan),
				'jumlah' => set_value('jumlah', $penjualan->jumlah),
				'total' => set_value('total', $penjualan->total),
				'diskon' => set_value('diskon', $penjualan->diskon),
				'keterangan' => set_value('keterangan', $penjualan->keterangan),
				
				'item_state' => 'item_create',
				'iditempenjualan' => set_value('iditempenjualan'),
				'idproduk' => set_value('idproduk',1),
				'jumlah_item' => set_value('jumlah_item', 0),
				'harga_item' => set_value('harga_item', 0),
				'subtotal' => set_value('subtotal', 0),
				'diskon_item' => set_value('diskon_item', 0),
				'tipe' => set_value('tipe'),
				'produk_data' => $produk_data,
				'itemPenjualanTnpResep_data' => $itemPenjualanTnpResep_data
            );

			$this->template->load('template/transaksi', 'transaksi/penjualanTnpResep_form', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/penjualanTnpResep'));
        }
    }

    public function editPenjualanTnpResep_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		
        $this->addPenjualan_rules();
        $idpenjualan = $this->input->post('idpenjualan', TRUE);

        if ($this->form_validation->run() == FALSE) {
            $this->editPenjualanTnpResep($idpenjualan);
        } else {			
            $data_penjualan = array(	
                'idpembuat' => $idkaryawan_header,
                'tglpenjualan' => date('Y-m-d', strtotime($this->input->post('tglpenjualan', TRUE))),
                'diskon' => $this->input->post('diskon', TRUE),
                //'ppn' => $this->input->post('ppn', TRUE),
                'keterangan' => $this->input->post('keterangan', TRUE),
            );
            $this->db->where('idpenjualan', $idpenjualan);
            if ($this->db->update('atha_penjualan', $data_penjualan)){

				
				$this->pesaninfo('Data Berhasil Disimpan');
				redirect(site_url('transaksi/editPenjualanTnpResep/'.$idpenjualan));
			} else {

				$this->pesaninfo('Data Gagal Disimpan');
				redirect(site_url('transaksi/editPenjualanTnpResep/'.$idpenjualan));
			}
        }
    }
	
	public function addItemPenjualanTnpResep_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		$idpenjualan = $this->input->post('idpenjualan', TRUE);
		$produk = $this->AdminModel->get_produk($idproduk);
            $data = array(
                'idpenjualan' => $idpenjualan,
                'idproduk' => $this->input->post('idproduk', TRUE),
                'jumlah' => $this->input->post('jumlah_item', TRUE),
                'diskon' => $this->input->post('diskon_item', TRUE),
            );
            $this->db->insert('atha_itempenjualan', $data);
			
			
            $this->pesaninfo('Data Berhasil Disimpan');
            redirect(site_url('transaksi/editPenjualanTnpResep/'.$idpenjualan.'#tabelitempenjualan'));
			
    }

    public function editItemPenjualanTnpResep($idpenjualan, $iditempenjualan) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        $hakakses = $this->session->userdata('hakakses');
		
        //data content
        $supplier_data = $this->AdminModel->get_all_supplier();
        $produk_data = $this->AdminModel->get_all_produk();
        $penjualan = $this->TransaksiModel->get_penjualanTnpResep($idpenjualan);
        $itemPenjualanTnpResep_data = $this->TransaksiModel->get_all_itemPenjualanTnpResep($idpenjualan);
        $itempenjualan = $this->TransaksiModel->get_itemPenjualanTnpResep($iditempenjualan);
        if ($itempenjualan) {
            $data = array(
				'header' => 'Transaksi',
				'idkaryawan_header' => $idkaryawan_header,
				'nmkaryawan_header' => $nmkaryawan_header,
				'hakakses' => $hakakses,
				'page' => 'penjualan',
				'editPenjualanTnpResep_action' => site_url('transaksi/editPenjualanTnpResep_action'),
				
                'state' => 'update',
                'idpenjualan' => $idpenjualan,
                'nmpembuat' => set_value('nmpembuat', $penjualan->nmpembuat),
                'tglpenjualan' => set_value('tglpenjualan', $penjualan->tglpenjualan),
				'jumlah' => set_value('jumlah', $penjualan->jumlah),
				'total' => set_value('total', $penjualan->total),
				'diskon' => set_value('diskon', $penjualan->diskon),
				'keterangan' => set_value('keterangan', $penjualan->keterangan),
				
				'item_state' => 'item_update',
				'editItemPenjualanTnpResep_action' => site_url('transaksi/editItemPenjualanTnpResep_action'),
				'iditempenjualan' => set_value('iditempenjualan', $itempenjualan->iditempenjualan),
				'idproduk' => set_value('idproduk', $itempenjualan->idproduk),
				'jumlah_item' => set_value('jumlah_item', $itempenjualan->jumlah),
				'harga_item' => set_value('harga_item', $itempenjualan->harga),
				'subtotal' => set_value('subtotal', $itempenjualan->subtotal),
				'diskon_item' => set_value('diskon_item', $itempenjualan->diskon),
				'produk_data' => $produk_data,
				'itemPenjualanTnpResep_data' => $itemPenjualanTnpResep_data
				
            );

			$this->template->load('template/transaksi', 'transaksi/penjualanTnpResep_form', $data);
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/penjualan'));
        }
    }
	
	public function editItemPenjualanTnpResep_action() {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
		$idpenjualan = $this->input->post('idpenjualan', TRUE);
		$iditempenjualan = $this->input->post('iditempenjualan', TRUE);
            $data = array(
                'idpenjualan' => $idpenjualan,
                'idproduk' => $this->input->post('idproduk', TRUE),
                'jumlah' => $this->input->post('jumlah_item', TRUE),
                'diskon' => $this->input->post('diskon_item', TRUE),
            );
            $this->db->where('iditempenjualan', $iditempenjualan);
            if ($this->db->update('atha_itempenjualan', $data)){

				
				$this->pesaninfo('Data Berhasil Disimpan');
				redirect(site_url('transaksi/editItemPenjualanTnpResep/'.$idpenjualan.'/'.$iditempenjualan.'#tabelitempenjualan'));
			} else {

				$this->pesaninfo('Data Gagal Disimpan');
				redirect(site_url('transaksi/editPenjualanTnpResep/'.$idpenjualan));
			}
    }
	
    public function hapusItemPenjualanTnpResep($idpenjualan, $iditempenjualan) {
        //data header
		$idkaryawan_header = $this->session->userdata('idkaryawan');
        $nmkaryawan_header = $this->session->userdata('nmkaryawan');
        
        $itemPenjualanTnpResep = $this->TransaksiModel->get_itemPenjualanTnpResep($iditempenjualan);
        if ($itemPenjualanTnpResep) {
            $this->db->where('iditempenjualan', $iditempenjualan);
            if ($this->db->delete('atha_itempenjualan')) {
				
				
                $this->pesaninfo('Data berhasil dihapus');
            } else {
                $this->pesanerror('Data tidak berhasil dihapus');
            }
            redirect(site_url('transaksi/editPenjualanTnpResep/'.$idpenjualan.'#tabelitempenjualan'));
        } else {
            $this->pesanerror('Data Tidak Ditemukan!');
            redirect(site_url('transaksi/editPenjualanTnpResep/'.$idpenjualan.'#tabelitempenjualan'));
        }
    }
	
	public function total_penjualandgnresep($idpenjualan){
			$penjualan = $this->TransaksiModel->get_penjualanDgnResep($idpenjualan);
			$diskon = $penjualan->diskon;
			echo $total = $this->TransaksiModel->sum_itemResep($idpenjualan);
			
            $data = array(
                'total' => $total-$diskon,
            );
            $this->db->where('idpenjualan', $idpenjualan);
            $this->db->update('atha_penjualandgnresep', $data);
	}
	
	
    public function pesanerror($message) {
        $this->session->set_flashdata('idmessage', 1);
        $this->session->set_flashdata('message', $message);
    }

    public function pesaninfo($message) {
        $this->session->set_flashdata('idmessage', 2);
        $this->session->set_flashdata('message', $message);
    }
}
