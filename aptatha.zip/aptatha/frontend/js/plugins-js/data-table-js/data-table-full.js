 $(document).ready(function(){
            $('.dataTables-full').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'File_excel'},
                    {extend: 'pdf', title: 'File_excel'}
                    
                ]

            });

        });