 $(document).ready(function(){
            $('.dataTables-example').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'log_activity'},
                    {extend: 'pdf', title: 'log_activity'}
                    
                ],
				searching: true,
				info: false
            });
			
            $('.dataTables-full-karyawan').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'list_karyawan'},
                    {extend: 'pdf', title: 'list_karyawan'}
                    
                ],
				searching: true,
				info: false

            });

            $('.dataTables-full-produk').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'list_produk'},
                    {extend: 'pdf', title: 'list_produk'}
                    
                ],
				searching: true,
				info: false

            });
			
            $('.dataTables-full-supplier').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'list_supplier'},
                    {extend: 'pdf', title: 'list_supplier'}
                    
                ],
				searching: true,
				info: false

            });
			
            $('.dataTables-full-instansi').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'list_instansi'},
                    {extend: 'pdf', title: 'list_instansi'}
                    
                ],
				searching: true,
				info: false

            });
			
            $('.dataTables-full-dokter').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'list_dokter'},
                    {extend: 'pdf', title: 'list_dokter'}
                    
                ],
				searching: true,
				info: false

            });
			
			
            $('.dataTables-full-barangMasuk').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'list_barangmasuk'},
                    {extend: 'pdf', title: 'list_barangmasuk'}
                    
                ],
				searching: true,
				info: false,
				ordering: false

            });
			
            $('.dataTables-full-penjualanDgnResep').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'list_penjualandenganresep'},
                    {extend: 'pdf', title: 'list_penjualandenganresep'}
                    
                ],
				searching: true,
				info: false,
				ordering: false

            });
			
            $('.dataTables-full-penjualanTnpResep').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'list_penjualantanparesep'},
                    {extend: 'pdf', title: 'list_penjualantanparesep'}
                    
                ],
				searching: true,
				info: false,
				ordering: false

            });
			
			
            $('.dataTables-full-penjualan').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'list_penjualan'},
                    {extend: 'pdf', title: 'list_penjualan'}
                    
                ],
				searching: true,
				info: false,
				ordering: false

            });
			
			
            $('.dataTables-full-pembayaran').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'list_historypembayaran'},
                    {extend: 'pdf', title: 'list_historypembayaran'}
                    
                ],
				searching: true,
				info: false

            });
			
            $('.dataTables-full-historypembayaran').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'list_historypembayaran'},
                    {extend: 'pdf', title: 'list_historypembayaran'}
                    
                ],
				searching: true,
				info: false

            });
			
            $('.dataTables-full-transaksi').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons-tables"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'list_historypembayaran'},
                    {extend: 'pdf', title: 'list_historypembayaran'}
                    
                ],
				searching: true,
				info: false,
				ordering: false

            });
        });